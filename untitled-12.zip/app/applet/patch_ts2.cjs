const fs = require('fs');

// Path ProfileCompletionModal
let pContent = fs.readFileSync('src/components/ProfileCompletionModal.tsx', 'utf8');
pContent = pContent.replace(
   /const userData = useStore\(\(state: any\) => state\.user\) as any;/,
   `const userData = useStore((state: any) => state.user) as { displayName?: string, phone?: string, address?: string, [key:string]: any } | null;`
);
fs.writeFileSync('src/components/ProfileCompletionModal.tsx', pContent);

// Path lib/api.ts
let apiContent = fs.readFileSync('src/lib/api.ts', 'utf8');
apiContent = apiContent.replace(
   /u\.createdAt \|\| 0\)/g,
   `(u as any).createdAt || 0)`
);
fs.writeFileSync('src/lib/api.ts', apiContent);

console.log("Patched other TS errors");
