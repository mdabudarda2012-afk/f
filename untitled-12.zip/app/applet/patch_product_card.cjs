const fs = require('fs');
try {
   let pContent = fs.readFileSync('src/components/ProductCard.tsx', 'utf8');

   pContent = pContent.replace(
      /className="block relative aspect-square overflow-hidden bg-gradient-to-br from-gray-50\/50 to-white p-4 sm:p-6 group\/img"/,
      `className="block relative aspect-[4/3] sm:aspect-square overflow-hidden bg-gradient-to-br from-gray-50/50 to-white px-2 py-4 sm:p-4 group/img"`
   );

   pContent = pContent.replace(
      /h3 className="font-black text-primary-950 text-\[13px\] md:text-sm line-clamp-2 h-10 mb-4 leading-tight group-hover:text-primary-700 transition-colors uppercase tracking-tight italic"/,
      `h3 className="font-bold text-gray-800 text-[13px] sm:text-sm md:text-sm line-clamp-2 h-10 sm:h-10 mb-2 sm:mb-4 leading-tight group-hover:text-primary-600 transition-colors"`
   );

   pContent = pContent.replace(
      /<span className="font-black text-primary-900 text-xl md:text-2xl tracking-tighter shadow-primary-900\/10 drop-shadow-sm">৳\{product\.price\}<\/span>/,
      `<span className="font-black text-primary-900 text-lg sm:text-xl tracking-tight">৳{product.price}</span>`
   );

   pContent = pContent.replace(
      /div className="bg-white text-center border border-gray-100 rounded-\[2\.5rem\] overflow-hidden group hover:shadow-\[0_30px_70px_rgba\(5,46,22,0\.08\)\] transition-all duration-700 flex flex-col h-full relative border-b-4 border-b-transparent hover:border-b-primary-600"/g,
      `div className={\`bg-white text-center rounded-[1.5rem] sm:rounded-[2.5rem] overflow-hidden group hover:shadow-xl transition-all duration-300 flex flex-col h-full relative \${product.isCombo ? 'border-2 border-primary-500 shadow-md' : 'border border-gray-100'}\`}`
   );

   // Add Combo Badge
   pContent = pContent.replace(
      /\{discountPercent > 0 && \(/,
      `{product.isCombo && (
           <div className="absolute top-4 right-4 bg-primary-600 text-white text-[10px] font-bold px-3 py-1 rounded-full shadow-md z-10">
              কম্বো প্যাক
           </div>
        )}
        {discountPercent > 0 && (`
   );

   fs.writeFileSync('src/components/ProductCard.tsx', pContent);
   console.log("Patched ProductCard.tsx");
} catch(e) { console.error(e) }
