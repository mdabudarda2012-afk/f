const fs = require('fs');

function fixStore() {
    let store = fs.readFileSync('src/store.ts', 'utf8');
    store = store.replace(
       /userData:\s*\{\s*id:\s*string\s*\}/g,
       `userData: any`
    );
    fs.writeFileSync('src/store.ts', store);
}

fixStore();
