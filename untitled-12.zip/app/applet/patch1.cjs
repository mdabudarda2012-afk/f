const fs = require('fs');

let appContent = fs.readFileSync('src/App.tsx', 'utf8');
appContent = appContent.replace(
    /<Route path="\/order-tracking" element=\{\<OrderTracking \/>\} \/>/,
    '<Route path="/track" element={<OrderTracking />} />'
);

fs.writeFileSync('src/App.tsx', appContent);
console.log("Patched App.tsx route");
