const fs = require('fs');

function fixProductDetail() {
   let pd = fs.readFileSync('src/pages/ProductDetail.tsx', 'utf8');

   // Inject product.options buttons
   if (!pd.includes('অপশন নির্বাচন করুন')) {
       pd = pd.replace(
          /\{\/\* Quantity and Actions \*\/\}/,
          `{product.options && (
   <div className="mb-6">
      <span className="font-black text-gray-400 uppercase tracking-widest text-[10px] block mb-3">অপশন নির্বাচন করুন</span>
      <div className="flex flex-wrap gap-2">
         {product.options.split(',').map((o:any) => o.trim()).filter(Boolean).map((opt:any, i:any) => (
            <button
               key={i}
               onClick={() => setSelectedOption(opt)}
               className={\`px-4 py-2 rounded-xl border text-sm font-bold transition-all \${selectedOption === opt ? 'border-primary-500 bg-primary-50 text-primary-700 shadow-md' : 'border-gray-200 bg-white text-gray-600 hover:border-primary-300'}\`}
            >
               {opt}
            </button>
         ))}
      </div>
   </div>
)}
                {/* Quantity and Actions */}`
       );
   }

   // Fix Tab wrapping
   pd = pd.replace(
      /className="flex overflow-x-auto no-scrollbar border-b border-gray-100 bg-gray-50\/50"/,
      `className="flex flex-wrap sm:flex-nowrap sm:overflow-x-auto no-scrollbar border-b border-gray-100 bg-gray-50/50"`
   );
   
   pd = pd.replace(
      /className=\{\`px-6 py-4 font-bold text-sm whitespace-nowrap transition-colors relative \$\{activeTab === tab \? 'text-primary-700' : 'text-gray-500 hover:text-gray-900'\}\`\}/g,
      `className={\`px-3 py-3 sm:px-6 sm:py-4 font-bold text-xs sm:text-sm whitespace-nowrap transition-colors relative \${['Details', 'Specifications', 'Seller'].includes(tab) ? 'w-[33.33%] sm:w-auto' : 'w-[50%] border-t border-gray-100 sm:border-t-0 sm:w-auto'} \${activeTab === tab ? 'text-primary-700 bg-white shadow-sm' : 'text-gray-500 hover:text-gray-900 bg-gray-50/50'}\`}`
   );

   fs.writeFileSync('src/pages/ProductDetail.tsx', pd);
   console.log("Patched ProductDetail tabs and options");
}

function fixAPIReviews() {
   let api = fs.readFileSync('src/lib/api.ts', 'utf8');
   api = api.replace(
      /const q = query\(collection\(db, REVIEWS_COLLECTION\), where\('productId', '==', productId\), orderBy\('createdAt', 'desc'\)\);/,
      `const q = query(collection(db, REVIEWS_COLLECTION), where('productId', '==', productId));`
   );
   api = api.replace(
      /const reviews = snapshot\.docs\.map\(doc => \(\{ id: doc\.id, \.\.\.doc\.data\(\) \}\)\);/,
      `let reviews = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));\n    reviews.sort((a:any, b:any) => {\n       const tA = a.createdAt?.seconds || 0;\n       const tB = b.createdAt?.seconds || 0;\n       return tB - tA;\n    });`
   );
   fs.writeFileSync('src/lib/api.ts', api);
   console.log("Patched api.ts reviews fetch");
}

function fixComboCard() {
   let card = fs.readFileSync('src/components/ProductCard.tsx', 'utf8');
   // Replace the floating badge with a more prominent one at the top
   card = card.replace(
      /\{product\.isCombo && \([\s\S]*?কম্বো প্যাক[\s\S]*?<\/div>\s*\)\}/,
      `{product.isCombo && (
           <div className="absolute top-0 left-0 right-0 bg-primary-600 text-white text-[11px] font-black uppercase tracking-widest text-center py-1.5 z-20 shadow-sm shadow-primary-900/20">
              🔥 কম্বো অফার
           </div>
        )}`
   );
   fs.writeFileSync('src/components/ProductCard.tsx', card);
   console.log("Patched Combo card");
}

function fixAdminModal() {
   let admin = fs.readFileSync('src/pages/Admin.tsx', 'utf8');
   
   if (!admin.includes('DeleteConfirmModal')) {
       admin = admin.replace(
           /export default function Admin\(\) \{/,
           `export default function Admin() {
  const [deleteConfirmOrder, setDeleteConfirmOrder] = useState<any>(null);`
       );

       admin = admin.replace(
           /if \(confirm\('Are you sure you want to delete this order\?'\)\) \{[\s\S]*?catch \(e: any\) \{[\s\S]*?\}[\s\S]*?\}/,
           `setDeleteConfirmOrder(order);`
       );

       admin = admin.replace(
           /<\/Layout>/,
           `  <AnimatePresence>
        {deleteConfirmOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-[2rem] p-8 max-w-sm w-full shadow-2xl"
            >
              <h3 className="text-xl font-black text-gray-900 mb-2 mt-2">Delete Order?</h3>
              <p className="text-gray-500 font-medium mb-8 text-sm leading-relaxed">
                Are you completely sure you want to delete order <strong className="text-gray-900">#{deleteConfirmOrder.shortId || deleteConfirmOrder.id?.slice(-8).toUpperCase()}</strong>? This action is permanent and cannot be undone.
              </p>
              <div className="flex gap-4">
                <button
                  onClick={() => setDeleteConfirmOrder(null)}
                  className="flex-1 px-4 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={async () => {
                    try {
                      await deleteOrder(deleteConfirmOrder.id);
                      showToast('Order deleted permanently');
                    } catch (e: any) {
                      showToast('Failed to delete order', 'error');
                    }
                    setDeleteConfirmOrder(null);
                  }}
                  className="flex-1 px-4 py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 transition-colors shadow-lg shadow-red-600/20"
                >
                  Yes, Delete
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </Layout>`
       );
   }
   fs.writeFileSync('src/pages/Admin.tsx', admin);
   console.log("Patched Admin.tsx modal");
}

fixProductDetail();
fixAPIReviews();
fixComboCard();
fixAdminModal();
