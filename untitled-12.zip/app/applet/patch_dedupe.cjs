const fs = require('fs');
let coContent = fs.readFileSync('src/pages/Checkout.tsx', 'utf8');

// remove second note: formData.note
coContent = coContent.replace(
   /customerEmail: auth\.currentUser\?\.email \|\| '',\s*note: formData\.note,/,
   `customerEmail: auth.currentUser?.email || '',`
);

// fix the ts errors
coContent = coContent.replace(
   /const userData = useStore\(\(state: any\) => state\.user\) as any;/,
   `const userData = useStore((state: any) => state.user) as { displayName?: string, phone?: string, address?: string, [key:string]: any } | null;`
);

fs.writeFileSync('src/pages/Checkout.tsx', coContent);
console.log("Patched Checkout.tsx note duplication");
