const fs = require('fs');

let r1 = fs.readFileSync('src/components/ProfileCompletionModal.tsx', 'utf8');
r1 = r1.replace(/userData\?\.phone/g, '(userData as any)?.phone');
r1 = r1.replace(/userData\?\.address/g, '(userData as any)?.address');
r1 = r1.replace(/userData\?\.displayName/g, '(userData as any)?.displayName');
r1 = r1.replace(/userData\.phone/g, '(userData as any).phone');
r1 = r1.replace(/userData\.address/g, '(userData as any).address');
r1 = r1.replace(/userData\.displayName/g, '(userData as any).displayName');
fs.writeFileSync('src/components/ProfileCompletionModal.tsx', r1);

let r2 = fs.readFileSync('src/pages/Checkout.tsx', 'utf8');
r2 = r2.replace(/userData\?\.displayName/g, '(userData as any)?.displayName');
r2 = r2.replace(/userData\?\.phone/g, '(userData as any)?.phone');
r2 = r2.replace(/userData\?\.address/g, '(userData as any)?.address');
fs.writeFileSync('src/pages/Checkout.tsx', r2);

let api = fs.readFileSync('src/lib/api.ts', 'utf8');
api = api.replace(/u\.createdAt/g, '(u as any).createdAt');
fs.writeFileSync('src/lib/api.ts', api);

console.log("Patched correctly");
