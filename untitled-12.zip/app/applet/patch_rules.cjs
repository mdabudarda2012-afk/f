const fs = require('fs');
let rules = fs.readFileSync('firestore.rules', 'utf8');
rules = rules.replace(
   /match \/orders\/\{orderId\} \{\s*allow create: if true;\s*allow read: if \(isSignedIn\(\) && \(existing\(\)\.customerId == request\.auth\.uid\)\) \|\| isAdmin\(\);\s*allow update, delete: if isAdmin\(\);\s*\}/,
   `match /orders/{orderId} {
      allow create: if true;
      allow read: if true;
      allow update, delete: if isAdmin();
    }`
);
fs.writeFileSync('firestore.rules', rules);
console.log('Patched firestore.rules');
