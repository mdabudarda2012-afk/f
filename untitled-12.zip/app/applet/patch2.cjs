const fs = require('fs');

let mnContent = fs.readFileSync('src/components/MobileBottomNav.tsx', 'utf8');
mnContent = mnContent.replace(
    /\/order-tracking/g,
    '/track'
);

fs.writeFileSync('src/components/MobileBottomNav.tsx', mnContent);
console.log("Patched MobileBottomNav.tsx");
