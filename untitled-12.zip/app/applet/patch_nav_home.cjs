const fs = require('fs');

function patchNavbar() {
    let nav = fs.readFileSync('src/components/Navbar.tsx', 'utf8');
    
    if (!nav.includes('<div className="lg:hidden flex items-center justify-end gap-3">')) {
       nav = nav.replace(
          /<div className="lg:hidden w-12 flex items-center justify-end">/g,
          `<div className="lg:hidden flex items-center justify-end gap-3">
               {isUserAdmin && (
                 <Link to="/admin" className="p-2 bg-red-500 text-white rounded-xl shadow-lg border border-red-600 active:scale-95 transition-all">
                    <LayoutDashboard className="w-5 h-5" />
                 </Link>
               )}`
       );
       fs.writeFileSync('src/components/Navbar.tsx', nav);
       console.log('Patched Navbar');
    }
}

function patchHome() {
    let home = fs.readFileSync('src/pages/Home.tsx', 'utf8');

    home = home.replace(
       /\{!settings\?\.heroSideBannerImage && \([\s\S]*?<\/div>\s*\)\}/,
       ''
    );
    
    // Only wrap inside if it's not wrapped yet
    if (!home.includes('{settings?.heroSideBannerImage && (\\n              <aside')) {
        home = home.replace(
           /<aside className="hidden lg:flex flex-col w-\[280px\] xl:w-\[320px\] shrink-0 gap-6 h-\[500px\]">/,
           `{settings?.heroSideBannerImage && (
              <aside className="hidden lg:flex flex-col w-[280px] xl:w-[320px] shrink-0 gap-6 h-[500px]">`
        );

        home = home.replace(
           /<\/aside>/,
           `</aside>\n            )}`
        );
        fs.writeFileSync('src/pages/Home.tsx', home);
        console.log('Patched Home');
    }
}

patchNavbar();
patchHome();
