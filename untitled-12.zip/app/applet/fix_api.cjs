const fs = require('fs');

let api = fs.readFileSync('src/lib/api.ts', 'utf8');
api = api.replace(
   /const d1 = u\.createdAt\?\.seconds \|\| 0;/g,
   `const d1 = (u as any).createdAt?.seconds || 0;`
);
api = api.replace(
   /const d2 = b\.createdAt\?\.seconds \|\| 0;/g,
   `const d2 = (b as any).createdAt?.seconds || 0;`
);
api = api.replace(
   /b\.createdAt\?\.seconds/g,
   `(b as any).createdAt?.seconds`
);
api = api.replace(
   /u\.createdAt\?\.seconds/g,
   `(u as any).createdAt?.seconds`
);
fs.writeFileSync('src/lib/api.ts', api);
