const fs = require('fs');

function patchProductCard() {
   let pContent = fs.readFileSync('src/components/ProductCard.tsx', 'utf8');

   pContent = pContent.replace(
      /className="block relative aspect-square overflow-hidden bg-gradient-to-br from-gray-50\/50 to-white p-4 sm:p-6 group\/img"/,
      `className="block relative aspect-[4/3] sm:aspect-square overflow-hidden bg-gradient-to-br from-gray-50/50 to-white px-2 py-4 sm:p-4 group/img"`
   );

   pContent = pContent.replace(
      /h3 className="font-black text-primary-950 text-\[13px\] md:text-sm line-clamp-2 h-10 mb-4 leading-tight group-hover:text-primary-700 transition-colors uppercase tracking-tight italic"/,
      `h3 className="font-bold text-gray-800 text-[13px] sm:text-sm line-clamp-2 h-10 sm:h-10 mb-2 sm:mb-4 leading-tight group-hover:text-primary-600 transition-colors"`
   );

   pContent = pContent.replace(
      /<span className="font-black text-primary-900 text-xl md:text-2xl tracking-tighter shadow-primary-900\/10 drop-shadow-sm">৳\{product\.price\}<\/span>/,
      `<span className="font-black text-primary-900 text-[17px] sm:text-xl md:text-2xl tracking-tight">৳{product.price}</span>`
   );

   pContent = pContent.replace(
      /div className="bg-white text-center border border-gray-100 rounded-\[2\.5rem\] overflow-hidden group hover:shadow-\[0_30px_70px_rgba\(5,46,22,0\.08\)\] transition-all duration-700 flex flex-col h-full relative/g,
      `div className={\`bg-white text-center rounded-[1.5rem] sm:rounded-[2.5rem] group hover:shadow-xl transition-all duration-300 flex flex-col h-full relative overflow-hidden \${product.isCombo ? 'border-2 border-primary-500 shadow-md' : 'border border-gray-100'}\`}`
   );

   // Add Combo Badge
   pContent = pContent.replace(
      /\{discountPercent > 0 && \(/,
      `{product.isCombo && (
           <div className="absolute top-4 right-4 bg-primary-600 text-white text-[10px] sm:text-xs font-bold px-3 py-1 rounded-full shadow-md z-10">
              কম্বো প্যাক
           </div>
        )}
        {discountPercent > 0 && (`
   );

   fs.writeFileSync('src/components/ProductCard.tsx', pContent);
   console.log("Patched ProductCard.tsx");
}

function patchMobileDrawer() {
   let dContent = fs.readFileSync('src/components/MobileDrawer.tsx', 'utf8');
   dContent = dContent.replace(/\/dashboard"/g, '/admin"');
   dContent = dContent.replace(/\/order-tracking"/g, '/track"');
   fs.writeFileSync('src/components/MobileDrawer.tsx', dContent);
   console.log("Patched MobileDrawer.tsx");
}

function patchHome() {
   let hContent = fs.readFileSync('src/pages/Home.tsx', 'utf8');

   hContent = hContent.replace(
      /onClick=\{\(\) => \{\s*window\.location\.href = banner\.link \|\| banner\.targetUrl \|\| '\/products';\s*\}\}/,
      `onClick={() => {
        if (banner.link || banner.targetUrl) {
           window.location.href = banner.link || banner.targetUrl;
        }
      }}`
   );

   hContent = hContent.replace(
      /<aside className="hidden lg:flex flex-col w-\[280px\] xl:w-\[320px\] shrink-0 gap-6 h-\[500px\]">[\s\S]*?<\/aside>/,
      `<aside className="hidden lg:flex flex-col w-[280px] xl:w-[320px] shrink-0 gap-6 h-[500px]">
         {settings?.heroSideBannerImage && (
           <Link to={settings.heroSideBannerUrl || '/products'} className="relative w-full flex-1 rounded-[2rem] overflow-hidden group shadow-lg border border-primary-100 flex-shrink-0 min-h-0 bg-gray-100">
              <img src={settings.heroSideBannerImage} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" alt="Special Banner" />
           </Link>
         )}
         {!settings?.heroSideBannerImage && (
           <div className="bg-[#f0f9ff] rounded-[2rem] p-6 text-center border border-[#e0f2fe] flex flex-col relative overflow-hidden group flex-shrink-0 flex-1 min-h-0 justify-center">
              <h4 className="font-black text-xl text-[#0369a1] tracking-tight">Pure Organic</h4>
              <p className="text-xs uppercase tracking-widest text-[#0ea5e9] font-bold mt-2">100% ন্যাচারাল</p>
           </div>
         )}
      </aside>`
   );

   fs.writeFileSync('src/pages/Home.tsx', hContent);
   console.log("Patched Home.tsx");
}

function patchAdminBannerLink() {
   let adminContent = fs.readFileSync('src/pages/Admin.tsx', 'utf8');
   
   adminContent = adminContent.replace(
      /\{ name: 'link', label: 'Link URL \(Optional\)', required: false \}/,
      `{ name: 'link', label: 'Category Link', type: 'select', required: false, options: [{label: 'None', value: ''}, ...categories.map(c => ({label: c.name, value: '/category/'+c.name}))] }`
   );

   fs.writeFileSync('src/pages/Admin.tsx', adminContent);
   console.log("Patched Admin.tsx");
}

function patchReceipt() {
   let rContent = fs.readFileSync('src/components/Receipt.tsx', 'utf8');
   
   rContent = rContent.replace(/uppercase italic/g, '');
   rContent = rContent.replace(/font-black uppercase tracking-widest/g, 'font-bold text-gray-500');
   rContent = rContent.replace(/tracking-\[0\.2em\] uppercase/g, '');
   rContent = rContent.replace(/font-black tracking-wider uppercase/g, 'font-bold text-gray-700');
   rContent = rContent.replace(/uppercase tracking-tighter/g, '');
   rContent = rContent.replace(/font-extrabold text-gray-400 uppercase tracking-widest/g, 'font-bold text-gray-500 text-[11px]');
   rContent = rContent.replace(/font-black text-gray-900 tracking-wider uppercase/g, 'font-bold text-gray-800 text-sm');

   fs.writeFileSync('src/components/Receipt.tsx', rContent);
   console.log("Patched Receipt.tsx");
}

patchProductCard();
patchMobileDrawer();
patchHome();
patchAdminBannerLink();
patchReceipt();
