/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Hind Siliguri"', 'sans-serif'],
      },
      colors: {
        primary: {
          50: '#f2fbf6',
          100: '#e1f5e9',
          200: '#c3ecd4',
          300: '#94ddb6',
          400: '#5dc590',
          500: '#34a871', // Organic Sage Green
          600: '#238657',
          700: '#1e6a47',
          800: '#1b553b',
          900: '#174733',
          950: '#0c281d', // Very dark for typography
        },
        accent: {
          DEFAULT: '#f5b041', // Warm Organic Honey Gold
          hover: '#e59e2f'
        }
      }
    },
  },
  plugins: [],
}
