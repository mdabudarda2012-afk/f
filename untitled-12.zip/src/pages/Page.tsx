import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Layout from '../layouts/Layout';
import { getSettings } from '../lib/api';
import { db } from '../lib/firebase';
import { doc, getDoc } from 'firebase/firestore';

export default function Page() {
  const { slug } = useParams();
  const [settings, setSettings] = useState<any>({});
  const [dynamicContent, setDynamicContent] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    getSettings().then(setSettings);
  }, []);

  useEffect(() => {
    async function fetchDynamicContent() {
      if (!slug) return;
      setIsLoading(true);
      try {
        let content = null;
        if (slug === 'blog') {
          // If the user visits /pages/blog, they might expect a list of blogs or something, 
          // but we can just say "Please select a specific blog post" for now as we don't have a blog list view.
          setDynamicContent({ title: 'Blog', content: 'Our Latest Blogs. Please visit the correct blog link.' });
        } else {
          // Try fetching from blogs collection just in case it's a blog post
          const docRef = doc(db, 'blogs', slug);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            content = docSnap.data();
          }
        }
        if (content) {
          setDynamicContent(content);
        } else {
          setDynamicContent(null);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setIsLoading(false);
      }
    }
    
    fetchDynamicContent();
  }, [slug]);

  const titleFormat = (str: string) => {
    if (dynamicContent?.title) return dynamicContent.title;
    return str
      .split('-')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  const getPageContent = (slug: string) => {
    if (dynamicContent?.content) {
      return (
        <div className="dynamic-content">
           {dynamicContent.imageUrl && (
             <img src={dynamicContent.imageUrl || dynamicContent.image} className="w-full h-80 object-cover rounded-2xl mb-8" alt={dynamicContent.title} />
           )}
           <div className="whitespace-pre-wrap">{dynamicContent.content}</div>
        </div>
      );
    }
    switch(slug) {
      // INFORMATION
      case 'about-us':
        return (
          <>
            <p className="mb-4">Welcome to our store! We are a family-owned business dedicated to providing the highest quality natural and organic products to our customers.</p>
            <p className="mb-4">Our journey started with a simple belief: that everyone deserves access to healthy, pure, and unadulterated food. We work directly with farmers and trusted suppliers to bring you authentic products like raw honey, premium dates, and unrefined oils.</p>
            <p>Thank you for choosing us. We are committed to your health and satisfaction.</p>
          </>
        );
      case 'contact-us':
        return (
          <>
            <p className="mb-4">We'd love to hear from you! Please reach out to us using any of the following methods:</p>
            <ul className="list-none space-y-2 mb-6">
              <li><strong>Email:</strong> {settings?.contactEmailGeneral || settings?.email || 'support@kholosshop.com'}</li>
              <li><strong>Phone:</strong> {settings?.contactNumber || settings?.phone || '+880 1234 567890'}</li>
              <li><strong>Address:</strong> {settings?.contactAddress || settings?.address || 'Dhaka, Bangladesh'}</li>
            </ul>
            <p>Our support team is available from 9 AM to 9 PM everyday to assist you with your queries.</p>
            {settings?.googleMapUrl && (
              <div className="mt-8 rounded-2xl overflow-hidden shadow-lg border border-gray-100 h-80 lg:h-96 w-full">
                 <iframe src={settings.googleMapUrl} width="100%" height="100%" style={{border: 0}} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
              </div>
            )}
          </>
        );
      case 'company-information':
        return (
          <>
            <p className="mb-4">Kholos Shop is an enterprise registered in Bangladesh, committed to supplying premium organic and natural foods directly to consumers.</p>
            <p className="mb-4">Registration Number: XYZ-123456</p>
            <p>Trade License: XXXXXXXXXX</p>
          </>
        );
      case 'stories':
        return (
          <>
            <p className="mb-4">Every product has a story. Our raw honey comes from the deep Sundarbans, collected by experienced local beekeepers who have been doing this for generations.</p>
            <p>Our Ajwa dates are sourced directly from the finest farms in Madinah. We believe knowing the origin of your food makes every bite more meaningful.</p>
          </>
        );
      case 'terms-and-conditions':
        return (
          <>
            <p className="mb-4">By accessing and using this website, you agree to comply with our Terms & Conditions.</p>
            <ul className="list-disc pl-5 space-y-2 mb-6">
              <li>All content is for informational and shopping purposes only.</li>
              <li>Prices are subject to change without prior notice.</li>
              <li>We reserve the right to cancel any order due to stock unavailability or suspected fraud.</li>
            </ul>
          </>
        );
      case 'privacy-policy':
        return (
          <>
            <p className="mb-4">We value your privacy. We only collect information necessary to process your order, such as your name, address, and contact number.</p>
            <p>We will never sell or share your personal data with third parties. Payment information is securely encrypted.</p>
          </>
        );
      case 'careers':
        return (
          <>
            <p className="mb-4">We are always looking for passionate individuals to join our team. If you love natural products and want to grow with us, send your CV to careers@kholosshop.com.</p>
            <p>Currently open positions: None</p>
          </>
        );

      // SUPPORT
      case 'support-center':
        return (
          <>
             <p className="mb-4">Welcome to the Support Center. If you have any issues with your order, please do not hesitate to contact us.</p>
             <p>Our helpline is active 7 days a week: +880 1234 567890.</p>
          </>
        );
      case 'how-to-order':
        return (
          <ol className="list-decimal pl-5 space-y-2 mb-6">
            <li>Browse our catalog and click "Add to Cart" on your desired products.</li>
            <li>Click the shopping bag icon on the top right to view your cart.</li>
            <li>Click "Proceed to Checkout".</li>
            <li>Enter your delivery details and choose your payment method.</li>
            <li>Click "Confirm Order". You will receive an SMS confirmation.</li>
          </ol>
        );
      case 'order-tracking':
        return (
          <>
            <p className="mb-4">Once your order is dispatched, you will receive an SMS with a tracking link from our courier partner.</p>
            <p>You can also log into your account here and go to the Orders section to view live status updates.</p>
          </>
        );
      case 'payment':
        return (
          <>
            <p className="mb-4">We support multiple payment methods for your convenience:</p>
            <ul className="list-disc pl-5 space-y-2 mb-6">
              <li><strong>Cash on Delivery (COD)</strong> - Pay when you receive the product.</li>
              <li><strong>bKash / Nagad</strong> - Secure mobile banking channels.</li>
              <li><strong>Credit/Debit Cards</strong> - We accept Visa, Mastercard, and Amex.</li>
            </ul>
          </>
        );
      case 'shipping':
        return (
          <>
            <p className="mb-4">We deliver nationwide across Bangladesh. Here are our shipping terms:</p>
            <ul className="list-disc pl-5 space-y-2 mb-6">
              <li>Inside Dhaka: 1-2 business days (Delivery charge ৳60)</li>
              <li>Outside Dhaka: 2-3 business days (Delivery charge ৳120)</li>
            </ul>
            <p>We provide home delivery for all orders. You will receive an SMS tracking link once your order is dispatched.</p>
          </>
        );
      case 'faq':
        return (
          <div className="space-y-4">
             <div>
               <h3 className="font-bold mb-1">Are your products 100% natural?</h3>
               <p>Yes, we ensure all our products are organic and unadulterated.</p>
             </div>
             <div>
               <h3 className="font-bold mb-1">Do you deliver outside Dhaka?</h3>
               <p>Yes, we deliver to all 64 districts in Bangladesh.</p>
             </div>
             <div>
               <h3 className="font-bold mb-1">What if I receive a damaged product?</h3>
               <p>Contact our support team within 24 hours of delivery for a free exchange or refund.</p>
             </div>
          </div>
        );

      // CONSUMER POLICY
      case 'refund-policy':
      case 'happy-return':
      case 'exchange':
        return (
          <>
            <p className="mb-4">We offer a 100% Happy Return Policy. If you are not satisfied with your purchase, you can return or exchange the product within 7 days of delivery.</p>
            <p className="mb-4"><strong>Conditions for Return/Exchange:</strong></p>
            <ul className="list-disc pl-5 space-y-2 mb-6">
              <li>The product must be unused and in its original packaging.</li>
              <li>Perishable items cannot be returned unless damaged during transit.</li>
              <li>Please contact our customer support before sending the item back.</li>
            </ul>
            <p>Refunds will be processed within 5-7 business days after we receive the returned item.</p>
          </>
        );
      case 'cancellation':
        return (
          <>
            <p className="mb-4">You can cancel your order any time before it is dispatched from our warehouse.</p>
            <p>To cancel an order, please call our hotline +880 1234 567890 immediately. If the order has already been handed over to the courier, cancellation may not be possible.</p>
          </>
        );
      case 'pre-order':
        return (
          <>
             <p className="mb-4">Certain exclusive items can be pre-ordered. Pre-orders may require partial or full advance payment.</p>
             <p>Delivery timelines for pre-ordered items will be clearly stated on the product page.</p>
          </>
        );
      case 'extra-discount':
        return (
          <>
             <p className="mb-4">We occasionally offer discounts and coupon codes.</p>
             <p>Unless clearly specified, multiple promo codes cannot be combined in a single order.</p>
          </>
        );

      default:
        return (
          <>
             <p className="mb-4">
               Welcome to the {titleFormat(slug || '')} page. This area contains all relevant information related to this topic.
             </p>
             <p className="mb-4">
               We are committed to providing you with the best experience and ensuring our policies are clear and transparent.
             </p>
             <div className="h-40 bg-white rounded-xl mt-8 flex items-center justify-center border-2 border-dashed border-gray-200">
               <span className="text-gray-400 font-medium">Detailed content will be updated soon.</span>
             </div>
          </>
        );
    }
  };

  return (
    <Layout>
      <div className="bg-gray-50/30 py-16 md:py-24 min-h-[60vh] relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 -mt-20 -mr-20 w-64 h-64 bg-primary-100 rounded-full blur-3xl opacity-50 pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-80 h-80 bg-accent/20 rounded-full blur-3xl opacity-50 pointer-events-none"></div>
        
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="bg-white rounded-[2.5rem] p-8 md:p-14 lg:p-20 shadow-[0_20px_40px_-15px_rgba(0,0,0,0.05)] border border-gray-100 relative">
            <div className="absolute top-0 right-10 -translate-y-1/2 bg-yellow-400 text-yellow-900 text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-lg italic">
               Official Information
            </div>
            
            <h1 className="text-4xl md:text-5xl font-black text-primary-950 mb-10 pb-10 border-b-2 border-dashed border-gray-100 uppercase tracking-tight italic inline-block w-full">
               {titleFormat(slug || '')}
            </h1>
            
            <div className="prose prose-lg max-w-none text-gray-600 font-medium leading-[1.8] prose-p:mb-6 prose-ul:mb-6 prose-ol:mb-6 prose-li:mb-2 prose-h3:text-2xl prose-h3:font-black prose-h3:text-primary-900 prose-h3:mt-10 prose-h3:mb-4 prose-strong:text-primary-950 prose-a:text-primary-600 prose-a:no-underline hover:prose-a:underline">
               {getPageContent(slug || '')}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
