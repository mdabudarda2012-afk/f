// @ts-nocheck
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';
import Layout from '../layouts/Layout';
import { addOrder, getUserProfile, getSettings, verifyCoupon } from '../lib/api';
import { auth } from '../lib/firebase';
import Receipt from '../components/Receipt';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { Locate, Tag } from 'lucide-react';

// Fix for default marker icon in react-leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
    iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png'
});

function LocationMarker({ position, setPosition, onPositionSelected }: any) {
  const map = useMapEvents({
    async click(e) {
      setPosition(e.latlng);
      map.flyTo(e.latlng, map.getZoom());
      if (onPositionSelected) {
         try {
            const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${e.latlng.lat}&lon=${e.latlng.lng}`);
            const data = await res.json();
            if (data && data.display_name) {
               onPositionSelected(data.display_name);
            }
         } catch (error) {
            console.error(error);
         }
      }
    },
    locationfound(e) {
      if (!position) {
        setPosition(e.latlng);
        map.flyTo(e.latlng, map.getZoom());
      }
    },
  });

  useEffect(() => {
    map.locate();
  }, [map]);

  return position === null ? null : (
    <Marker position={position}></Marker>
  );
}

export default function Checkout() {
  const { cart, cartTotal, clearCart } = useStore();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [placedOrder, setPlacedOrder] = useState<any>(null);
  const [position, setPosition] = useState<{lat: number, lng: number} | null>(null);
  const [paymentMethod, setPaymentMethod] = useState('COD');
  const [transactionId, setTransactionId] = useState('');
  const [settings, setSettings] = useState<any>(null);
  
  const [couponCode, setCouponCode] = useState('');
  const [coupon, setCoupon] = useState<any>(null);
  const [couponError, setCouponError] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    city: 'Dhaka',
    note: ''
  });
  
  useEffect(() => {
    const fetchProfile = async () => {
      if (auth.currentUser?.uid) {
        const profile = await getUserProfile(auth.currentUser.uid);
        if (profile) {
          setFormData(prev => ({
            ...prev,
            name: profile.displayName || auth.currentUser?.displayName || '',
            phone: profile.phone || '',
            address: profile.address || ''
          }));
        }
      }
    };
    fetchProfile();
    
    // Auto-detect location for map
    if ("geolocation" in navigator && !formData.address) {
       navigator.geolocation.getCurrentPosition(async (pos) => {
         const { latitude, longitude } = pos.coords;
         setPosition({ lat: latitude, lng: longitude });
         try {
           const res = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${import.meta.env.VITE_GOOGLE_MAPS_API_KEY}`);
           const data = await res.json();
           if (data.results && data.results[0]) {
             setFormData(prev => {
                if (prev.address) return prev; // Don't overwrite if manual entry started
                return { ...prev, address: data.results[0].formatted_address };
             });
           }
         } catch (e) {
           console.error('Reverse geocode failed', e);
         }
       }, (err) => {
         console.log("Location permission denied or error", err);
       });
    }
  }, [auth.currentUser?.uid]);

  useEffect(() => {
    getSettings().then(setSettings);
  }, []);

  const handleApplyCoupon = async () => {
    setCouponError('');
    if (!couponCode.trim()) {
      setCouponError('Please enter a valid coupon');
      return;
    }
    const c = await verifyCoupon(couponCode);
    if (c) {
      setCoupon(c);
    } else {
      setCoupon(null);
      setCouponError('Invalid or expired coupon');
    }
  };

  const handleDetectLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(async (position) => {
        const { latitude, longitude } = position.coords;
        setPosition({ lat: latitude, lng: longitude });
        
        // Try to get address via reverse geocoding if maps is available
        try {
          const response = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${import.meta.env.VITE_GOOGLE_MAPS_API_KEY}`);
          const data = await response.json();
          if (data.results && data.results[0]) {
            setFormData(prev => ({ ...prev, address: data.results[0].formatted_address }));
          }
        } catch (error) {
          console.error('Reverse geocoding failed', error);
        }
      });
    } else {
      alert("আপনার ব্রাউজারটি লোকেশন সার্ভিস সাপোর্ট করে না।");
    }
  };

  // Auto-detect location on mount if possible
  useEffect(() => {
    if ("geolocation" in navigator) {
      navigator.permissions?.query({ name: 'geolocation' }).then((result) => {
        if (result.state === 'granted') {
           handleDetectLocation();
        }
      });
    }
  }, []);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'BDT',
      maximumFractionDigits: 0,
    }).format(price).replace('BDT', '৳');
  };

  const deliveryCharge = formData.city === 'Dhaka' ? 60 : 120;
  
  let discountAmount = 0;
  if (coupon) {
    if (coupon.type === 'percent') {
      discountAmount = (cartTotal() * coupon.discount) / 100;
    } else {
      discountAmount = coupon.discount;
    }
  }
  
  const total = cartTotal() + deliveryCharge - discountAmount;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;
    setIsSubmitting(true);
    try {
      const orderData = {
        customerName: formData.name,
        customerPhone: formData.phone.replace(/[^0-9+]/g, ''),
        customerAddress: `${formData.address}, ${formData.city}`,
        coordinates: position ? { lat: position.lat, lng: position.lng } : null,
        note: formData.note,
        items: cart.map(item => ({
             productId: item.cartItemId,
             name: item.name,
             price: item.price,
             quantity: item.quantity,
             image: item.image
        })),
        totalAmount: total,
        customerId: auth.currentUser?.uid || 'guest',
        customerEmail: auth.currentUser?.email || '',
        paymentMethod,
        transactionId: paymentMethod !== 'COD' ? transactionId : null,
        source: window.innerWidth < 768 ? 'Mobile' : 'Desktop',
        userAgent: navigator.userAgent
      };
      const result = await addOrder(orderData);
      
      if (!result || !result.id) {
        throw new Error('অর্ডার সেভ করতে সমস্যা হয়েছে।');
      }

      const { id: orderId, shortId } = result;
      
      const successOrder = { 
        id: orderId, 
        shortId: shortId || orderId.slice(-6).toUpperCase(), 
        ...orderData, 
        createdAt: Date.now() 
      };
      
      setPlacedOrder(successOrder);
      clearCart();
      window.scrollTo(0, 0);
    } catch (error: any) {
      console.error('Order Error:', error);
      alert(error.message || 'অর্ডার প্লেস করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Success View / Receipt
  if (placedOrder) {
    return (
      <Layout>
        <div className="px-4 py-8 mx-auto max-w-4xl sm:px-6 lg:px-8 print:p-0 print:m-0 print:max-w-none">
          <Receipt order={placedOrder} />
        </div>
      </Layout>
    );
  }

  if (cart.length === 0) {
    return (
      <Layout>
        <div className="min-h-[60vh] flex items-center justify-center px-4">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">আপনার কার্টে বর্তমানে কোনো পণ্য নেই।</h2>
            <Link to="/" className="text-primary-600 hover:text-primary-800 font-medium">
              সেরা মানের পণ্যগুলো দেখতে শপিং শুরু করুন।
            </Link>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="px-4 py-8 mx-auto max-w-7xl sm:px-6 lg:px-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-8">চেকআউট</h1>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Checkout Form */}
          <div className="flex-1">
            <div className="bg-white border border-gray-100 rounded-2xl p-6 md:p-8 shadow-sm">
              <h2 className="text-xl font-black text-gray-900 mb-6">ডেলিভারি ইনফরমেশন</h2>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                    আপনার নাম *
                  </label>
                  <div className="mt-1">
                    <input
                      type="text"
                      id="name"
                      required
                      className="block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                    মোবাইল নাম্বার *
                  </label>
                  <div className="mt-1">
                    <input
                      type="tel"
                      id="phone"
                      required
                      placeholder="01XXXXXXXXX"
                      className="block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="city" className="block text-sm font-medium text-gray-700">
                    শহর *
                  </label>
                  <div className="mt-1">
                    <select
                      id="city"
                      className="block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    >
                      <option value="Dhaka">ঢাকা (ডেলিভারি চার্জ: ৬০ টাকা)</option>
                      <option value="Outside">ঢাকার বাইরে (ডেলিভারি চার্জ: ১২০ টাকা)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="address" className="block text-sm font-medium text-gray-700">
                    সম্পূর্ণ ঠিকানা *
                  </label>
                  <div className="mt-1">
                    <textarea
                      id="address"
                      rows={3}
                      required
                      className="block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    />
                  </div>
                </div>
      <div>
         <label htmlFor="note" className="block text-sm font-medium text-gray-700 mt-4">
         অতিরিক্ত নোট (ঐচ্ছিক)
         </label>
         <div className="mt-1">
         <textarea
            id="note"
            rows={2}
            className="block w-full px-4 py-3 border border-gray-300 rounded-md shadow-sm focus:ring-primary-500 focus:border-primary-500 sm:text-sm"
            value={formData.note}
            onChange={(e) => setFormData({ ...formData, note: e.target.value })}
            placeholder="অর্ডার সম্পর্কে কোন তথ্য থাকলে দিন..."
         />
         </div>
      </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-sm font-medium text-gray-700">
                      ম্যাপ থেকে লোকশন সিলেক্ট করুন (ঐচ্ছিক)
                    </label>
                    <button 
                      type="button"
                      onClick={handleDetectLocation}
                      className="text-[10px] font-black text-primary-600 uppercase tracking-widest flex items-center gap-1.5 hover:text-primary-800 transition-colors bg-primary-50 px-3 py-1 rounded-full"
                    >
                      <Locate className="w-3 h-3" />
                      Auto Detect
                    </button>
                  </div>
                  <div className="h-48 w-full bg-gray-100 rounded-lg overflow-hidden border border-gray-300 relative z-0">
                    <MapContainer center={[23.8103, 90.4125]} zoom={13} scrollWheelZoom={true} className="h-full w-full">
                      <TileLayer
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                      />
                      <LocationMarker position={position} setPosition={setPosition} onPositionSelected={(addr: string) => setFormData(prev => ({ ...prev, address: addr }))} />
                    </MapContainer>
                  </div>
                  {position && <p className="text-xs text-green-600 mt-2 font-medium">লোকেশন সিলেক্ট হয়েছে!</p>}
                </div>

                <div className="pt-4 border-t border-gray-200">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">পেমেন্ট মেথড</h3>
                  <div className="space-y-3">
                    <label className={`block border ${paymentMethod === 'COD' ? 'border-primary-500 bg-primary-50' : 'border-gray-200'} rounded-lg p-4 cursor-pointer transition-colors relative`}>
                      <div className="flex items-center gap-3">
                        <input type="radio" name="paymentMethod" value="COD" checked={paymentMethod === 'COD'} onChange={(e) => setPaymentMethod(e.target.value)} className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300" />
                        <span className="font-medium text-gray-900">ক্যাশ অন ডেলিভারি (COD)</span>
                      </div>
                    </label>

                    <label className={`block border ${paymentMethod === 'bKash' ? 'border-pink-500 bg-pink-50' : 'border-gray-200'} rounded-lg p-4 cursor-pointer transition-colors relative`}>
                      <div className="flex items-center gap-3">
                        <input type="radio" name="paymentMethod" value="bKash" checked={paymentMethod === 'bKash'} onChange={(e) => setPaymentMethod(e.target.value)} className="h-4 w-4 text-pink-600 focus:ring-pink-500 border-gray-300" />
                        <span className="font-medium text-gray-900">বিকাশ (bKash)</span>
                      </div>
                      {paymentMethod === 'bKash' && (
                         <div className="mt-4 pl-7 text-sm text-gray-700 animate-in fade-in slide-in-from-top-2">
                             <p className="mb-2">Send Money to: <strong>{settings?.bkashNumber || 'Not configured'}</strong></p>
                            <input type="text" placeholder="Transaction ID" required={paymentMethod === 'bKash'} value={transactionId} onChange={e => setTransactionId(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-pink-500" />
                         </div>
                      )}
                    </label>

                    <label className={`block border ${paymentMethod === 'Nagad' ? 'border-orange-500 bg-orange-50' : 'border-gray-200'} rounded-lg p-4 cursor-pointer transition-colors relative`}>
                      <div className="flex items-center gap-3">
                        <input type="radio" name="paymentMethod" value="Nagad" checked={paymentMethod === 'Nagad'} onChange={(e) => setPaymentMethod(e.target.value)} className="h-4 w-4 text-orange-600 focus:ring-orange-500 border-gray-300" />
                        <span className="font-medium text-gray-900">নগদ (Nagad)</span>
                      </div>
                      {paymentMethod === 'Nagad' && (
                         <div className="mt-4 pl-7 text-sm text-gray-700 animate-in fade-in slide-in-from-top-2">
                            <p className="mb-2">Send Money to: <strong>{settings?.nagadNumber || 'Not configured'}</strong></p>
                            <input type="text" placeholder="Transaction ID" required={paymentMethod === 'Nagad'} value={transactionId} onChange={e => setTransactionId(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-orange-500" />
                         </div>
                      )}
                    </label>

                    <label className={`block border ${paymentMethod === 'Rocket' ? 'border-purple-500 bg-purple-50' : 'border-gray-200'} rounded-lg p-4 cursor-pointer transition-colors relative`}>
                      <div className="flex items-center gap-3">
                        <input type="radio" name="paymentMethod" value="Rocket" checked={paymentMethod === 'Rocket'} onChange={(e) => setPaymentMethod(e.target.value)} className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300" />
                        <span className="font-medium text-gray-900">রকেট (Rocket)</span>
                      </div>
                      {paymentMethod === 'Rocket' && (
                         <div className="mt-4 pl-7 text-sm text-gray-700 animate-in fade-in slide-in-from-top-2">
                            <p className="mb-2">Send Money to: <strong>{settings?.rocketNumber || 'Not configured'}</strong></p>
                            <input type="text" placeholder="Transaction ID" required={paymentMethod === 'Rocket'} value={transactionId} onChange={e => setTransactionId(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500" />
                         </div>
                      )}
                    </label>
                  </div>
                </div>

                <div className="pt-6">
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full flex justify-center items-center gap-2 py-4 px-4 rounded-xl shadow-md text-lg font-black text-white bg-primary-700 hover:bg-primary-800 disabled:opacity-70 transition-all transform active:scale-[0.98]"
                  >
                    {isSubmitting ? (
                      <>
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                           <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                           <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        প্রসেসিং...
                      </>
                    ) : (
                      `অর্ডার কনফার্ম করুন ( ${formatPrice(total)} )`
                    )}
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Order Summary */}
          <div className="w-full lg:w-96">
            <div className="bg-gray-50 border border-gray-100 rounded-2xl p-6 sticky top-24 shadow-sm">
              <h2 className="text-lg font-medium text-gray-900 mb-6">অর্ডার ওভারভিউ</h2>

              <ul className="divide-y divide-gray-200 mb-6">
                {cart.map((item) => (
                  <li key={item.cartItemId} className="py-3 flex justify-between">
                    <div className="flex items-center">
                      <span className="text-gray-500 text-sm">{item.quantity} x </span>
                      <span className="ml-2 text-sm font-medium text-gray-900 line-clamp-1">{item.name}</span>
                    </div>
                    <span className="text-sm font-medium text-gray-900 whitespace-nowrap ml-4">
                      {formatPrice(item.price * item.quantity)}
                    </span>
                  </li>
                ))}
              </ul>

              <dl className="space-y-4 text-sm text-gray-600 border-t border-gray-200 pt-6">
                <div className="flex justify-between">
                  <dt>সাবটোটাল</dt>
                  <dd className="font-medium text-gray-900">{formatPrice(cartTotal())}</dd>
                </div>
                <div className="flex justify-between">
                  <dt>ডেলিভারি চার্জ ({formData.city === 'Dhaka' ? 'ঢাকা' : 'ঢাকার বাইরে'})</dt>
                  <dd className="font-medium text-gray-900">{formatPrice(deliveryCharge)}</dd>
                </div>
                
                {coupon && (
                   <div className="flex justify-between text-green-600">
                     <dt>ডিসকাউন্ট ({coupon.code})</dt>
                     <dd className="font-bold">-{formatPrice(discountAmount)}</dd>
                   </div>
                )}
                
                <div className="border-t border-gray-200 pt-4 flex justify-between">
                  <dt className="text-lg font-bold text-gray-900">সর্বমোট</dt>
                  <dd className="text-lg font-bold text-primary-700">{formatPrice(total)}</dd>
                </div>
              </dl>

              <div className="mt-6 border-t border-gray-200 pt-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">কুপন কোড (যদি থাকে)</label>
                <div className="flex gap-2">
                  <div className="relative flex-1">
                     <Tag className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                     <input 
                       type="text" 
                       value={couponCode}
                       onChange={e => setCouponCode(e.target.value)}
                       placeholder="Enter code" 
                       className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 uppercase"
                     />
                  </div>
                  <button type="button" onClick={handleApplyCoupon} className="bg-gray-900 text-white px-4 py-2 rounded-lg font-bold hover:bg-black transition-colors">
                    Apply
                  </button>
                </div>
                {couponError && <p className="text-red-500 text-xs mt-2">{couponError}</p>}
                {coupon && <p className="text-green-600 text-xs mt-2 font-bold">Coupon applied successfully!</p>}
              </div>

            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
