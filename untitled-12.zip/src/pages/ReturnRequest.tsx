import { useState, useEffect } from 'react';
import Layout from '../layouts/Layout';
import { addReturnRequest, getUserProfile } from '../lib/api';
import { auth } from '../lib/firebase';
import { useNavigate } from 'react-router-dom';

export default function ReturnRequest() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    customerName: '',
    phone: '',
    orderId: '',
    itemsText: '', // simpler for user to just specify what they're returning text-wise if not linked directly
    reason: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const fetchProfile = async () => {
      if (auth.currentUser?.uid) {
        const profile = await getUserProfile(auth.currentUser.uid) as any;
        if (profile) {
          setFormData(prev => ({
            ...prev,
            customerName: profile.displayName || auth.currentUser?.displayName || '',
            phone: profile.phone || ''
          }));
        }
      }
    };
    fetchProfile();
  }, [auth.currentUser?.uid]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) {
      alert("Please login first to submit a return request.");
      return;
    }
    setIsSubmitting(true);
    try {
      await addReturnRequest({
        orderId: formData.orderId,
        customerId: auth.currentUser.uid,
        items: [{name: formData.itemsText}], // Mocking items structure
        reason: formData.reason,
        phone: formData.phone,
        customerName: formData.customerName
      });
      alert('Return request has been submitted to the Admin!');
      navigate('/account');
    } catch (error: any) {
      alert('Error submitting return: ' + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Layout>
      <div className="bg-gray-50 min-h-[70vh] py-12">
        <div className="max-w-2xl mx-auto px-4">
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
            <h1 className="text-2xl font-black text-gray-900 mb-2">Return Request</h1>
            <p className="text-gray-500 mb-8 border-b border-gray-100 pb-6">Looking to return an item? Please fill out the form below and provide your exact Order ID.</p>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Customer Name</label>
                  <input required type="text" value={formData.customerName} onChange={e => setFormData(prev => ({ ...prev, customerName: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Phone Number</label>
                  <input required type="tel" value={formData.phone} onChange={e => setFormData(prev => ({ ...prev, phone: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Order ID</label>
                <input required type="text" value={formData.orderId} onChange={e => setFormData(prev => ({ ...prev, orderId: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20" placeholder="e.g. KHL-123456" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Items to Return</label>
                <input required type="text" value={formData.itemsText} onChange={e => setFormData(prev => ({ ...prev, itemsText: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20" placeholder="e.g. 5x Natural Honey 1KG" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Reason for Return</label>
                <textarea required value={formData.reason} onChange={e => setFormData(prev => ({ ...prev, reason: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20" rows={4} placeholder="Please explain why you want to return the product(s)..."></textarea>
              </div>
              
              <button disabled={isSubmitting} type="submit" className="w-full py-4 bg-primary-950 hover:bg-black text-white font-black uppercase tracking-widest rounded-xl disabled:opacity-50">
                {isSubmitting ? 'Submitting...' : 'Submit Return Request'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </Layout>
  );
}
