import { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart as RePieChart, Pie, Cell } from 'recharts';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { Package, ShoppingBag, Users, User, Mail, Phone, MapPin, LayoutDashboard, Search, Menu, TrendingUp, ChevronLeft, LogOut, List, CreditCard, Star, Banknote, Ticket, Image, Settings, Trash2, Edit, CheckCircle, XCircle, Truck, X, ArrowRight, Shield, Monitor, ShoppingCart, Share2, Terminal, Database, Clock, ExternalLink, Save, History, RefreshCcw, RefreshCw, Eye, EyeOff, Link as LinkIcon, Zap, Activity, Palette, FileText, Plus, HelpCircle, Layers, Leaf, Download, Lock } from 'lucide-react';

// Interfaces for better type safety
interface Order {
  id: string;
  customerName: string;
  phone: string;
  total: number;
  totalAmount?: number;
  status: string;
  createdAt: string;
  items: any[];
  [key: string]: any;
}

interface Product {
  id: string;
  name: string;
  title?: string;
  price: number;
  stock: number;
  category: string;
  brand: string;
  image?: string;
  label?: string;
  [key: string]: any;
}

interface Coupon {
  id: string;
  code: string;
  discount: number;
  expiry: string;
  [key: string]: any;
}

interface Reseller {
  id: string;
  businessName: string;
  ownerName: string;
  email: string;
  status: string;
  [key: string]: any;
}

interface Withdrawal {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  status: string;
  createdAt: string;
  [key: string]: any;
}

interface SiteImage {
  id: string;
  url: string;
  name?: string;
  type: string;
  [key: string]: any;
}

interface ReturnRequest {
  id: string;
  orderId: string;
  reason: string;
  status: string;
  createdAt: string;
  [key: string]: any;
}

interface SiteSettings {
  siteName?: string;
  contactEmail?: string;
  heroSideBannerImage?: string;
  heroSideBannerUrl?: string;
  heroSideBannerTitle?: string;
  homeSection1Title?: string;
  homeSection1Filter?: string;
  homeSection2Title?: string;
  homeSection2Filter?: string;
  homeSection3Title?: string;
  homeSection3Filter?: string;
  homeSection4Title?: string;
  homeSection4Filter?: string;
  [key: string]: any;
}

interface Category {
  id: string;
  name: string;
  image?: string;
  [key: string]: any;
}

interface Brand {
  id: string;
  name: string;
  image?: string;
  [key: string]: any;
}

interface UserData {
  id: string;
  name: string;
  email: string;
  role?: string;
  [key: string]: any;
}
import { auth, db } from '../lib/firebase';
import { signInWithPopup, GoogleAuthProvider, signOut, signInAnonymously, signInWithEmailAndPassword } from 'firebase/auth';
import { doc, updateDoc } from 'firebase/firestore';
import { subscribeToOrders, subscribeToProducts, updateOrderStatus, updateProduct, deleteProduct, addProduct, subscribeToCategories, addCategory, updateCategory, deleteCategory, subscribeToCoupons, addCoupon, deleteCoupon, subscribeToUsers, getSettings, saveSettings, subscribeToSiteImages, addSiteImage, deleteSiteImage, subscribeToResellers, addReseller, subscribeToWithdrawals, subscribeToBrands, addBrand, updateBrand, deleteBrand, subscribeToReturns, updateReturnStatus, deleteOrder, deleteUser, deleteReseller, deleteWithdrawal, deleteReturnRequest, restockItems, subscribeToCollection, addItemToCollection, updateItemInCollection, deleteItemFromCollection } from '../lib/api';

import { motion, AnimatePresence } from 'motion/react';
import Receipt from '../components/Receipt';

export default function Admin() {
  const [deleteConfirmOrder, setDeleteConfirmOrder] = useState<any>(null);
  const [user, setUser] = useState(auth.currentUser);
  const [isLoadingAuth, setIsLoadingAuth] = useState(true);
  const location = useLocation();
  const navigate = useNavigate();
  const pathParts = location.pathname.split('/');
  const activeTab = pathParts[2] || 'dashboard';
  const [orders, setOrders] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [brands, setBrands] = useState<any[]>([]);
  const [coupons, setCoupons] = useState<any[]>([]);
  const [customers, setCustomers] = useState<any[]>([]);
  const [resellers, setResellers] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [siteImages, setSiteImages] = useState<any[]>([]);
  const [returns, setReturns] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [uiConfigTab, setUiConfigTab] = useState('hero-banners');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [genericData, setGenericData] = useState<Record<string, any>[]>([]);
  const lowStockProducts = products.filter(p => (p.stock || 0) < 10);

  const [modalConfig, setModalConfig] = useState<{
    isOpen: boolean;
    title: string;
    fields: { name: string, label: string, type?: string, defaultValue?: string, required?: boolean, options?: {label: string, value: string}[] }[];
    onSubmit: (data: Record<string, any>) => void;
  } | null>(null);

  const [toast, setToast] = useState<{message: string, type: 'success'|'error'} | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };
  
  const [isTempAdmin, setIsTempAdmin] = useState(localStorage.getItem('isTempAdmin') === 'true');
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged((user) => {
      setUser(user);
      setIsLoadingAuth(false);
      
      // Auto sign-in anonymously if in temp admin mode but not signed in to Firebase
      // this ensures firestore rules work after page refresh
      if (!user && isTempAdmin) {
        signInAnonymously(auth).catch(err => console.error('Silent login failed', err));
      }
    });
    return () => unsubscribe();
  }, [isTempAdmin]);

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await signInWithEmailAndPassword(auth, adminEmail, adminPassword);
      showToast('Login successful', 'success');
    } catch (err: any) {
      showToast(err.message, 'error');
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.error('Sign out error', e);
    }
    setIsTempAdmin(false);
    localStorage.removeItem('isTempAdmin');
    window.dispatchEvent(new Event('authStatusChanged'));
    showToast('Logged out successfully');
    navigate('/dashboard');
  };

  const ADMIN_EMAILS = ['mdjaberboss2@gmail.com', 'admin@example.com', 'admin@kholosshop.com', 'nmd032984@gmail.com', 'tipsandtechunlimited@gmail.com'];
  const isUserAdmin = (user?.email && ADMIN_EMAILS.includes(user.email.toLowerCase())) || isTempAdmin;

  useEffect(() => {
    if (isUserAdmin) {
      const unsubOrders = subscribeToOrders(setOrders);
      const unsubProducts = subscribeToProducts(setProducts);
      const unsubCategories = subscribeToCategories(setCategories);
      const unsubBrands = subscribeToBrands(setBrands);
      const unsubCoupons = subscribeToCoupons(setCoupons);
      const unsubUsers = subscribeToUsers(setCustomers);
      const unsubResellers = subscribeToResellers(setResellers);
      const unsubWithdrawals = subscribeToWithdrawals(setWithdrawals);
      const unsubImages = subscribeToSiteImages(setSiteImages);
      const unsubReturns = subscribeToReturns(setReturns);
      
      getSettings().then(setSettings);

      return () => {
        unsubOrders?.();
        unsubProducts?.();
        unsubCategories?.();
        unsubBrands?.();
        unsubCoupons?.();
        unsubUsers?.();
        unsubResellers?.();
        unsubWithdrawals?.();
        unsubImages?.();
        unsubReturns?.();
      };
    }
  }, [user, isUserAdmin]);

  // Handle generic modules
  useEffect(() => {
    if (isUserAdmin && activeTab && !['dashboard', 'products', 'categories', 'brands', 'coupons', 'users', 'customers', 'resellers', 'withdrawals', 'banners', 'website-config', 'orders', 'returns', 'payment-history', 'ui-config', 'settings', 'shipping', 'payments', 'endpoint_test', 'system_metrics', 'activity-logs', 'media-library', 'orders-dashboard', 'payment-gateways', 'shipping-methods', 'pos', 'sales-report', 'low-stock'].includes(activeTab)) {
      const unsub = subscribeToCollection(activeTab.replace(/-/g, '_'), (data) => {
        setGenericData(data);
      });
      return () => unsub?.();
    } else {
      setTimeout(() => {
        if (genericData.length > 0) {
          setGenericData([]);
        }
      }, 0);
    }
  }, [activeTab, isUserAdmin]);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error('Login failed', error);
      showToast('Login failed. Ensure you are an admin.', 'error');
    }
  };

  const adminMenu = [
    {
      group: 'MAIN SYSTEM',
      items: [
        { id: 'dashboard', label: 'ANALYTICS & KPI', icon: LayoutDashboard },
        { id: 'products', label: 'INVENTORY MANAGEMENT', icon: Package },
        { id: 'categories', label: 'TAXONOMY: CATEGORIES', icon: List },
        { id: 'brands', label: 'BRAND DIRECTORY', icon: Shield },
        { id: 'orders', label: 'TRANSACTIONAL ORDERS', icon: ShoppingBag, count: orders.filter(o => o.status === 'pending').length },
        { id: 'payment-history', label: 'FINANCIAL JOURNAL', icon: History },
        { id: 'customers', label: 'USER DATABASE', icon: Users },
        { id: 'resellers', label: 'PARTNER NETWORK', icon: Users },
        { id: 'withdrawals', label: 'PAYOUT QUEUE', icon: CreditCard, count: withdrawals.filter(w => w.status === 'pending').length },
        { id: 'coupons', label: 'PROMOTIONAL ARTIFACTS', icon: Ticket },
        { id: 'returns', label: 'REVERSE LOGISTICS', icon: RefreshCcw, count: returns.filter(r => r.status === 'pending').length },
        { id: 'banners', label: 'VISUAL ASSETS', icon: Image },
        { id: 'blogs', label: 'CONTENT / EDITORIAL', icon: FileText },
        { id: 'low-stock', label: 'CRITICAL STOCK ALERT', icon: Activity, count: lowStockProducts.length },
      ]
    },
    {
      group: 'SYSTEM CORE',
      items: [
        { id: 'ui-config', label: 'INTERFACE BUILDER', icon: Palette },
        { id: 'shipping', label: 'CARRIER MATRIX', icon: Truck },
        { id: 'payments', label: 'GATEWAY CONFIG', icon: CreditCard },
        { id: 'settings', label: 'GLOBAL ENVIRONMENT', icon: Settings },
      ]
    }
  ];


  if (isLoadingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="flex flex-col items-center gap-4">
           <div className="w-12 h-12 border-4 border-primary-100 border-t-primary-700 rounded-full animate-spin"></div>
           <p className="text-sm font-bold text-gray-500 uppercase tracking-widest">Checking auth...</p>
        </div>
      </div>
    );
  }

  const handlePinLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPassword === 'admin247' || adminPassword === '123456') {
      setIsTempAdmin(true);
      localStorage.setItem('isTempAdmin', 'true');
      window.dispatchEvent(new Event('authStatusChanged'));
      showToast('Login successful', 'success');
    } else {
      showToast('Incorrect Admin PIN', 'error');
    }
  };

  if (!isUserAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#fdfdfd] p-4 font-sans relative overflow-hidden">
        {/* Background blobs */}
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[60%] bg-accent/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[60%] bg-[#0f172a]/5 rounded-full blur-[120px] pointer-events-none" />

        <motion.div 
           initial={{ opacity: 0, scale: 0.95 }}
           animate={{ opacity: 1, scale: 1 }}
           className="w-full max-w-md bg-white rounded-[2.5rem] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.1)] border border-gray-100 p-8 sm:p-12 text-center relative z-10"
        >
          <div className="w-20 h-20 bg-primary-950 text-white rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-xl rotate-3 transition-transform hover:rotate-6">
             <Shield className="w-10 h-10" />
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-gray-900 mb-2 tracking-tight uppercase italic underline decoration-accent decoration-4 underline-offset-8">Admin Portal</h1>
          <p className="text-gray-500 mb-8 font-bold tracking-wide uppercase text-[10px]">Secure access only. Authentication required.</p>
          
          <form onSubmit={handlePinLogin} className="space-y-4 mb-6">
             <div className="text-left space-y-2">
                <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest pl-2">Admin PIN / Password</label>
                <div className="relative">
                   <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                      <Lock className="w-5 h-5 text-gray-300" />
                   </div>
                   <input
                     type="password"
                     value={adminPassword}
                     onChange={(e) => setAdminPassword(e.target.value)}
                     className="w-full pl-12 pr-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl focus:ring-2 focus:ring-accent/20 focus:border-accent outline-none transition-all font-mono tracking-widest"
                     placeholder="••••••"
                     required
                   />
                </div>
             </div>
             <button 
                type="submit"
                className="w-full py-4 bg-accent text-white rounded-2xl font-black uppercase tracking-widest hover:bg-accent/90 transition-all shadow-lg hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 flex justify-center items-center gap-2"
             >
                Login to Dashboard <ArrowRight className="w-4 h-4" />
             </button>
          </form>

          <div className="flex items-center gap-4 my-6">
             <div className="h-px bg-gray-100 flex-1"></div>
             <span className="text-[10px] font-black text-gray-300 uppercase tracking-widest">OR</span>
             <div className="h-px bg-gray-100 flex-1"></div>
          </div>

          <div className="space-y-4">
             <button 
                onClick={handleLogin}
                className="w-full py-4 bg-primary-950 text-white rounded-2xl font-black uppercase tracking-widest hover:bg-black transition-all flex items-center justify-center gap-3 shadow-md hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0"
             >
                <Monitor className="w-5 h-5 text-accent" /> Verify via Google
             </button>
             
             <Link 
                to="/"
                className="w-full py-4 bg-gray-50 text-gray-400 rounded-2xl font-black uppercase tracking-widest hover:bg-gray-100 hover:text-gray-600 transition-all flex items-center justify-center gap-3"
             >
                <ArrowRight className="w-5 h-5 rotate-180" /> Storefront
             </Link>
          </div>
          
          <div className="mt-10 pt-6 border-t border-gray-50">
             <p className="text-[9px] font-black text-gray-300 uppercase tracking-[0.2em]">System Version 2.0 • Admin Panel</p>
          </div>
        </motion.div>
      </div>
    );
  }

  const todaysOrders = orders.filter(o => {
    try {
      const date = typeof o.createdAt === 'number' ? new Date(o.createdAt) : new Date(o.createdAt);
      return date.toDateString() === new Date().toDateString();
    } catch (e) {
      return false;
    }
  });
  const todaysRevenue = todaysOrders.reduce((sum, o) => sum + (o.totalAmount || 0), 0);

  // Tab specific configurations
  const tabConfigs: Record<string, {
    title: string,
    description: string,
    fields: { name: string, label: string, type?: string, required?: boolean, options?: {label: string, value: string}[] }[],
    headers: string[]
  }> = {
    'product-types': {
      title: 'Product Types',
      description: 'Manage product category classifications',
      fields: [{ name: 'name', label: 'Type Name', required: true }, { name: 'description', label: 'Description' }],
      headers: ['Type Name', 'Description', 'Created']
    },
    'product-bases': {
      title: 'Product Bases',
      description: 'Define foundational materials or bases',
      fields: [{ name: 'name', label: 'Base Name', required: true }, { name: 'origin', label: 'Origin' }],
      headers: ['Base Name', 'Origin', 'Created']
    },
    'sizes': {
      title: 'Sizes',
      description: 'Standard product dimensions',
      fields: [{ name: 'name', label: 'Size (e.g. XL)', required: true }, { name: 'value', label: 'Measurements' }],
      headers: ['Size', 'Measurements', 'Created']
    },
    'colors': {
      title: 'Colors',
      description: 'Available product color variants',
      fields: [{ name: 'name', label: 'Color Name', required: true }, { name: 'value', label: 'Hex Code (#...)', required: true }],
      headers: ['Color', 'Hex Code', 'Created']
    },
    'weights': {
      title: 'Weights',
      description: 'Standard mass measurements',
      fields: [{ name: 'name', label: 'Weight (e.g. 500g)', required: true }, { name: 'unit', label: 'Unit', required: true }],
      headers: ['Weight', 'Unit', 'Created']
    },
    'badges': {
      title: 'Badges',
      description: 'Product label markers like "Sale", "New"',
      fields: [{ name: 'name', label: 'Badge Name', required: true }, { name: 'color', label: 'Bg Color' }],
      headers: ['Badge', 'Color', 'Created']
    },
    'admins': {
      title: 'Admins',
      description: 'Privileged user accounts',
      fields: [{ name: 'name', label: 'Name', required: true }, { name: 'email', label: 'Email', required: true }, { name: 'role', label: 'Role', options: [{label: 'Super Admin', value: 'super'}, {label: 'Manager', value: 'manager'}] }],
      headers: ['Admin', 'Email', 'Role', 'Created']
    },
    'employees': {
      title: 'Employees',
      description: 'Staff and workforce management',
      fields: [{ name: 'name', label: 'Full Name', required: true }, { name: 'designation', label: 'Designation' }, { name: 'salary', label: 'Monthly Salary', type: 'number' }],
      headers: ['Employee', 'Designation', 'Salary', 'Created']
    },
    'vendors': {
      title: 'Vendors',
      description: 'Supply chain partners',
      fields: [{ name: 'name', label: 'Vendor Name', required: true }, { name: 'contact', label: 'Contact Person' }, { name: 'phone', label: 'Phone' }],
      headers: ['Vendor', 'Contact', 'Phone', 'Created']
    },
    'suppliers': {
      title: 'Suppliers',
      description: 'Raw material suppliers',
      fields: [{ name: 'name', label: 'Supplier Name', required: true }, { name: 'material', label: 'Main Material' }],
      headers: ['Supplier', 'Material', 'Created']
    },
    'banners': {
      title: 'Banners',
      description: 'Home page sliders and banners',
      fields: [{ name: 'name', label: 'Title' }, { name: 'url', label: 'Image URL', required: true }, { name: 'link', label: 'Target Link' }],
      headers: ['Banner', 'Target Link', 'Created']
    },
    'page-banners': {
      title: 'Page Banners',
      description: 'Static banners for specific pages',
      fields: [{ name: 'name', label: 'Page Name' }, { name: 'url', label: 'Image URL', required: true }],
      headers: ['Page', 'Image', 'Created']
    },
    'website-icons': {
      title: 'Website Icons',
      description: 'Logos and favicons',
      fields: [{ name: 'name', label: 'Label' }, { name: 'url', label: 'Icon URL', required: true }],
      headers: ['Icon', 'Label', 'Created']
    },
    'social-media': {
      title: 'Social Media',
      description: 'External link configurations',
      fields: [{ name: 'name', label: 'Platform Name' }, { name: 'url', label: 'Profile URL' }],
      headers: ['Platform', 'Username/Link', 'Created']
    },
    'website-config': {
      title: 'Website Configuration',
      description: 'Global site settings and metadata',
      fields: [
        { name: 'siteName', label: 'Site Name' }, 
        { name: 'siteDescription', label: 'Description', type: 'textarea' }, 
        { name: 'contactEmail', label: 'Contact Email' },
        { name: 'megaCampaignImage', label: 'Mega Campaign Image URL' },
        { name: 'megaCampaignTitle', label: 'Mega Campaign Title' },
        { name: 'megaCampaignUrl', label: 'Mega Campaign Target URL' }
      ],
      headers: ['Site Name', 'Contact Email', 'Created']
    },
    'shipping-methods': {
      title: 'Shipping Methods',
      description: 'Configure delivery zones and costs',
      fields: [{ name: 'name', label: 'Method Name', required: true }, { name: 'cost', label: 'Cost (৳)', type: 'number', required: true }, { name: 'time', label: 'Est. Delivery Time' }],
      headers: ['Method', 'Cost', 'Time', 'Created']
    },
    'taxes': {
      title: 'Tax Settings',
      description: 'Manage VAT and sales tax percentages',
      fields: [{ name: 'name', label: 'Tax Label', required: true }, { name: 'rate', label: 'Rate (%)', type: 'number', required: true }],
      headers: ['Tax Label', 'Rate', 'Created']
    },
    'currencies': {
      title: 'Currencies',
      description: 'System currency and exchange rates',
      fields: [{ name: 'name', label: 'Currency Name', required: true }, { name: 'symbol', label: 'Symbol', required: true }, { name: 'code', label: 'ISO Code (e.g. BDT)', required: true }],
      headers: ['Currency', 'Symbol', 'Code', 'Created']
    },
    'payment-gateways': {
      title: 'Payment Gateways',
      description: 'Configure active checkout bridge',
      fields: [{ name: 'name', label: 'Gateway Name', required: true }, { name: 'type', label: 'Type', options: [{label: 'Manual', value: 'manual'}, {label: 'API', value: 'api'}] }, { name: 'status', label: 'Status', options: [{label: 'Active', value: 'active'}, {label: 'Disabled', value: 'disabled'}] }],
      headers: ['Gateway', 'Type', 'Status', 'Created']
    },
    'sms-config': {
      title: 'SMS Gateway Config',
      description: 'API settings for notification dispatch',
      fields: [{ name: 'provider', label: 'SMS Provider', required: true }, { name: 'apiKey', label: 'API Key' }, { name: 'senderId', label: 'Sender ID' }],
      headers: ['Provider', 'Sender ID', 'Created']
    },
    'abandoned-cart': {
      title: 'Abandoned Carts',
      description: 'Users who left items but did not checkout',
      fields: [{ name: 'email', label: 'User Email' }, { name: 'itemsCount', label: 'Items Price' }, { name: 'lastActivity', label: 'Last Active' }],
      headers: ['Email', 'Value', 'Time', 'Created']
    },
    'invoices': {
      title: 'Digital Invoices',
      description: 'System generated billing documents',
      fields: [{ name: 'invoiceNo', label: 'Invoice #', required: true }, { name: 'customer', label: 'Customer Name' }, { name: 'amount', label: 'Amount', type: 'number' }],
      headers: ['Invoice #', 'Customer', 'Amount', 'Created']
    },
    'qc': {
      title: 'Quality Check Log',
      description: 'Warehouse product inspection history',
      fields: [{ name: 'product', label: 'Product Name' }, { name: 'status', label: 'QC Status', options: [{label: 'Passed', value: 'passed'}, {label: 'Failed', value: 'failed'}] }],
      headers: ['Product', 'Status', 'Date']
    },
    'subscriptions': {
      title: 'Email Subscriptions',
      description: 'Newsletter and alert subscribers',
      fields: [{ name: 'email', label: 'User Email', required: true }],
      headers: ['Email', 'Subscribed At']
    },
    'salaries': {
      title: 'Employee Payroll',
      description: 'Monthly salary disbursement logs',
      fields: [{ name: 'employee', label: 'Employee Name' }, { name: 'amount', label: 'Paid Amount', type: 'number' }, { name: 'month', label: 'Month' }],
      headers: ['Employee', 'Amount', 'Month', 'Paid At']
    },
    'vendor-products': {
      title: 'Vendor Product List',
      description: 'Products supplied by third party vendors',
      fields: [{ name: 'name', label: 'Product Name' }, { name: 'vendor', label: 'Vendor' }, { name: 'stock', label: 'Stock', type: 'number' }],
      headers: ['Product', 'Vendor', 'Stock', 'Created']
    },
    'ads-banners': {
      title: 'Advertisement Units',
      description: 'Promotional banners for sidebars/modals',
      fields: [{ name: 'name', label: 'Ad Title' }, { name: 'url', label: 'Image URL', required: true }, { name: 'link', label: 'Target Link' }],
      headers: ['Ad', 'Image', 'Link', 'Created']
    },
    'brands': {
      title: 'Brands',
      description: 'Manage manufacturer brands',
      fields: [{ name: 'name', label: 'Brand Name', required: true }, { name: 'logo', label: 'Logo URL' }],
      headers: ['Brand', 'Logo', 'Created']
    },
    'purchase-dashboard': {
      title: 'Purchase Records',
      description: 'Inventory purchase history',
      fields: [{ name: 'item', label: 'Item Name' }, { name: 'vendor', label: 'Vendor' }, { name: 'amount', label: 'Amount', type: 'number' }],
      headers: ['Item', 'Vendor', 'Amount', 'Created']
    },
    'blog-posts': {
      title: 'Blog Posts',
      description: 'Manage shop articles',
      fields: [{ name: 'title', label: 'Post Title', required: true }, { name: 'image', label: 'Feature Image' }, { name: 'excerpt', label: 'Short Description' }],
      headers: ['Title', 'Created']
    },
    'menus': {
      title: 'Appearance Menus',
      description: 'Manage navigation link groups',
      fields: [{ name: 'name', label: 'Menu Name', required: true }, { name: 'items', label: 'Menu Items (JSON)' }],
      headers: ['Menu', 'Created']
    },
    'addresses': {
      title: 'Global Addresses',
      description: 'Manage warehouse and office locations',
      fields: [{ name: 'name', label: 'Location Name', required: true }, { name: 'address', label: 'Full Address' }, { name: 'phone', label: 'Phone' }],
      headers: ['Location', 'Address', 'Phone', 'Created']
    },
    'about-page': {
      title: 'About Page Config',
      description: 'Manage "About Us" page content',
      fields: [{ name: 'title', label: 'Section Title' }, { name: 'content', label: 'Body Content', type: 'textarea' }, { name: 'image', label: 'Feature Image' }],
      headers: ['Section', 'Created']
    },
    'career-page': {
      title: 'Career Page Config',
      description: 'Manage recruitment page branding',
      fields: [{ name: 'title', label: 'Hero Title' }, { name: 'description', label: 'Intro Text' }, { name: 'banner', label: 'Hero Banner' }],
      headers: ['Title', 'Created']
    },
    'our-team': {
      title: 'Our Team',
      description: 'Manage company staff profiles',
      fields: [{ name: 'name', label: 'Member Name', required: true }, { name: 'role', label: 'Position' }, { name: 'image', label: 'Photo URL' }],
      headers: ['Member', 'Position', 'Created']
    },
    'trusted-by': {
      title: 'Partners & Clients',
      description: 'Logos for the "Trusted By" section',
      fields: [{ name: 'name', label: 'Partner Name' }, { name: 'logo', label: 'Logo URL', required: true }],
      headers: ['Partner', 'Logo', 'Created']
    },
    'careers': {
      title: 'Job Openings',
      description: 'Manage active career opportunities',
      fields: [{ name: 'title', label: 'Job Title', required: true }, { name: 'department', label: 'Department' }, { name: 'status', label: 'Status', options: [{label: 'Open', value: 'open'}, {label: 'Closed', value: 'closed'}] }],
      headers: ['Job Title', 'Department', 'Status', 'Created']
    },
    'social_links': {
      title: 'Social Media Links',
      description: 'Connect your brand profiles',
      fields: [{ name: 'platform', label: 'Platform' }, { name: 'url', label: 'Profile URL' }],
      headers: ['Platform', 'Link', 'Created']
    },
    'blog_posts_management': {
      title: 'Blog Management',
      description: 'Create and edit news articles',
      fields: [{ name: 'title', label: 'Title', required: true }, { name: 'image', label: 'Thumbnail URL' }, { name: 'excerpt', label: 'Short Intro' }],
      headers: ['Article', 'Introduction', 'Created']
    },
    'component-types': {
      title: 'Component Library',
      description: 'Manage specialized UI blocks',
      fields: [{ name: 'type', label: 'Type Name' }, { name: 'category', label: 'Category' }],
      headers: ['Type', 'Category', 'Created']
    },
    'banner-pages': {
      title: 'Banner Mapping',
      description: 'Assign banners to site locations',
      fields: [{ name: 'page', label: 'Target Page' }, { name: 'bannerId', label: 'Banner ID' }],
      headers: ['Page', 'Banner ID', 'Created']
    },
    'stock-adjustment': {
      title: 'Stock Corrections',
      description: 'Audit manual inventory changes',
      fields: [{ name: 'product', label: 'Product' }, { name: 'quantity', label: 'Change (+/-)', type: 'number' }, { name: 'reason', label: 'Reason' }],
      headers: ['Product', 'Adjustment', 'Reason', 'Date']
    },
    'contact-settings': {
      title: 'Contact Config',
      description: 'Business contact details mapping',
      fields: [{ name: 'type', label: 'Type (e.g. Support Phone)' }, { name: 'value', label: 'Contact Information' }],
      headers: ['Type', 'Detail', 'Created']
    },
    'vendor_registry': {
      title: 'Vendor Registry',
      description: 'Manage third-party marketplace sellers',
      fields: [{ name: 'name', label: 'Vendor Name' }, { name: 'email', label: 'Business Email' }, { name: 'phone', label: 'Contact Phone' }],
      headers: ['Vendor', 'Email', 'Phone', 'Created']
    },
    'vendor_inventory': {
      title: 'Vendor Inventory',
      description: 'Products assigned to specific vendors',
      fields: [{ name: 'productName', label: 'Product' }, { name: 'vendorName', label: 'Vendor' }, { name: 'commission', label: 'Commission (%)', type: 'number' }],
      headers: ['Product', 'Vendor', 'Commission', 'Created']
    },
    'vendor-analytics': {
      title: 'Vendor Performance',
      description: 'Sales and payout tracking per vendor',
      fields: [{ name: 'vendor', label: 'Vendor' }, { name: 'sales', label: 'Total Sales', type: 'number' }, { name: 'payout', label: 'Pending Payout', type: 'number' }],
      headers: ['Vendor', 'Sales', 'Payout', 'Created']
    },
    'vendor-config': {
      title: 'Vendor Settings',
      description: 'Global vendor policies and commissions',
      fields: [{ name: 'defaultCommission', label: 'Default Commission (%)', type: 'number' }, { name: 'autoApprove', label: 'Auto Approve Vendors', options: [{label: 'Yes', value: 'yes'}, {label: 'No', value: 'no'}] }],
      headers: ['Default Commission', 'Auto Approve', 'Created']
    },
    'purchase_audit': {
      title: 'Purchase Audit',
      description: 'Track all stock procurement events',
      fields: [{ name: 'orderId', label: 'PO Number' }, { name: 'supplier', label: 'Supplier' }, { name: 'totalAmount', label: 'Total Cost', type: 'number' }],
      headers: ['PO #', 'Supplier', 'Cost', 'Date']
    },
    'create-purchase': {
      title: 'Stock Acquisition',
      description: 'Log new inventory arrivals',
      fields: [{ name: 'item', label: 'Item Name' }, { name: 'qty', label: 'Received Qty', type: 'number' }, { name: 'cost', label: 'Unit Cost', type: 'number' }],
      headers: ['Item', 'Qty', 'Unit Cost', 'Created']
    },
    'approved-purchases': {
      title: 'Approved POs',
      description: 'Purchases verified by warehouse managers',
      fields: [{ name: 'orderId', label: 'Order ID' }, { name: 'approver', label: 'Approved By' }],
      headers: ['Order ID', 'Approver', 'Created']
    },
    'purchased': {
      title: 'Completed Purchases',
      description: 'Stock successfully added to inventory',
      fields: [{ name: 'item', label: 'Item' }, { name: 'finalCost', label: 'Final Cost', type: 'number' }],
      headers: ['Item', 'Final Cost', 'Created']
    },
    'material_suppliers': {
      title: 'Material Suppliers',
      description: 'Raw material and base providers',
      fields: [{ name: 'name', label: 'Supplier' }, { name: 'speciality', label: 'Speciality' }],
      headers: ['Supplier', 'Speciality', 'Created']
    },
    'customer-report': {
      title: 'Customer Analytics',
      description: 'User engagement and lifetime value reports',
      fields: [{ name: 'customer', label: 'Customer Name' }, { name: 'orders', label: 'Order Count', type: 'number' }, { name: 'spent', label: 'Total Spent', type: 'number' }],
      headers: ['Customer', 'Orders', 'Spent', 'Created']
    },
    'product-report': {
      title: 'Inventory Performance',
      description: 'Moving speed and stock rotation analytics',
      fields: [{ name: 'product', label: 'Product' }, { name: 'views', label: 'Views', type: 'number' }, { name: 'sales', label: 'Sales Volume', type: 'number' }],
      headers: ['Product', 'Views', 'Sales', 'Created']
    },
    'activity-logs': {
      title: 'System Activity',
      description: 'Audit trail for all administrative actions',
      fields: [{ name: 'admin', label: 'Admin User' }, { name: 'action', label: 'Action Performed' }, { name: 'details', label: 'Details' }],
      headers: ['Admin', 'Action', 'Details', 'Timestamp']
    }
  };

  const currentConfig = tabConfigs[activeTab] || {
    title: activeTab.replace(/-/g, ' '),
    description: `Manage ${activeTab.replace(/-/g, ' ')} modules`,
    fields: [{ name: 'name', label: 'Name', required: true }, { name: 'description', label: 'Description' }],
    headers: ['Name', 'Details', 'Created']
  };

  return (
    <div className="flex h-screen bg-[#FBFBFB] overflow-hidden font-sans text-[#1A1A1A]">
      {/* Sidebar - Desktop & Mobile */}
      <aside 
        className={`fixed inset-y-0 left-0 z-50 w-72 bg-white border-r border-[#E5E5E5] transform transition-transform duration-300 ease-in-out md:relative md:translate-x-0 ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} flex flex-col flex-shrink-0 shadow-2xl md:shadow-none bg-white`}
      >
        <div className="h-20 flex items-center px-8 border-b border-[#F0F0F0] justify-between sticky top-0 z-20 bg-white">
          <Link to="/" className="flex items-center gap-4 group">
            <div className="flex items-center justify-center w-10 h-10 bg-black text-white rounded-xl shadow-lg font-black text-xl transition-transform group-hover:rotate-12">
               {settings?.siteName?.[0] || 'K'}
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-black tracking-tighter leading-none uppercase">{settings?.siteName?.split(' ')[0] || 'KHOLOS'}</span>
              <span className="text-[9px] font-bold text-gray-400 uppercase tracking-[0.3em] mt-1.5 flex items-center gap-2">
                 <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse"></span>
                 CORE ENGINE
              </span>
            </div>
          </Link>
          <button className="md:hidden p-2 hover:bg-gray-100 rounded-xl transition-all" onClick={() => setIsSidebarOpen(false)}>
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto no-scrollbar scroll-smooth bg-white">
          <div className="px-6 py-10 space-y-10">
            {adminMenu.map((group, idx) => (
              <div key={idx} className="space-y-4">
                <p className="px-2 text-[10px] font-black text-gray-400 uppercase tracking-[0.3em]">{group.group}</p>
                <nav className="space-y-1">
                  {group.items.map((item) => (
                    <button 
                      key={item.id}
                      onClick={() => {
                        navigate(`/dashboard/${item.id}`);
                        if (window.innerWidth < 768) setIsSidebarOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3 py-3 rounded-xl text-xs transition-all group relative ${activeTab === item.id ? 'bg-black text-white shadow-xl' : 'text-gray-500 hover:bg-[#F5F5F7] hover:text-black font-bold'}`}
                    >
                      <div className="flex items-center gap-3 relative z-10">
                        <item.icon className={`w-4 h-4 transition-transform duration-500 ${activeTab === item.id ? 'scale-110' : 'group-hover:scale-110'}`} strokeWidth={activeTab === item.id ? 2.5 : 2} />
                        <span className="tracking-tight font-black uppercase text-[10px]">{item.label}</span>
                      </div>
                      {item.count !== undefined && item.count > 0 && (
                        <span className={`text-[9px] font-black px-2 py-0.5 rounded-lg relative z-10 shadow-sm ${activeTab === item.id ? 'bg-accent text-white' : 'bg-accent/10 text-accent'}`}>
                          {item.count}
                        </span>
                      )}
                    </button>
                  ))}
                </nav>
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 border-t border-[#F0F0F0] bg-white">
           <button 
             onClick={handleLogout}
             className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-red-500 hover:bg-red-50 transition-all font-black text-[11px] uppercase tracking-wider"
           >
             <LogOut className="w-4 h-4" /> Sign Out System
           </button>
        </div>
      </aside>

      {/* Overlay for mobile sidebar */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 md:hidden" 
            onClick={() => setIsSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden bg-[#FBFBFB]">
        {/* Modern Top Header */}
        <header className="h-20 bg-white border-b border-[#E5E5E5] flex items-center justify-between px-6 sm:px-10 relative z-30 flex-shrink-0">
          <div className="flex items-center gap-6">
            <div className="flex flex-col">
               <h2 className="text-sm font-black text-gray-900 uppercase tracking-widest flex items-center gap-3">
                  {activeTab.replace(/-/g, ' ')}
               </h2>
               <div className="flex items-center gap-2 mt-1">
                  <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Kholos</span>
                  <span className="text-gray-300">/</span>
                  <span className="text-[9px] font-bold text-accent uppercase tracking-widest">v2.0.4-LTS</span>
               </div>
            </div>
          </div>
          
          <div className="flex items-center gap-6">
            <div className="hidden lg:flex items-center gap-4 px-4 py-2 bg-[#F5F5F7] rounded-xl border border-[#E5E5E5]">
               <Activity className="w-4 h-4 text-green-500" />
               <div className="flex flex-col">
                  <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">System Status</span>
                  <span className="text-[10px] font-black text-gray-900 uppercase">Operational</span>
               </div>
            </div>

            <Link to="/" className="hidden lg:flex items-center gap-2 px-6 py-2.5 bg-black text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-gray-900 transition-all shadow-lg active:scale-95">
               <ExternalLink className="w-4 h-4" /> Open Shop
            </Link>

            <div className="flex items-center gap-3 pl-6 border-l border-[#E5E5E5]">
               <div className="text-right hidden sm:block">
                  <p className="text-[10px] font-black text-gray-900 uppercase tracking-widest">{user?.email?.split('@')[0] || 'Admin'}</p>
                  <p className="text-[9px] font-black text-accent uppercase tracking-[0.2em]">Verified</p>
               </div>
               <div className="h-10 w-10 rounded-xl border-2 border-white shadow-md overflow-hidden bg-gray-100">
                <img src={user?.photoURL || `https://ui-avatars.com/api/?name=${user?.email}&background=000&color=fff`} className="w-full h-full object-cover" alt="" />
              </div>
            </div>
          </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 sm:p-10 no-scrollbar">
          <div className="w-full max-w-[1440px] mx-auto">
            
            {activeTab === 'dashboard' && (
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-10"
              >
                {/* Admin Hero Section */}
                <div className="bg-gradient-to-r from-primary-950 to-primary-900 rounded-[3rem] p-10 md:p-14 text-white shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-accent/20 rounded-full blur-[80px] -mr-20 -mt-20 pointer-events-none"></div>
                  <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-white/5 rounded-full blur-[60px] -ml-20 -mb-20 pointer-events-none"></div>
                  <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8 text-center md:text-left">
                     <div>
                       <h1 className="text-3xl md:text-5xl font-black mb-4 tracking-tight">Welcome back, Admin! 👋</h1>
                       <p className="text-primary-100/80 font-bold text-lg max-w-xl">
                          Here's what's happening with your store today. You have <span className="text-accent">{orders.filter(o => o.status === 'pending').length} pending</span> orders waiting for your attention.
                       </p>
                     </div>
                     <div className="flex flex-col sm:flex-row gap-4 shrink-0">
                        <button onClick={() => navigate('/dashboard/products/add')} className="px-8 py-4 bg-accent text-primary-950 font-black rounded-2xl uppercase tracking-widest text-[10px] hover:bg-white transition-all shadow-[0_10px_30px_rgba(251,191,36,0.3)] hover:-translate-y-1">Add Product</button>
                        <button onClick={() => navigate('/dashboard/orders')} className="px-8 py-4 bg-white/10 backdrop-blur-sm border border-white/20 text-white font-black rounded-2xl uppercase tracking-widest text-[10px] hover:bg-white/20 transition-all hover:-translate-y-1">View Orders</button>
                     </div>
                  </div>
                </div>

                {/* Modern Stats Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { label: 'Total Sales', value: `৳${orders.reduce((sum, o) => sum + (o.totalAmount || 0), 0).toLocaleString()}`, icon: Banknote, color: 'bg-primary-950 text-white', iconColor: 'bg-white/10 text-accent', trend: '+12%', sub: 'Total Revenue' },
                    { label: 'Total Orders', value: orders.length, icon: ShoppingBag, color: 'bg-white', iconColor: 'bg-blue-50 text-blue-600', trend: '+5%', sub: 'Lifetime volume' },
                    { label: 'Total Customers', value: customers.length, icon: Users, color: 'bg-white', iconColor: 'bg-indigo-50 text-indigo-600', trend: '+18%', sub: 'Active users' },
                    { label: 'Total Products', value: products.length, icon: Package, color: 'bg-white', iconColor: 'bg-emerald-50 text-emerald-600', trend: 'Stable', sub: 'In inventory' },
                  ].map((stat, i) => (
                    <motion.div 
                      key={i}
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.1 }}
                      className={`${stat.color} rounded-3xl p-8 shadow-[0_10px_30px_-10px_rgba(0,0,0,0.05)] border border-gray-100 flex flex-col justify-between group hover:-translate-y-1 transition-all duration-300`}
                    >
                      <div className="flex items-center justify-between mb-6">
                         <div className={`p-3 rounded-2xl ${stat.iconColor}`}>
                            <stat.icon className="w-6 h-6" />
                         </div>
                         <div className={`text-[9px] font-black uppercase tracking-widest px-2 py-1 rounded-full ${i === 0 ? 'bg-accent/20 text-accent' : 'bg-gray-50 text-gray-400'}`}>
                             {stat.trend}
                         </div>
                      </div>
                      <div>
                        <p className={`text-[10px] font-black uppercase tracking-[0.2em] mb-1 ${i === 0 ? 'text-white/40' : 'text-gray-400'}`}>{stat.label}</p>
                        <h3 className={`text-3xl font-black tracking-tight ${i === 0 ? 'text-white' : 'text-gray-900'}`}>{stat.value}</h3>
                        <p className={`text-[9px] font-bold mt-2 ${i === 0 ? 'text-white/30' : 'text-gray-300'} uppercase tracking-widest`}>{stat.sub}</p>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {[
                    { label: 'Today Revenue', value: `৳${todaysRevenue.toLocaleString()}`, icon: TrendingUp, color: 'bg-white', iconColor: 'bg-green-50 text-green-600', sub: 'Real-time sales' },
                    { label: 'Withdrawals', value: withdrawals.filter(w => w.status === 'pending').length, icon: CreditCard, color: 'bg-white', iconColor: 'bg-pink-50 text-pink-600', sub: 'Pending requests' },
                    { label: 'Return Requests', value: returns.filter(r => r.status === 'pending').length, icon: XCircle, color: 'bg-white', iconColor: 'bg-red-50 text-red-600', sub: 'Urgent returns' },
                    { label: 'Stock Alerts', value: lowStockProducts.length, icon: Package, color: 'bg-white', iconColor: 'bg-amber-50 text-amber-600', sub: 'Low inventory items' },
                  ].map((stat, i) => (
                    <div key={i} className="bg-white rounded-3xl p-6 border border-gray-100 shadow-sm flex items-center gap-5">
                       <div className={`w-14 h-14 rounded-2xl ${stat.iconColor} flex items-center justify-center shrink-0`}>
                          <stat.icon className="w-6 h-6" />
                       </div>
                       <div>
                          <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest">{stat.label}</p>
                          <h4 className="text-xl font-black text-gray-900">{stat.value}</h4>
                          <p className="text-[8px] font-bold text-gray-300 uppercase mt-0.5">{stat.sub}</p>
                       </div>
                    </div>
                  ))}
                </div>

                 {/* Main Content Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
                   {/* Sales Chart Card */}
                   <div className="lg:col-span-8 bg-white rounded-[2.5rem] border border-gray-100 shadow-[0_10px_40px_-5px_rgba(0,0,0,0.03)] overflow-hidden flex flex-col">
                     <div className="p-8 pb-0 flex items-center justify-between">
                       <div>
                         <h3 className="font-black text-gray-900 text-2xl tracking-tight">Revenue Analytics</h3>
                         <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">Growth performance metrics</p>
                       </div>
                       <select className="bg-gray-50 border-none rounded-xl text-xs font-black px-4 py-2.5 outline-none focus:ring-4 focus:ring-primary-500/10 cursor-pointer">
                          <option>Last 7 Days</option>
                          <option>Last 30 Days</option>
                       </select>
                     </div>
                     <div className="p-8 pb-4 flex-1 min-h-[400px]">
                       <ResponsiveContainer width="100%" height="100%">
                         <AreaChart data={[
                           {name: "Mon", sales: 4200}, {name: "Tue", sales: 3800}, {name: "Wed", sales: 5600}, 
                           {name: "Thu", sales: 4800}, {name: "Fri", sales: 7200}, {name: "Sat", sales: 6400}, {name: "Sun", sales: 8900}
                         ]}>
                           <defs>
                             <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                               <stop offset="5%" stopColor="#0f172a" stopOpacity={0.15}/>
                               <stop offset="95%" stopColor="#0f172a" stopOpacity={0}/>
                             </linearGradient>
                           </defs>
                           <CartesianGrid strokeDasharray="10 10" vertical={false} stroke="#f1f5f9" />
                           <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: "#94a3b8", fontSize: 10, fontWeight: 800, textAnchor: 'middle'}} dy={15} />
                           <YAxis axisLine={false} tickLine={false} tick={{fill: "#94a3b8", fontSize: 10, fontWeight: 800}} dx={-10} tickFormatter={(val) => `৳${val/1000}k`}/>
                           <Tooltip 
                             contentStyle={{borderRadius: "24px", border: "none", boxShadow: "0 20px 50px -10px rgba(0,0,0,0.1)", padding: "16px"}}
                             itemStyle={{color: "#0f172a", fontWeight: "900", fontSize: "16px"}}
                             cursor={{ stroke: '#0f172a', strokeWidth: 2, strokeDasharray: '5 5' }}
                           />
                           <Area type="monotone" dataKey="sales" stroke="#0f172a" strokeWidth={5} fillOpacity={1} fill="url(#colorSales)" animationDuration={2000} />
                         </AreaChart>
                       </ResponsiveContainer>
                     </div>
                   </div>

                   {/* Distribution Chart Card */}
                   <div className="lg:col-span-4 bg-white rounded-[2.5rem] border border-gray-100 shadow-[0_10px_40px_-5px_rgba(0,0,0,0.03)] p-10 flex flex-col">
                      <div className="mb-10 text-center lg:text-left">
                        <h3 className="font-black text-gray-900 text-xl tracking-tight">Stock Distribution</h3>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Inventory weightage by category</p>
                      </div>
                      <div className="flex-1 min-h-[300px]">
                        <ResponsiveContainer width="100%" height="100%">
                          <RePieChart>
                            <Pie
                              data={categories.map(c => ({
                                name: c.name,
                                value: products.filter(p => p.category === c.name).length
                              })).filter(d => d.value > 0).slice(0, 5)}
                              cx="50%"
                              cy="50%"
                              stroke="none"
                              innerRadius={60}
                              outerRadius={100}
                              paddingAngle={8}
                              dataKey="value"
                            >
                              {categories.map((_, index) => (
                                <Cell key={`cell-${index}`} fill={['#0f172a', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'][index % 6]} />
                              ))}
                            </Pie>
                            <Tooltip 
                               contentStyle={{borderRadius: "16px", border: "none", boxShadow: "0 10px 30px rgba(0,0,0,0.05)", fontSize: "12px", fontWeight: "900"}}
                            />
                          </RePieChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="mt-8 space-y-3">
                         {categories.map(c => ({
                            name: c.name,
                            count: products.filter(p => p.category === c.name).length
                         })).filter(d => d.count > 0).slice(0, 4).map((cat, i) => (
                            <div key={i} className="flex items-center justify-between">
                               <div className="flex items-center gap-3">
                                  <div className={`w-3 h-3 rounded-full ${['bg-[#0f172a]', 'bg-blue-500', 'bg-emerald-500', 'bg-amber-500'][i % 4]}`}></div>
                                  <span className="text-xs font-black text-gray-500 uppercase tracking-tight">{cat.name}</span>
                               </div>
                               <span className="text-xs font-black text-gray-900">{cat.count} Units</span>
                            </div>
                         ))}
                      </div>
                   </div>
                </div>

                {/* Quick Actions & Top Products */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 mt-10">
                   {/* Top Selling Products */}
                   <div className="lg:col-span-8 bg-white rounded-[2.5rem] border border-gray-100 shadow-[0_10px_40px_-5px_rgba(0,0,0,0.03)] p-10">
                      <div className="flex items-center justify-between mb-10">
                         <div>
                            <h3 className="font-black text-gray-900 text-xl tracking-tight">Top Selling Products</h3>
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Based on recent order volume</p>
                         </div>
                         <Link to="/dashboard/products" className="text-[10px] font-black text-primary-700 uppercase tracking-widest hover:underline px-4 py-2 bg-primary-50 rounded-full">View All</Link>
                      </div>
                      <div className="space-y-6">
                         {products.slice(0, 5).map((product, i) => (
                            <div key={i} className="flex items-center justify-between group">
                               <div className="flex items-center gap-4">
                                  <div className="w-12 h-12 rounded-xl border border-gray-100 overflow-hidden bg-gray-50 shrink-0">
                                     <img src={product.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                                  </div>
                                  <div>
                                     <p className="text-sm font-black text-gray-900 group-hover:text-primary-700 transition-colors">{product.name}</p>
                                     <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{product.category}</p>
                                  </div>
                               </div>
                               <div className="text-right">
                                  <p className="text-sm font-black text-gray-900">৳{product.price.toLocaleString()}</p>
                                  <p className="text-[10px] text-emerald-500 font-black uppercase tracking-tight">Active</p>
                               </div>
                            </div>
                         ))}
                      </div>
                   </div>

                   {/* Quick Actions Bar */}
                   <div className="lg:col-span-4 space-y-10">
                      <div className="bg-primary-950 rounded-[2.5rem] p-10 text-white shadow-2xl relative overflow-hidden">
                         <div className="absolute top-0 right-0 w-32 h-32 bg-accent/20 rounded-full blur-[60px] -mr-16 -mt-16"></div>
                         <h3 className="font-black text-xl mb-6 tracking-tight">Quick Actions</h3>
                         <div className="grid grid-cols-2 gap-4">
                            {[
                               { label: 'Add Product', icon: Package, tab: 'products', action: '/dashboard/products/add' },
                               { label: 'Orders', icon: ShoppingBag, tab: 'orders' },
                               { label: 'Coupons', icon: Ticket, tab: 'coupons' },
                               { label: 'Customers', icon: Users, tab: 'customers' },
                               { label: 'Settings', icon: Settings, tab: 'settings' }
                            ].map((action, i) => (
                               <button 
                                  key={i} 
                                  onClick={() => {
                                     if (action.action) navigate(action.action);
                                     else navigate(`/dashboard/${action.tab}`);
                                  }}
                                  className="flex flex-col items-center justify-center p-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl transition-all active:scale-95 group"
                               >
                                  <action.icon className="w-6 h-6 text-accent mb-2 group-hover:scale-110 transition-transform" />
                                  <span className="text-[9px] font-black uppercase tracking-widest opacity-60 group-hover:opacity-100">{action.label}</span>
                               </button>
                            ))}
                         </div>
                      </div>

                      {/* Recent Customers Widget */}
                      <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-[0_10px_40px_-5px_rgba(0,0,0,0.03)] p-8">
                         <h3 className="font-black text-gray-900 text-lg mb-6 tracking-tight">Recent Customers</h3>
                         <div className="space-y-4">
                            {customers.slice(0, 4).map((customer, i) => (
                               <div key={i} className="flex items-center gap-4">
                                  <div className="w-10 h-10 rounded-full bg-primary-50 text-primary-700 flex items-center justify-center font-black text-xs">
                                     {customer.displayName?.charAt(0) || 'U'}
                                  </div>
                                  <div className="flex-1 overflow-hidden">
                                     <p className="text-xs font-black text-gray-900 truncate">{customer.displayName || 'Anonymous User'}</p>
                                     <p className="text-[9px] text-gray-400 font-bold uppercase tracking-widest truncate">{customer.email}</p>
                                  </div>
                               </div>
                            ))}
                         </div>
                      </div>
                   </div>
                </div>

                {/* Secondary Content Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
                   {/* Sidebar Control Widget (Re-using some existing logic but making it cleaner) */}
                   <div className="lg:col-span-4 space-y-10">
                     {lowStockProducts.length > 0 && (
                       <div className="bg-red-50 border border-red-100 rounded-[2.5rem] p-8">
                          <div className="flex items-center gap-3 text-red-600 mb-6">
                             <Package className="w-6 h-6 animate-bounce" />
                             <h4 className="font-black text-sm uppercase tracking-widest">Inventory Alerts</h4>
                          </div>
                          <div className="space-y-4">
                             {lowStockProducts.slice(0, 3).map(p => (
                               <div key={p.id} className="flex items-center justify-between">
                                  <span className="text-xs font-bold text-gray-700 truncate max-w-[150px]">{p.name}</span>
                                  <span className="text-[10px] font-black px-2 py-1 bg-red-100 text-red-700 rounded-lg">{p.stock} left</span>
                               </div>
                             ))}
                          </div>
                          <button onClick={() => navigate('/dashboard/products')} className="w-full mt-6 py-3 bg-red-600 text-white text-[10px] font-black uppercase tracking-[0.2em] rounded-xl hover:bg-red-700 transition-all">
                             Restock Now
                          </button>
                       </div>
                     )}

                     <div className="bg-[#0f172a] rounded-[2.5rem] p-8 text-white relative overflow-hidden shadow-2xl group">
                        <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-700">
                           <LayoutDashboard className="w-40 h-40" />
                        </div>
                        <div className="relative z-10">
                           <h3 className="text-2xl font-black mb-2 tracking-tight">System Status</h3>
                           <p className="text-white/40 text-[10px] font-bold uppercase tracking-[0.2em] mb-10">Cloud synchronization live</p>
                           
                           <div className="space-y-6">
                              {[
                                { label: 'Server Load', level: '14%', color: 'bg-green-500' },
                                { label: 'Auth Health', level: '99.9%', color: 'bg-accent' },
                                { label: 'Storage Usage', level: '2.4GB', color: 'bg-blue-500' },
                              ].map((sys, i) => (
                                <div key={i} className="space-y-2">
                                   <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-white/60">
                                      <span>{sys.label}</span>
                                      <span>{sys.level}</span>
                                   </div>
                                   <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                                      <motion.div 
                                        initial={{ width: 0 }}
                                        animate={{ width: i === 0 ? '14%' : i === 1 ? '99.9%' : '35%' }}
                                        transition={{ duration: 1.5, delay: i * 0.2 }}
                                        className={`h-full ${sys.color}`}
                                      />
                                   </div>
                                </div>
                              ))}
                           </div>
                           <button className="w-full mt-10 py-4 bg-white/5 hover:bg-white/10 border border-white/10 rounded-2xl text-xs font-black uppercase tracking-widest transition-all active:scale-[0.98]">
                              Refresh Metrics
                           </button>
                        </div>
                     </div>

                     <div className="grid grid-cols-2 gap-4">
                        {[
                          { label: 'Add Product', icon: Package, path: '/dashboard/products/add', bg: 'bg-blue-50', text: 'text-blue-600' },
                          { label: 'Review List', icon: Star, path: '/dashboard/reviews', bg: 'bg-amber-50', text: 'text-amber-600' },
                          { label: 'Configure UI', icon: Image, path: '/dashboard/banners', bg: 'bg-purple-50', text: 'text-purple-600' },
                          { label: 'View Analytics', icon: TrendingUp, path: '/dashboard/dashboard', bg: 'bg-green-50', text: 'text-green-600' },
                        ].map((btn, i) => (
                          <button 
                            key={i}
                            onClick={() => navigate(btn.path)}
                            className={`flex flex-col items-center justify-center p-6 bg-white rounded-[2rem] border border-gray-100 hover:shadow-xl transition-all group scale-hover`}
                          >
                             <div className={`p-3 rounded-xl mb-3 ${btn.bg} ${btn.text} group-hover:scale-110 transition-transform`}>
                                <btn.icon className="w-5 h-5" />
                             </div>
                             <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest text-center">{btn.label}</span>
                          </button>
                        ))}
                     </div>
                   </div>
                </div>

                {/* Performance Table Section */}
                <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-[0_10px_40px_-5px_rgba(0,0,0,0.03)] overflow-hidden">
                   <div className="p-8 border-b border-gray-50 flex items-center justify-between">
                      <div>
                        <h3 className="font-black text-gray-900 text-2xl tracking-tight">Recent Transactions</h3>
                        <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">Live order feed system</p>
                      </div>
                      <button onClick={() => navigate("/dashboard/orders")} className="flex items-center gap-2 px-6 py-3 bg-gray-900 text-white rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-black transition-all active:scale-95 shadow-lg">
                        See All Activity <ArrowRight className="w-4 h-4" />
                      </button>
                   </div>
                    <div className="overflow-x-auto no-scrollbar">
                      <table className="w-full text-left whitespace-nowrap">
                        <thead className="bg-[#f8fafc] text-gray-400 text-[10px] font-black uppercase tracking-[0.25em] border-b border-gray-100">
                          <tr>
                            <th className="px-10 py-6">Transaction ID</th>
                            <th className="px-10 py-6">Customer</th>
                            <th className="px-10 py-6">Method</th>
                            <th className="px-10 py-6">Created At</th>
                            <th className="px-10 py-6 text-right">Value</th>
                            <th className="px-10 py-6 text-center">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50 capitalize font-bold">
                          {orders.slice(0, 8).map((order) => (
                            <tr key={order.id} className="hover:bg-gray-50/50 transition-all group cursor-pointer" onClick={() => {
                              setSelectedOrder(order);
                              navigate("/dashboard/orders");
                            }}>
                              <td className="px-10 py-8">
                                 <div className="flex items-center gap-3">
                                   <div className={`w-2 h-2 rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)] ${
                                     order.status === 'delivered' ? 'bg-green-500 shadow-green-500/50' : 
                                     order.status === 'pending' ? 'bg-amber-500 shadow-amber-500/50' :
                                     'bg-blue-500 shadow-blue-500/50'
                                   }`}></div>
                                   <span className="font-mono text-[11px] font-black text-gray-900 bg-gray-100 px-3 py-1.5 rounded-lg border border-gray-200">
                                     #{order.shortId || order.id.slice(-8).toUpperCase()}
                                   </span>
                                 </div>
                              </td>
                              <td className="px-10 py-8">
                                <div className="flex items-center gap-4">
                                   <div className="w-10 h-10 bg-[#0f172a] rounded-xl flex items-center justify-center text-white font-black text-sm shadow-md transition-transform group-hover:scale-110">
                                     {order.customerName?.[0]}
                                   </div>
                                   <div>
                                     <div className="font-black text-gray-900 text-sm group-hover:text-blue-600 transition-colors">{order.customerName}</div>
                                     <div className="text-[10px] font-bold text-gray-400 uppercase tracking-tight">{order.customerPhone}</div>
                                   </div>
                                </div>
                              </td>
                              <td className="px-10 py-8">
                                 <span className={`text-[10px] font-black uppercase px-3 py-1 rounded-full ${order.paymentMethod === 'bkash' ? 'bg-pink-50 text-pink-600' : 'bg-slate-100 text-slate-600'}`}>
                                   {order.paymentMethod || 'COD'}
                                 </span>
                              </td>
                              <td className="px-10 py-8 text-gray-400 font-bold text-xs uppercase tracking-tight">
                                 {new Date(order.createdAt).toLocaleString(undefined, { day: '2-digit', month: 'short', year: 'numeric' })}
                              </td>
                              <td className="px-10 py-8 font-black text-gray-900 text-right text-lg">৳{order.totalAmount?.toLocaleString()}</td>
                              <td className="px-10 py-8">
                                 <div className="flex justify-center">
                                   <span className={`text-[10px] font-black uppercase tracking-[0.2em] px-5 py-2.5 rounded-2xl shadow-inner border transition-colors ${
                                     order.status === "delivered" ? "bg-green-50 text-green-700 border-green-100 group-hover:bg-green-100" : 
                                     order.status === "pending" ? "bg-amber-50 text-amber-700 border-amber-100 group-hover:bg-amber-100" :
                                     order.status === "shipped" ? "bg-blue-50 text-blue-700 border-blue-100 group-hover:bg-blue-100" :
                                     "bg-red-50 text-red-700 border-red-100 group-hover:bg-red-100"
                                   }`}>
                                     {order.status || "Pending"}
                                   </span>
                                 </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                </div>
              </motion.div>
            )}

            {/* Dynamic Administrative Modules */}
            {activeTab !== 'dashboard' && !['blogs', 'dashboard', 'products', 'categories', 'brands', 'coupons', 'users', 'customers', 'resellers', 'withdrawals', 'banners', 'website-config', 'orders', 'returns', 'payment-history', 'ui-config', 'settings', 'shipping', 'payments', 'endpoint_test', 'system_metrics', 'activity-logs', 'media-library', 'orders-dashboard', 'payment-gateways', 'shipping-methods', 'pos', 'sales-report', 'low-stock'].includes(activeTab) && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-8"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-gray-200">
                   <div>
                      <h2 className="text-3xl font-black text-gray-900 tracking-tight uppercase italic">{currentConfig.title}</h2>
                      <p className="text-sm text-gray-500 font-medium italic">{currentConfig.description}</p>
                   </div>
                   <button 
                     onClick={() => {
                       const moduleName = activeTab.replace(/-/g, '_');
                       setModalConfig({
                         isOpen: true,
                         title: `Add ${currentConfig.title}`,
                         fields: currentConfig.fields,
                         onSubmit: async (data) => {
                           await addItemToCollection(moduleName, data);
                           showToast('Entry added successfully');
                         }
                       });
                     }}
                     className="px-8 py-4 bg-primary-950 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl active:scale-95 flex items-center gap-3"
                   >
                     <Package className="w-4 h-4" /> Add {currentConfig.title}
                   </button>
                </div>

                <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl overflow-hidden">
                   <div className="overflow-x-auto no-scrollbar">
                     <table className="w-full text-left whitespace-nowrap">
                       <thead className="bg-[#f8fafc] text-gray-400 text-[10px] font-black uppercase tracking-[0.25em] border-b border-gray-100">
                         <tr>
                            {currentConfig.headers.map((h, i) => (
                              <th key={i} className={`px-10 py-6 ${i === currentConfig.headers.length - 1 ? 'text-right' : ''}`}>
                                {h}
                              </th>
                            ))}
                           <th className="px-10 py-6 text-right">Actions</th>
                         </tr>
                       </thead>
                       <tbody className="divide-y divide-gray-50 capitalize font-bold">
                         {genericData.length === 0 ? (
                           <tr>
                             <td colSpan={currentConfig.headers.length + 1} className="px-10 py-20 text-center">
                               <div className="flex flex-col items-center gap-4 opacity-20">
                                 <Database className="w-12 h-12" />
                                 <p className="text-sm uppercase tracking-widest font-black">No data available in this module</p>
                               </div>
                             </td>
                           </tr>
                         ) : genericData.map((item) => (
                           <tr key={item.id} className="hover:bg-gray-50/50 transition-all group">
                             <td className="px-10 py-8">
                               <div className="flex items-center gap-4">
                                  {item.url && (
                                    <div className="w-12 h-12 rounded-xl border border-gray-100 overflow-hidden bg-gray-50">
                                      <img src={item.url} alt="" className="w-full h-full object-cover" />
                                    </div>
                                  )}
                                  {activeTab === 'colors' && item.value && (
                                    <div className="w-8 h-8 rounded-full border border-gray-100 shadow-inner" style={{backgroundColor: item.value}}></div>
                                  )}
                                  <div>
                                    <div className="font-black text-gray-900">{item.name || item.title || item.label || 'Unnamed'}</div>
                                    <div className="text-[10px] font-mono text-gray-400 mt-1 uppercase">ID: {item.id.slice(-8)}</div>
                                  </div>
                               </div>
                             </td>
                             {currentConfig.headers.slice(1, -1).map((h, i) => {
                               const fieldKey = currentConfig.fields[i+1]?.name;
                               return (
                                 <td key={i} className="px-10 py-8">
                                   <div className="text-xs text-gray-500 italic max-w-xs truncate">
                                     {fieldKey ? String(item[fieldKey] || 'N/A') : 'N/A'}
                                   </div>
                                 </td>
                               );
                             })}
                             <td className="px-10 py-8 text-gray-400 font-bold text-xs uppercase text-right">
                               {item.createdAt ? new Date(item.createdAt).toLocaleDateString() : 'N/A'}
                             </td>
                             <td className="px-10 py-8">
                                <div className="flex justify-end gap-3">
                                  <button 
                                    onClick={() => {
                                      const moduleName = activeTab.replace(/-/g, '_');
                                      setModalConfig({
                                        isOpen: true,
                                        title: `Edit ${currentConfig.title}`,
                                        fields: currentConfig.fields.map(f => ({ ...f, defaultValue: item[f.name] })),
                                        onSubmit: async (data) => {
                                          await updateItemInCollection(moduleName, item.id, data);
                                          showToast('Entry updated');
                                        }
                                      });
                                    }}
                                    className="p-3 bg-gray-50 text-gray-400 hover:bg-primary-50 hover:text-primary-700 rounded-xl transition-all"
                                  >
                                    <Edit className="w-4 h-4" />
                                  </button>
                                  <button 
                                    onClick={async () => {
                                      if (confirm('Are you sure you want to delete this entry?')) {
                                        await deleteItemFromCollection(activeTab.replace(/-/g, '_'), item.id);
                                        showToast('Entry deleted', 'error');
                                      }
                                    }}
                                    className="p-3 bg-red-50 text-red-400 hover:bg-red-500 hover:text-white rounded-xl transition-all"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                             </td>
                           </tr>
                         ))}
                       </tbody>
                     </table>
                   </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'orders-dashboard' && (
               <div className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                     <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                        <div className="flex items-center justify-between mb-4">
                           <span className="text-xs font-black text-gray-400 uppercase tracking-widest">Total Processing</span>
                           <Activity className="w-5 h-5 text-blue-500" />
                        </div>
                        <div className="text-3xl font-black text-gray-900">{orders.filter(o => o.status === 'processing').length}</div>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-2">Currently in warehouse</p>
                     </div>
                     <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                        <div className="flex items-center justify-between mb-4">
                           <span className="text-xs font-black text-gray-400 uppercase tracking-widest">Awaiting Shipping</span>
                           <Truck className="w-5 h-5 text-amber-500" />
                        </div>
                        <div className="text-3xl font-black text-gray-900">{orders.filter(o => o.status === 'pending').length}</div>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-2">Validated but not dispatched</p>
                     </div>
                     <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                        <div className="flex items-center justify-between mb-4">
                           <span className="text-xs font-black text-gray-400 uppercase tracking-widest">Delivered Success</span>
                           <CheckCircle className="w-5 h-5 text-green-500" />
                        </div>
                        <div className="text-3xl font-black text-gray-900">{orders.filter(o => o.status === 'delivered').length}</div>
                        <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-2">Completed transactions</p>
                     </div>
                  </div>
                  
                  <div className="bg-[#0f172a] p-10 rounded-[2.5rem] shadow-2xl relative overflow-hidden">
                     <div className="absolute top-0 right-0 w-64 h-64 bg-primary-500/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
                     <h3 className="text-white font-black text-xl mb-10 tracking-tight">Order Velocity (Hourly)</h3>
                     <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                           <AreaChart data={[
                              {h: '08:00', o: 5}, {h: '10:00', o: 15}, {h: '12:00', o: 42}, 
                              {h: '14:00', o: 28}, {h: '16:00', o: 56}, {h: '18:00', o: 72}, {h: '20:00', o: 38}
                           ]}>
                              <Area type="monotone" dataKey="o" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.1} />
                              <Tooltip contentStyle={{backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', color: '#fff'}} />
                           </AreaChart>
                        </ResponsiveContainer>
                     </div>
                  </div>
               </div>
            )}

            {activeTab === 'orders' && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-8"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-gray-200">
                   <div>
                      <h2 className="text-3xl font-black text-gray-900 tracking-tight">Order Management</h2>
                      <p className="text-sm text-gray-500 font-medium">Control and process customer distributions</p>
                   </div>
                   <div className="flex items-center gap-4">
                      <div className="relative">
                        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input type="text" placeholder="Filter orders..." className="pl-10 pr-4 py-2.5 bg-white border border-gray-100 rounded-xl text-sm font-medium focus:ring-4 focus:ring-primary-500/10 outline-none transition-all" />
                      </div>
                      <select className="bg-white border border-gray-100 rounded-xl text-xs font-black px-4 py-2.5 outline-none focus:ring-4 focus:ring-primary-500/10">
                        <option>All Status</option>
                        <option>Pending</option>
                        <option>Shipped</option>
                        <option>Delivered</option>
                      </select>
                   </div>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {orders.length === 0 ? (
                    <div className="bg-white rounded-[2rem] p-20 text-center border border-dashed border-gray-200">
                       <ShoppingBag className="w-16 h-16 text-gray-200 mx-auto mb-4" />
                       <p className="font-bold text-gray-400 uppercase tracking-widest text-sm">No orders found</p>
                    </div>
                  ) : orders.map((order, idx) => (
                    <motion.div 
                      key={order.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      onClick={() => setSelectedOrder(order)}
                      className="bg-white rounded-3xl border border-gray-100 p-6 flex flex-col lg:flex-row lg:items-center gap-8 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.02)] hover:shadow-xl transition-all group relative overflow-hidden cursor-pointer"
                    >
                      <div className={`absolute top-0 left-0 w-1.5 h-full ${
                        order.status === 'delivered' ? 'bg-green-500' : 
                        order.status === 'pending' ? 'bg-amber-500' :
                        order.status === 'shipped' ? 'bg-blue-500' :
                        'bg-red-500'
                      }`} />
                      
                      <div className="flex items-center gap-6 lg:w-72 shrink-0">
                         <div className="w-14 h-14 bg-gray-50 rounded-2xl flex items-center justify-center font-black text-primary-900 border border-gray-100">
                           #{order.shortId || order.id.slice(-4).toUpperCase()}
                         </div>
                         <div>
                            <h4 className="font-black text-gray-900 leading-tight">{order.customerName}</h4>
                            <p className="text-xs font-bold text-gray-400 mt-1">{order.customerPhone}</p>
                         </div>
                      </div>

                      <div className="flex-1 min-w-0">
                         <div className="flex flex-wrap gap-2">
                           {order.items?.map((item: any, i: number) => (
                             <div key={i} className="flex items-center gap-2 bg-gray-50 px-3 py-1.5 rounded-lg border border-gray-100">
                                <span className="text-[10px] font-black text-primary-700">{item.quantity}x</span>
                                <span className="text-xs font-bold text-gray-600 truncate max-w-[120px]">{item.name}</span>
                             </div>
                           ))}
                         </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-3 gap-8 lg:w-96 shrink-0 lg:text-right">
                         <div className="lg:text-center">
                            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Total</p>
                            <p className="font-black text-xl text-gray-900">৳{order.totalAmount || order.total}</p>
                         </div>
                         <div className="lg:text-center">
                            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Date</p>
                            <p className="font-bold text-gray-900">{new Date(order.createdAt).toLocaleDateString(undefined, { day: 'numeric', month: 'short' })}</p>
                         </div>
                         <div className="col-span-2 md:col-span-1 lg:text-right flex items-center lg:justify-end gap-3" onClick={(e) => e.stopPropagation()}>
                            <select 
                               value={order.status} 
                               onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                               className={`text-[10px] font-black uppercase tracking-widest px-3 py-2 rounded-xl border-none ring-1 ring-gray-100 shadow-inner cursor-pointer appearance-none ${
                                 order.status === 'delivered' ? 'bg-green-50 text-green-700' : 
                                 order.status === 'pending' ? 'bg-amber-50 text-amber-700' :
                                 order.status === 'shipped' ? 'bg-blue-50 text-blue-700' :
                                 'bg-red-50 text-red-700'
                               }`}
                             >
                               <option value="pending">Pending</option>
                               <option value="shipped">Shipped</option>
                               <option value="delivered">Delivered</option>
                               <option value="cancelled">Cancelled</option>
                             </select>
                             <button 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const printWindow = window.open('', '_blank');
                                  if (!printWindow) return;
                                  
                                  const itemsHtml = order.items?.map((item: any) => `
                                    <tr>
                                      <td style="padding: 10px; border-bottom: 1px solid #eee;">${item.name}</td>
                                      <td style="padding: 10px; border-bottom: 1px solid #eee; text-align: center;">${item.quantity}</td>
                                      <td style="padding: 10px; border-bottom: 1px solid #eee; text-align: right;">৳${item.price}</td>
                                      <td style="padding: 10px; border-bottom: 1px solid #eee; text-align: right;">৳${item.price * item.quantity}</td>
                                    </tr>
                                  `).join('') || '';

                                  printWindow.document.write(`
                                    <html>
                                      <head>
                                        <title>Invoice #${order.shortId || order.id.slice(-6)}</title>
                                        <style>
                                          body { font-family: 'Inter', sans-serif; padding: 40px; color: #1e293b; line-height: 1.5; }
                                          .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 40px; border-bottom: 2px solid #f1f5f9; padding-bottom: 20px; }
                                          .logo { font-size: 28px; font-weight: 900; color: #14532d; text-transform: uppercase; letter-spacing: -1px; }
                                          .meta { text-align: right; }
                                          .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; margin-bottom: 40px; }
                                          table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
                                          th { background: #f8fafc; padding: 12px; text-align: left; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; color: #64748b; font-weight: 900; border-bottom: 1px solid #e2e8f0; }
                                          .total-box { margin-left: auto; width: 250px; background: #f8fafc; padding: 20px; rounded: 12px; border: 1px solid #e2e8f0; }
                                          .footer { margin-top: 60px; text-align: center; font-size: 12px; color: #94a3b8; border-top: 1px solid #f1f5f9; padding-top: 30px; }
                                        </style>
                                      </head>
                                      <body>
                                        <div class="header">
                                          <div class="logo">Kholos<span style="color:#f97316">Shop</span></div>
                                          <div class="meta">
                                            <div style="font-weight:900; font-size: 18px;">INVOICE</div>
                                            <div style="color:#64748b; font-size: 12px; font-weight: 700;">#${order.shortId || order.id.slice(-6).toUpperCase()}</div>
                                          </div>
                                        </div>
                                        <div class="grid">
                                          <div>
                                            <div style="font-size: 10px; font-weight: 900; color: #94a3b8; text-transform: uppercase; margin-bottom: 8px;">Ship To</div>
                                            <div style="font-weight: 800; font-size: 16px;">${order.customerName}</div>
                                            <div style="font-weight: 600; color: #475569;">${order.customerPhone}</div>
                                            <div style="color: #64748b; font-size: 14px;">${order.customerAddress || 'No address provided'}</div>
                                          </div>
                                          <div style="text-align: right;">
                                            <div style="font-size: 10px; font-weight: 900; color: #94a3b8; text-transform: uppercase; margin-bottom: 8px;">Order Info</div>
                                            <div style="font-weight: 700;">Date: ${new Date(order.createdAt).toLocaleDateString()}</div>
                                            <div style="font-weight: 700;">Payment: Cash on Delivery</div>
                                            <div style="font-weight: 900; color: #14532d; text-transform: uppercase; font-size: 12px; margin-top: 5px;">${order.status}</div>
                                          </div>
                                        </div>
                                        <table>
                                          <thead>
                                            <tr>
                                              <th>Description</th>
                                              <th style="text-align: center;">Qty</th>
                                              <th style="text-align: right;">Price</th>
                                              <th style="text-align: right;">Amount</th>
                                            </tr>
                                          </thead>
                                          <tbody>
                                            ${itemsHtml}
                                          </tbody>
                                        </table>
                                        <div class="total-box">
                                           <div style="display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px;">
                                              <span style="color:#64748b; font-weight: 600;">Subtotal:</span>
                                              <span style="font-weight: 700;">৳${order.totalAmount || order.total}</span>
                                           </div>
                                           <div style="display: flex; justify-content: space-between; font-size: 18px; font-weight: 900; border-top: 2px solid #e2e8f0; padding-top: 10px; margin-top: 10px;">
                                              <span style="color:#1e293b;">Total:</span>
                                              <span style="color:#14532d;">৳${order.totalAmount || order.total}</span>
                                           </div>
                                        </div>
                                        <div class="footer">
                                          <strong>KholosShop - Authentic & Pure Products</strong><br>
                                          Official Invoice • Customer Support: 01878-145559<br>
                                          <em>Thank you for your business!</em>
                                        </div>
                                        <script>window.print();</script>
                                      </body>
                                    </html>
                                  `);
                                  printWindow.document.close();
                                }}
                                className="p-2.5 bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white rounded-xl transition-all"
                                title="Print Receipt"
                             >
                                <Download className="w-4 h-4" />
                             </button>
                             <button 
                                onClick={async (e) => {
                                  e.stopPropagation();
                                  setDeleteConfirmOrder(order);
                                }}
                                className="p-2.5 bg-gray-50 text-gray-400 hover:bg-red-50 hover:text-red-500 rounded-xl transition-all"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                         </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
            
            {activeTab === 'products' && pathParts[3] === 'add' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] p-6 sm:p-8">
                 <div className="flex items-center gap-3 mb-8 pb-6 border-b border-gray-100 justify-between">
                    <div className="flex items-center gap-3">
                       <button onClick={() => navigate('/dashboard/products')} className="p-2 bg-gray-50 text-gray-400 hover:text-gray-600 rounded-full">
                         <ChevronLeft className="w-5 h-5" />
                       </button>
                       <div>
                         <h2 className="text-xl font-black text-gray-900">Add New Product</h2>
                         <p className="text-sm text-gray-500">Create a new product for your catalog</p>
                       </div>
                    </div>
                 </div>
                 
                 <form onSubmit={async (e) => {
                    e.preventDefault();
                    const formData = new FormData(e.currentTarget);
                    
                    try {
                      await addProduct({
                        name: formData.get('name'),
                        price: parseInt(formData.get('price') as string),
                        originalPrice: formData.get('originalPrice') ? parseInt(formData.get('originalPrice') as string) : null,
                        category: formData.get('category'),
                        brand: formData.get('brand') || '',
                        stock: parseInt(formData.get('stock') as string),
                        unit: formData.get('unit') ? String(formData.get('unit')) : '',
                        image: formData.get('imageUrl') ? String(formData.get('imageUrl')) : '',
                        images: formData.get('additionalImages') ? (formData.get('additionalImages') as string).split(',').map(s => s.trim()).filter(Boolean) : [],
                        options: formData.get('variants') || formData.get('options') || '',
                        description: formData.get('description') || 'No description',
                        shortDescription: formData.get('shortDescription') || '',
                        isCombo: formData.get('isCombo') === 'on',
                        isHotDeal: formData.get('isHotDeal') === 'on',
                        isFlashSale: formData.get('isFlashSale') === 'on',
                        isVerified: formData.get('isVerified') === 'on',
                        inStock: true,
                        tag: formData.get('tag') ? String(formData.get('tag')) : ''
                      });
                      showToast('Product added successfully!', 'success');
                      navigate('/dashboard/products');
                    } catch (e: any) {
                      showToast('Error: ' + e.message, 'error');
                    }
                 }} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                       <div>
                         <label className="block text-sm font-bold text-gray-700 mb-2">Product Name <span className="text-red-500">*</span></label>
                         <input required name="name" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all" placeholder="Enter product name" />
                       </div>
                       <div>
                         <label className="block text-sm font-bold text-gray-700 mb-2">Brand (Optional)</label>
                         <select name="brand" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all">
                           <option value="">No Brand</option>
                           {brands.map(b => (
                             <option key={b.id} value={b.name}>{b.name}</option>
                           ))}
                         </select>
                       </div>
                       <div>
                         <label className="block text-sm font-bold text-gray-700 mb-2">Category <span className="text-red-500">*</span></label>
                         <select required name="category" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all">
                           {(categories.length > 0 ? categories : [{name: 'General'}]).map(c => (
                             <option key={c.name} value={c.name}>{c.name}</option>
                           ))}
                         </select>
                       </div>
                       <div>
                         <label className="block text-sm font-bold text-gray-700 mb-2">Price (৳) <span className="text-red-500">*</span></label>
                         <input required type="number" name="price" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all" placeholder="1000" />
                       </div>
                       <div>
                         <label className="block text-sm font-bold text-gray-700 mb-2">Original Price (৳)</label>
                         <input type="number" name="originalPrice" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all" placeholder="1200" />
                       </div>
                       <div>
                         <label className="block text-sm font-bold text-gray-700 mb-2">Unit/Size (e.g. 500g, 1L, Pack)</label>
                         <input type="text" name="unit" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all" placeholder="1 kg" />
                       </div>
                       <div>
                         <label className="block text-sm font-bold text-gray-700 mb-2">Stock Available <span className="text-red-500">*</span></label>
                         <input required type="number" name="stock" defaultValue="10" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all" placeholder="10" />
                       </div>
                    </div>
                    <div className="flex flex-col sm:flex-row items-center gap-6 p-4 bg-gray-50 border border-gray-100 rounded-xl">
                      <div className="flex items-center gap-2">
                         <input type="checkbox" id="isCombo" name="isCombo" className="w-5 h-5 text-primary-600 rounded" />
                         <label htmlFor="isCombo" className="font-bold text-gray-700 cursor-pointer text-sm">Mark as Combo Package</label>
                      </div>
                      <div className="flex items-center gap-2">
                         <input type="checkbox" id="isHotDeal" name="isHotDeal" className="w-5 h-5 text-red-600 rounded" />
                         <label htmlFor="isHotDeal" className="font-bold text-gray-700 cursor-pointer text-sm">Mark as Hot Deal 🔥</label>
                      </div>
                      <div className="flex items-center gap-2">
                         <input type="checkbox" id="isFlashSale" name="isFlashSale" className="w-5 h-5 text-accent rounded" />
                         <label htmlFor="isFlashSale" className="font-bold text-gray-700 cursor-pointer text-sm">Include in Flash Sale ⚡</label>
                      </div>
                      <div className="flex items-center gap-2">
                         <input type="checkbox" id="isVerified" name="isVerified" className="w-5 h-5 text-green-500 rounded" />
                         <label htmlFor="isVerified" className="font-bold text-gray-700 cursor-pointer text-sm">Verified Product ✅</label>
                      </div>
                      <div className="flex-1 w-full">
                         <label className="block text-xs font-bold text-gray-700 mb-1">Product Badge/Tag</label>
                         <select name="tag" className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm bg-white outline-none">
                            <option value="">None</option>
                            <option value="সেরা অফার">সেরা অফার (Best Offer)</option>
                            <option value="এই সপ্তাহের">এই সপ্তাহের (This Week)</option>
                            <option value="সর্বোচ্চ বিক্রিত পণ্যসমূহ">সর্বোচ্চ বিক্রিত পণ্যসমূহ (Best Selling)</option>
                            <option value="নতুন সংগ্রহ">নতুন সংগ্রহ (New Collection)</option>
                            <option value="Hot Deals">Hot Deals</option>
                            <option value={settings?.homeSection1Filter || 'HomeSection1'}>{settings?.homeSection1Title || 'Home Section 1'} ({settings?.homeSection1Filter || 'HomeSection1'})</option>
                            <option value={settings?.homeSection2Filter || 'HomeSection2'}>{settings?.homeSection2Title || 'Home Section 2'} ({settings?.homeSection2Filter || 'HomeSection2'})</option>
                            <option value={settings?.homeSection3Filter || 'HomeSection3'}>{settings?.homeSection3Title || 'Home Section 3'} ({settings?.homeSection3Filter || 'HomeSection3'})</option>
                            <option value={settings?.homeSection4Filter || 'HomeSection4'}>{settings?.homeSection4Title || 'Home Section 4'} ({settings?.homeSection4Filter || 'HomeSection4'})</option>
                         </select>
                      </div>
                    </div>
                    <div>
                       <label className="block text-sm font-bold text-gray-700 mb-2">Product Variants (Optional)</label>
                       <input type="text" name="options" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all" placeholder="500g, 1kg, 2kg..." />
                       <p className="text-xs text-gray-500 mt-1">Comma separated options for the user to select.</p>
                    </div>
                    <div>
                       <label className="block text-sm font-bold text-gray-700 mb-2">Main Image URL</label>
                       <input type="url" name="imageUrl" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all" placeholder="https://..." />
                       <p className="text-xs text-gray-500 mt-1">Leave empty to use a default placeholder image.</p>
                    </div>
                    <div>
                       <label className="block text-sm font-bold text-gray-700 mb-2">Additional Image URLs</label>
                       <textarea name="additionalImages" rows={3} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all" placeholder="https://image1.jpg, https://image2.jpg... (comma separated)"></textarea>
                       <p className="text-xs text-gray-500 mt-1">Multiple images separated by commas</p>
                    </div>
                    <div>
                       <label className="block text-sm font-bold text-gray-700 mb-2">Short Description</label>
                       <input type="text" name="shortDescription" className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all" placeholder="Enter a brief summary..." />
                    </div>
                    <div>
                       <label className="block text-sm font-bold text-gray-700 mb-2">Full Description</label>
                       <textarea name="description" rows={4} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all" placeholder="Enter full product details..."></textarea>
                    </div>
                    <div className="pt-4 border-t border-gray-100 flex justify-end">
                       <button type="submit" className="px-8 py-3 bg-primary-700 text-white font-bold rounded-xl shadow-md hover:bg-primary-800 transition-all active:scale-[0.98]">
                         Publish Product
                       </button>
                    </div>
                 </form>
              </div>
            )}

            {activeTab === 'products' && pathParts[3] !== 'add' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] overflow-hidden">
                <div className="p-6 bg-gray-50/50 border-b border-gray-100 flex justify-between items-center">
                     <div>
                       <h2 className="text-xl font-black text-gray-900">Products</h2>
                       <p className="text-sm text-gray-500 mt-1">Manage your store products</p>
                     </div>
                     <button 
                      onClick={() => navigate('/dashboard/products/add')}
                      className="bg-primary-700 text-white px-6 py-2.5 rounded-xl font-bold text-sm shadow-md hover:bg-primary-800 transition-all active:scale-[0.98] border border-transparent"
                     >
                       + Add Product
                     </button>
                  </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm whitespace-nowrap">
                    <thead className="bg-[#f8f9fa] text-gray-500 border-b border-gray-100 font-bold">
                      <tr>
                        <th className="px-6 py-5 uppercase tracking-widest text-[10px]">Product</th>
                        <th className="px-6 py-5 uppercase tracking-widest text-[10px]">Category</th>
                        <th className="px-6 py-5 uppercase tracking-widest text-[10px] text-right">Price</th>
                        <th className="px-6 py-5 uppercase tracking-widest text-[10px] text-center">Status</th>
                        <th className="px-6 py-5 uppercase tracking-widest text-[10px] text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50">
                      {products.map((product) => (
                        <tr key={product.id} className="hover:bg-gray-50/50 transition-colors">
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-4">
                              <div className="w-12 h-12 rounded-xl border border-gray-100 overflow-hidden bg-white shadow-sm flex-shrink-0">
                                <img src={product.image} referrerPolicy="no-referrer" className="w-full h-full object-contain" />
                              </div>
                              <div className="flex flex-col">
                                <span className="font-black text-gray-900 line-clamp-1">{product.name}</span>
                                <span className="text-[10px] text-gray-400 font-mono tracking-tighter">ID: {product.id.slice(0,8)}</span>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-[10px] font-black uppercase tracking-widest">{product.category}</span>
                          </td>
                          <td className="px-6 py-4 font-black text-gray-900 text-right">৳{product.price}</td>
                          <td className="px-6 py-4">
                            <div className="flex flex-col items-center gap-2">
                              <div className="flex items-center gap-2">
                                <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest ${product.stock > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                  {product.stock > 0 ? 'Stock' : 'Out'} ({product.stock})
                                </span>
                                <span className={`px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest ${product.inStock ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100 text-gray-600'}`}>
                                  {product.inStock ? 'Visible' : 'Hidden'}
                                </span>
                              </div>
                              <div className="flex items-center gap-1.5">
                                <button 
                                  onClick={() => {
                                    setModalConfig({
                                      isOpen: true,
                                      title: `Restock: ${product.name}`,
                                      fields: [
                                        { name: 'qty', label: 'Quantity to ADD (put negative to remove)', type: 'number', defaultValue: '10' }
                                      ],
                                      onSubmit: async (data: any) => {
                                        try {
                                          const updateData = { 
                                            stock: (Number(product.stock) || 0) + Number(data.qty),
                                            inStock: true 
                                          };
                                          await updateProduct(product.id, updateData);
                                          showToast('Restocked successfully!');
                                        } catch (e: any) {
                                          showToast(`Failed: ${e.message}`, 'error');
                                        }
                                      }
                                    });
                                  }}
                                  className="flex items-center gap-1.5 text-[9px] bg-green-50 border border-green-100 text-green-700 px-2.5 py-1.5 rounded-lg hover:bg-green-600 hover:text-white transition-all font-black uppercase tracking-widest shadow-sm"
                                >
                                  <RefreshCw className="w-3 h-3" />
                                  Restock
                                </button>
                                <button 
                                  onClick={() => {
                                    updateProduct(product.id, { inStock: !product.inStock })
                                      .then(() => showToast(product.inStock ? 'Product hidden' : 'Product visible'))
                                      .catch((e: any) => showToast(`Failed: ${e.message}`, 'error'));
                                  }}
                                  className={`flex items-center gap-1.5 text-[9px] px-2.5 py-1.5 rounded-lg border font-black uppercase tracking-widest transition-all shadow-sm ${
                                    product.inStock ? 'bg-gray-50 text-gray-500 border-gray-100 hover:bg-primary-900 hover:text-white' : 'bg-orange-50 text-orange-600 border-orange-100 hover:bg-orange-600 hover:text-white'
                                  }`}
                                >
                                  {product.inStock ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                                  {product.inStock ? 'Hide' : 'Show'}
                                </button>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 text-right">
                             <div className="flex items-center justify-end gap-2">
                                <button 
                                  onClick={() => {
                                    setModalConfig({
                                      isOpen: true,
                                      title: 'Edit Product',
                                      fields: [
                                        { name: 'name', label: 'Product Name', type: 'text', defaultValue: product.name },
                                        { name: 'price', label: 'Price (৳)', type: 'number', defaultValue: product.price.toString() },
                                        { name: 'originalPrice', label: 'Original Price (৳) [optional]', type: 'number', defaultValue: product.originalPrice?.toString() || '' },
                                        { name: 'unit', label: 'Unit (e.g. 1kg, 500g) [optional]', type: 'text', defaultValue: product.unit || '' },
                                        { name: 'category', label: 'Category', type: 'select', defaultValue: product.category, options: categories.length > 0 ? categories.map(c => ({ label: c.name, value: c.name })) : [{ label: 'General', value: 'General' }] },
                                        { name: 'brand', label: 'Brand (optional)', type: 'select', defaultValue: product.brand || '', options: [{ label: 'No Brand', value: '' }, ...brands.map(b => ({ label: b.name, value: b.name }))] },
                                        { name: 'imageUrl', label: 'Main Image URL', type: 'text', defaultValue: product.image || '' },
                                        { name: 'options', label: 'Options (comma separated)', type: 'text', defaultValue: product.options || (product.variants ? product.variants.join(', ') : '') || '' },
                                        { name: 'shortDescription', label: 'Short Description', type: 'text', defaultValue: product.shortDescription || '' },
                                        { name: 'description', label: 'Full Description', type: 'text', defaultValue: product.description || '' },
                                        { name: 'stock', label: 'Stock', type: 'number', defaultValue: product.stock.toString() },
                                        { name: 'isCombo', label: 'Is Combo Paket', type: 'select', defaultValue: product.isCombo ? 'true' : 'false', options: [{label: 'Yes', value: 'true'}, {label: 'No', value: 'false'}] },
                                        { name: 'isHotDeal', label: 'Is Hot Deal 🔥', type: 'select', defaultValue: product.isHotDeal ? 'true' : 'false', options: [{label: 'Yes', value: 'true'}, {label: 'No', value: 'false'}] },
                                        { name: 'isFlashSale', label: 'Include in Flash Sale ⚡', type: 'select', defaultValue: product.isFlashSale ? 'true' : 'false', options: [{label: 'Yes', value: 'true'}, {label: 'No', value: 'false'}] },
                                        { name: 'isVerified', label: 'Verified Product ✅', type: 'select', defaultValue: product.isVerified ? 'true' : 'false', options: [{label: 'Yes', value: 'true'}, {label: 'No', value: 'false'}] },
                                        { name: 'tag', label: 'Product Tag/Badge', type: 'select', defaultValue: product.tag || '', options: [
                                           { label: 'None', value: '' },
                                           { label: 'সেরা অফার', value: 'সেরা অফার' },
                                           { label: 'এই সপ্তাহের', value: 'এই সপ্তাহের' },
                                           { label: 'সর্বোচ্চ বিক্রিত পণ্যসমূহ', value: 'সর্বোচ্চ বিক্রিত পণ্যসমূহ' },
                                           { label: 'নতুন সংগ্রহ', value: 'নতুন সংগ্রহ' },
                                           { label: 'Hot Deals', value: 'Hot Deals' },
                                           { label: `${settings?.homeSection1Title || 'Home Section 1'} (${settings?.homeSection1Filter || 'HomeSection1'})`, value: settings?.homeSection1Filter || 'HomeSection1' },
                                           { label: `${settings?.homeSection2Title || 'Home Section 2'} (${settings?.homeSection2Filter || 'HomeSection2'})`, value: settings?.homeSection2Filter || 'HomeSection2' },
                                           { label: `${settings?.homeSection3Title || 'Home Section 3'} (${settings?.homeSection3Filter || 'HomeSection3'})`, value: settings?.homeSection3Filter || 'HomeSection3' },
                                           { label: `${settings?.homeSection4Title || 'Home Section 4'} (${settings?.homeSection4Filter || 'HomeSection4'})`, value: settings?.homeSection4Filter || 'HomeSection4' }
                                        ]}
                                      ],
                                      onSubmit: async (data: any) => {
                                        try {
                                          const updateData: any = {
                                            name: data.name,
                                            price: parseInt(data.price), 
                                            stock: parseInt(data.stock),
                                            unit: data.unit || undefined,
                                            category: data.category,
                                            brand: data.brand || '',
                                            tag: data.tag || '',
                                            shortDescription: data.shortDescription,
                                            description: data.description,
                                            isCombo: data.isCombo === 'true',
                                            isHotDeal: data.isHotDeal === 'true',
                                            isFlashSale: data.isFlashSale === 'true',
                                            isVerified: data.isVerified === 'true',
                                          };
                                          if (data.imageUrl) {
                                            updateData.image = data.imageUrl;
                                          }
                                          if (data.originalPrice) {
                                            updateData.originalPrice = parseInt(data.originalPrice);
                                          } else {
                                            updateData.originalPrice = null;
                                          }
                                          await updateProduct(product.id, updateData);
                                          showToast('Product updated successfully!');
                                        } catch (e: any) {
                                          showToast('Failed to update product', 'error');
                                        }
                                      }
                                    });
                                  }}
                                  className="p-3 bg-blue-50 text-blue-500 hover:bg-blue-500 hover:text-white rounded-xl transition-all"
                                >
                                  <Edit className="w-4 h-4" />
                                </button>
                                <button 
                                  onClick={async () => {
                                    if (confirm('Delete this product?')) {
                                      try {
                                        await deleteProduct(product.id);
                                        showToast('Product deleted');
                                      } catch (e: any) {
                                        showToast('Error: ' + e.message, 'error');
                                      }
                                    }
                                  }}
                                  className="p-3 bg-red-50 text-red-500 hover:bg-red-500 hover:text-white rounded-xl transition-all"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                             </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'categories' && (
              <div className="space-y-8">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-gray-200">
                  <div>
                    <h2 className="text-3xl font-black text-gray-900 tracking-tight">Category Catalog</h2>
                    <p className="text-sm text-gray-500 font-medium">Organize and manage your shop classification system</p>
                  </div>
                  <button 
                    onClick={() => {
                      setModalConfig({
                        isOpen: true,
                        title: 'Add Category',
                        fields: [
                          { name: 'name', label: 'Category Name' },
                          { name: 'image', label: 'Image URL (optional)', required: false }
                        ],
                        onSubmit: async (data: any) => {
                          try {
                            await addCategory({ name: data.name, image: data.image });
                            showToast('Category added!');
                          } catch (e: any) {
                            showToast('Failed: ' + e.message, 'error');
                          }
                        }
                      });
                    }}
                    className="bg-primary-950 text-white px-8 py-3.5 rounded-2xl font-black shadow-xl shadow-primary-950/20 hover:bg-black transition-all active:scale-[0.98] text-xs uppercase tracking-widest flex items-center gap-2"
                  >
                    <Plus className="w-5 h-5" /> Add New Category
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-6">
                  {categories.map((cat, idx) => (
                    <motion.div 
                      key={cat.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: idx * 0.03 }}
                      className="group bg-white rounded-3xl border border-gray-100 overflow-hidden hover:shadow-[0_20px_40px_rgba(0,0,0,0.06)] transition-all duration-500 relative"
                    >
                      <div className="aspect-square bg-[#FAFAFF] p-6 flex items-center justify-center relative overflow-hidden group-hover:bg-white transition-colors">
                        <div className="absolute inset-0 bg-gradient-to-br from-primary-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                        {cat.image ? (
                          <img src={cat.image} alt={cat.name} referrerPolicy="no-referrer" className="w-full h-full object-contain mix-blend-multiply group-hover:scale-110 transition-transform duration-700 z-10" />
                        ) : (
                          <div className="w-20 h-20 rounded-full bg-gray-100 flex items-center justify-center group-hover:bg-primary-50 transition-colors z-10">
                             <Image className="w-10 h-10 text-gray-300 group-hover:text-primary-400" />
                          </div>
                        )}
                      </div>
                      <div className="p-5 flex flex-col items-center border-t border-gray-100">
                        <span className="font-black text-gray-900 group-hover:text-primary-700 transition-colors mb-4">{cat.name}</span>
                        <div className="flex items-center gap-2">
                           <button 
                             onClick={() => {
                               setModalConfig({
                                 isOpen: true,
                                 title: 'Edit Category',
                                 fields: [
                                   { name: 'name', label: 'Category Name', defaultValue: cat.name },
                                   { name: 'image', label: 'Image URL (optional)', required: false, defaultValue: cat.image || '' }
                                 ],
                                 onSubmit: async (data: any) => {
                                   try {
                                     await updateCategory(cat.id, { name: data.name, image: data.image });
                                     showToast('Category updated!');
                                   } catch (e: any) {
                                     showToast('Failed: ' + e.message, 'error');
                                   }
                                 }
                               });
                             }}
                             className="p-3 bg-gray-50 text-gray-400 hover:bg-blue-50 hover:text-blue-600 rounded-xl transition-all"
                           >
                             <Edit className="w-4 h-4" />
                           </button>
                           <button 
                             onClick={async () => {
                               if (confirm(`Delete category "${cat.name}"?`)) {
                                 try {
                                   await deleteCategory(cat.id);
                                   showToast('Category deleted');
                                 } catch (e: any) {
                                   showToast('Error: ' + e.message, 'error');
                                 }
                               }
                             }}
                             className="p-3 bg-gray-50 text-gray-400 hover:bg-red-50 hover:text-red-600 rounded-xl transition-all"
                           >
                             <Trash2 className="w-4 h-4" />
                           </button>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                  {categories.length === 0 && (
                    <div className="col-span-full py-20 text-center bg-white rounded-[2.5rem] border border-dashed border-gray-200">
                       <Layers className="w-16 h-16 text-gray-200 mx-auto mb-4" />
                       <p className="font-bold text-gray-400 uppercase tracking-widest text-xs">No categories found</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'brands' && (
              <div className="space-y-8">
                 <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-gray-200">
                    <div>
                      <h2 className="text-3xl font-black text-gray-900 tracking-tight">Brand Directory</h2>
                      <p className="text-sm text-gray-500 font-medium">Manage manufacturing and sourcing partners</p>
                    </div>
                    <button 
                      onClick={() => {
                        setModalConfig({
                          isOpen: true,
                          title: 'Add Brand',
                          fields: [
                            { name: 'name', label: 'Brand Name' },
                            { name: 'image', label: 'Logo URL (optional)', required: false }
                          ],
                          onSubmit: async (data: any) => {
                            try {
                              await addBrand({ name: data.name, image: data.image });
                              showToast('Brand added!');
                            } catch (e: any) {
                              showToast('Failed: ' + e.message, 'error');
                            }
                          }
                        });
                      }}
                      className="bg-primary-950 text-white px-8 py-3.5 rounded-2xl font-black hover:bg-black transition-all shadow-xl shadow-primary-950/20 active:scale-[0.98] text-xs uppercase tracking-widest flex items-center gap-2"
                    >
                      <Plus className="w-5 h-5 text-accent" /> Add New Brand
                    </button>
                 </div>
                 
                 <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
                    {brands.map((brand, idx) => (
                      <motion.div 
                        key={brand.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: idx * 0.02 }}
                        className="group bg-white rounded-[2rem] border border-gray-100 p-6 flex flex-col items-center hover:shadow-[0_20px_40px_rgba(0,0,0,0.06)] transition-all duration-500"
                      >
                        <div className="w-20 h-20 bg-[#FAFAFF] rounded-2xl mb-4 flex items-center justify-center p-4 border border-gray-50 group-hover:bg-white group-hover:border-primary-50 transition-all">
                           {brand.image ? (
                             <img src={brand.image} alt={brand.name} referrerPolicy="no-referrer" className="w-full h-full object-contain mix-blend-multiply" />
                           ) : (
                             <Shield className="w-8 h-8 text-gray-200" />
                           )}
                        </div>
                        <h4 className="font-black text-gray-900 mb-4 tracking-tight">{brand.name}</h4>
                        <div className="flex items-center gap-2">
                           <button 
                             onClick={() => {
                               setModalConfig({
                                 isOpen: true,
                                 title: 'Edit Brand',
                                 fields: [
                                   { name: 'name', label: 'Brand Name', defaultValue: brand.name },
                                   { name: 'image', label: 'Logo URL (optional)', required: false, defaultValue: brand.image || '' }
                                 ],
                                 onSubmit: async (data: any) => {
                                   try {
                                     await updateBrand(brand.id, { name: data.name, image: data.image });
                                     showToast('Brand updated!');
                                   } catch (e: any) {
                                     showToast('Failed: ' + e.message, 'error');
                                   }
                                 }
                               });
                             }}
                             className="p-2.5 bg-gray-50 text-gray-400 hover:bg-blue-50 hover:text-blue-600 rounded-xl transition-all"
                           >
                             <Edit className="w-4 h-4" />
                           </button>
                           <button 
                             onClick={async () => {
                               if (confirm(`Delete brand "${brand.name}"?`)) {
                                 try {
                                   await deleteBrand(brand.id);
                                   showToast('Brand deleted');
                                 } catch (e: any) {
                                   showToast('Error: ' + e.message, 'error');
                                 }
                               }
                             }}
                             className="p-2.5 bg-gray-50 text-gray-400 hover:bg-red-50 hover:text-red-600 rounded-xl transition-all"
                           >
                             <Trash2 className="w-4 h-4" />
                           </button>
                        </div>
                      </motion.div>
                    ))}
                    {brands.length === 0 && (
                      <div className="col-span-full py-20 text-center bg-white rounded-[2.5rem] border border-dashed border-gray-200">
                         <Shield className="w-16 h-16 text-gray-200 mx-auto mb-4" />
                         <p className="font-bold text-gray-400 uppercase tracking-widest text-xs">No brands listed</p>
                      </div>
                    )}
                 </div>
              </div>
            )}

            {activeTab === 'blogs' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] p-8">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-xl font-black text-gray-900">Blogs & Articles</h2>
                    <p className="text-sm text-gray-500 mt-1">Manage content for your customers</p>
                  </div>
                  <button 
                    onClick={() => {
                        setModalConfig({
                            isOpen: true,
                            title: 'Create New Article',
                            fields: [
                                { name: 'title', label: 'Article Title', type: 'text', required: true },
                                { name: 'imageUrl', label: 'Feature Image URL', type: 'url', required: true },
                                { name: 'author', label: 'Author Name', type: 'text', defaultValue: 'Admin' },
                                { name: 'description', label: 'Short Summary/Excerpt', type: 'text', required: true },
                                { name: 'content', label: 'Full Article Content (Markdown/HTML supported)', type: 'text', required: true }
                            ],
                            onSubmit: async (data: any) => { 
                               try {
                                  await addItemToCollection('blogs', {
                                    ...data,
                                    createdAt: new Date().toISOString()
                                  });
                                  showToast('Article published successfully!');
                               } catch (err: any) {
                                  showToast('Failed to publish', 'error');
                               }
                            }
                        })
                    }}
                    className="bg-primary-950 text-white px-8 py-3 rounded-xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-black transition-all active:scale-95 flex items-center gap-2"
                  >
                     <Plus className="w-4 h-4" /> Add Article
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {genericData.map((blog) => (
                    <div key={blog.id} className="group bg-gray-50 border border-gray-100 rounded-[2rem] overflow-hidden hover:shadow-2xl transition-all duration-500 flex flex-col h-full relative">
                      <div className="h-48 overflow-hidden relative">
                         <img src={blog.imageUrl || blog.image || 'https://via.placeholder.com/400x200'} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
                         <div className="absolute top-4 right-4 flex gap-2">
                           <button 
                              onClick={() => {
                                setModalConfig({
                                  isOpen: true,
                                  title: 'Edit Article',
                                  fields: [
                                    { name: 'title', label: 'Article Title', defaultValue: blog.title },
                                    { name: 'imageUrl', label: 'Feature Image URL', defaultValue: blog.imageUrl || blog.image },
                                    { name: 'author', label: 'Author Name', defaultValue: blog.author || 'Admin' },
                                    { name: 'description', label: 'Short Summary', defaultValue: blog.description },
                                    { name: 'content', label: 'Full Content', defaultValue: blog.content }
                                  ],
                                  onSubmit: async (data: any) => {
                                    try {
                                      await updateItemInCollection('blogs', blog.id, data);
                                      showToast('Article updated!');
                                    } catch (e) {
                                      showToast('Failed to update', 'error');
                                    }
                                  }
                                });
                              }}
                              className="p-2 bg-white/90 backdrop-blur-sm text-primary-600 rounded-xl shadow-lg hover:bg-primary-600 hover:text-white transition-all"
                           >
                              <Edit className="w-4 h-4" />
                           </button>
                           <button 
                              onClick={async () => {
                                if (confirm('Delete this article?')) {
                                   try {
                                      await deleteItemFromCollection('blogs', blog.id);
                                      showToast('Article deleted');
                                   } catch (e: any) {
                                      showToast('Error', 'error');
                                   }
                                }
                              }}
                              className="p-2 bg-white/90 backdrop-blur-sm text-red-600 rounded-xl shadow-lg hover:bg-red-600 hover:text-white transition-all"
                           >
                              <Trash2 className="w-4 h-4" />
                           </button>
                         </div>
                      </div>
                      <div className="p-6 flex-1 flex flex-col">
                         <div className="flex items-center gap-2 mb-3">
                            <span className="px-3 py-1 bg-primary-100 text-primary-700 text-[10px] font-black uppercase tracking-widest rounded-full">Article</span>
                            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{blog.author || 'Admin'}</span>
                         </div>
                         <h4 className="font-black text-gray-900 text-lg mb-2 line-clamp-2 uppercase tracking-tight italic">{blog.title}</h4>
                         <p className="text-sm text-gray-500 font-medium line-clamp-3 mb-6 flex-1">{blog.description || blog.content || 'No description provided.'}</p>
                         <div className="border-t border-gray-100 pt-4 flex justify-between items-center">
                            <span className="text-[10px] font-mono text-gray-400">#{blog.id.slice(0,8)}</span>
                            <span className="text-[10px] font-bold text-gray-400 uppercase">{blog.createdAt ? new Date(blog.createdAt).toLocaleDateString() : 'N/A'}</span>
                         </div>
                      </div>
                    </div>
                  ))}
                  {genericData.length === 0 && (
                    <div className="col-span-full py-20 text-center bg-gray-50 rounded-[2rem] border-2 border-dashed border-gray-200">
                        <Leaf className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                        <p className="text-gray-400 font-black uppercase tracking-widest text-xs">No articles published yet.</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'coupons' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] p-8">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-xl font-black text-gray-900">Coupons</h2>
                    <p className="text-sm text-gray-500 mt-1">Create discount codes for your customers</p>
                  </div>
                  <button 
                    onClick={() => {
                      setModalConfig({
                        isOpen: true,
                        title: 'Add Coupon',
                        fields: [
                          { name: 'code', label: 'Coupon Code' },
                          { name: 'discount', label: 'Discount Amount (%)', type: 'number' }
                        ],
                        onSubmit: async (data: any) => {
                          try {
                            await addCoupon(data.code, parseInt(data.discount));
                            showToast('Coupon created!');
                          } catch (e: any) {
                            showToast('Failed: ' + e.message, 'error');
                          }
                        }
                      });
                    }}
                    className="bg-primary-700 text-white px-6 py-2.5 rounded-xl font-bold shadow-md hover:bg-primary-800 transition-all active:scale-[0.98] text-sm"
                  >
                    + Add New Coupon
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead className="bg-gray-50 text-[10px] text-gray-500 uppercase tracking-widest font-black border-b border-gray-100">
                      <tr>
                        <th className="px-6 py-4">Code</th>
                        <th className="px-6 py-4">Discount</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {coupons.map((coupon) => (
                        <tr key={coupon.id}>
                          <td className="px-6 py-4 font-bold text-primary-900">{coupon.code}</td>
                          <td className="px-6 py-4 text-gray-700">{coupon.discount}%</td>
                          <td className="px-6 py-4">
                            <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase">Active</span>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <button 
                              onClick={async () => {
                                 if (confirm('Delete this coupon?')) {
                                   try {
                                     await deleteCoupon(coupon.id);
                                     showToast('Coupon deleted');
                                   } catch (e: any) {
                                     showToast('Error', 'error');
                                   }
                                 }
                               }}
                              className="text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                      {coupons.length === 0 && <tr><td colSpan={4} className="px-6 py-12 text-center text-gray-500">No coupons yet.</td></tr>}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

             {activeTab === 'customers' && (
              <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-[0_10px_40px_-5px_rgba(0,0,0,0.03)] overflow-hidden">
                <div className="p-8 border-b border-gray-50 bg-gray-50/50">
                  <h2 className="text-2xl font-black text-gray-900 tracking-tight">Customer Repository</h2>
                  <p className="text-sm text-gray-500 font-medium">Manage and view registered user base</p>
                </div>
                <div className="overflow-x-auto no-scrollbar">
                  <table className="w-full text-left whitespace-nowrap">
                    <thead className="bg-[#f8fafc] text-gray-400 text-[10px] font-black uppercase tracking-[0.2em] border-b border-gray-100">
                      <tr>
                        <th className="px-10 py-5 text-center w-20">#</th>
                        <th className="px-10 py-5">Profile</th>
                        <th className="px-10 py-5">Contact Info</th>
                        <th className="px-10 py-5">Address</th>
                        <th className="px-10 py-5">Join Date</th>
                        <th className="px-10 py-5 text-right w-20">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-50 font-bold">
                      {customers.map((cust, idx) => (
                        <tr key={cust.id} className="hover:bg-gray-50/50 transition-all group">
                          <td className="px-10 py-6 text-center text-gray-400 text-xs">{(idx + 1).toString().padStart(2, '0')}</td>
                          <td className="px-10 py-6">
                            <div className="flex items-center gap-4">
                              <div className="w-10 h-10 bg-primary-100 text-primary-700 rounded-xl flex items-center justify-center font-black text-sm uppercase">
                                {cust.displayName?.[0] || <User className="w-5 h-5" />}
                              </div>
                              <div className="flex flex-col">
                                <span className="text-gray-900 text-sm">{cust.displayName || 'Guest User'}</span>
                                <span className="text-[10px] text-gray-400 font-mono tracking-tighter uppercase">{cust.uid?.slice(0, 10)}...</span>
                              </div>
                            </div>
                          </td>
                          <td className="px-10 py-6">
                            <div className="flex flex-col gap-1">
                              <div className="flex items-center gap-2 text-gray-700 text-xs">
                                <Mail className="w-3.5 h-3.5 text-gray-300" />
                                {cust.email || 'No Email'}
                              </div>
                              {cust.phone && (
                                <div className="flex items-center gap-2 text-gray-700 text-xs font-mono">
                                  <Phone className="w-3.5 h-3.5 text-gray-300" />
                                  {cust.phone}
                                </div>
                              )}
                            </div>
                          </td>
                          <td className="px-10 py-6 max-w-xs overflow-hidden">
                             <div className="flex items-start gap-2">
                                <MapPin className="w-3.5 h-3.5 text-gray-300 mt-0.5 shrink-0" />
                                <span className="text-xs text-gray-500 line-clamp-2 leading-relaxed">{cust.address || 'Not Provided'}</span>
                             </div>
                          </td>
                          <td className="px-10 py-6 text-xs text-gray-400 uppercase">
                            {cust.createdAt ? new Date(cust.createdAt).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) : 'N/A'}
                          </td>
                          <td className="px-10 py-6 text-right">
                             <button 
                                onClick={() => {
                                  if (confirm('Delete this user?')) deleteUser(cust.id);
                                }}
                                className="p-2 transition-all hover:bg-red-50 text-gray-300 hover:text-red-500 rounded-xl"
                             >
                                <Trash2 className="w-4 h-4" />
                             </button>
                          </td>
                        </tr>
                      ))}
                      {customers.length === 0 && (
                        <tr>
                          <td colSpan={6} className="px-6 py-20 text-center">
                            <Users className="w-12 h-12 text-gray-100 mx-auto mb-4" />
                            <p className="text-gray-400 font-black uppercase tracking-[0.2em] text-xs">No registered customers</p>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'settings' && (
               <div className="space-y-10 max-w-5xl">
                <form 
                  className="space-y-10"
                  onSubmit={async (e) => {
                    e.preventDefault();
                    const formData = new FormData(e.currentTarget);
                    
                      const firebaseConfig = {
                        apiKey: formData.get('fb_apiKey'),
                        authDomain: formData.get('fb_authDomain'),
                        projectId: formData.get('fb_projectId'),
                        storageBucket: formData.get('fb_storageBucket'),
                        messagingSenderId: formData.get('fb_messagingSenderId'),
                        appId: formData.get('fb_appId'),
                        databaseId: formData.get('fb_databaseId'),
                      };

                      const settingsData = {
                        ...settings,
                        siteName: formData.get('siteName'),
                        siteEmail: formData.get('siteEmail'),
                        sitePhone: formData.get('sitePhone'),
                        siteAddress: formData.get('siteAddress'),
                        whatsappNumber: formData.get('whatsappNumber'),
                        facebookUrl: formData.get('facebookUrl'),
                        instagramUrl: formData.get('instagramUrl'),
                        youtubeUrl: formData.get('youtubeUrl'),
                        bkashNumber: formData.get('bkashNumber'),
                        nagadNumber: formData.get('nagadNumber'),
                        rocketNumber: formData.get('rocketNumber'),
                        firebaseConfig
                      };
                      
                      try {
                        let willReload = false;
                        if (firebaseConfig.apiKey && firebaseConfig.projectId) {
                          localStorage.setItem('customFirebaseConfig', JSON.stringify(firebaseConfig));
                          willReload = true;
                        } else {
                          localStorage.removeItem('customFirebaseConfig');
                        }

                        if (settings?.id) {
                          await saveSettings(settings.id, settingsData);
                        } else {
                          await saveSettings('global', settingsData);
                        }
                        showToast('Settings saved successfully!');

                        if (willReload) {
                          setTimeout(() => {
                             window.location.reload();
                          }, 1000);
                        }
                      } catch (error) {
                        showToast('Error saving settings', 'error');
                      }
                  }}
                >
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
                    <div>
                      <h2 className="text-3xl font-black text-[#0f172a] tracking-tight">Core Settings</h2>
                      <p className="text-sm text-gray-500 font-bold uppercase tracking-widest mt-1">Foundational Store Parameters</p>
                    </div>
                    <button type="submit" className="flex items-center gap-3 px-10 py-5 bg-[#0f172a] text-white font-black rounded-[1.5rem] hover:shadow-2xl transition-all active:scale-95 text-xs uppercase tracking-[0.2em] shadow-lg">
                      <Save className="w-5 h-5" /> Persist Changes
                    </button>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                     <div className="lg:col-span-2 space-y-10">
                        <section className="bg-white rounded-[2.5rem] p-10 shadow-[0_10px_40px_-10px_rgba(0,0,0,0.02)] border border-gray-100">
                           <h3 className="text-xl font-black text-gray-900 mb-10 pb-6 border-b border-gray-50 flex items-center gap-3">
                              <div className="p-2 bg-slate-50 text-slate-600 rounded-xl"><Settings className="w-5 h-5" /></div>
                              Identity & Branding
                           </h3>
                           <div className="space-y-8">
                              <div className="space-y-3">
                                 <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Site Display Name</label>
                                 <input type="text" name="siteName" defaultValue={settings?.siteName} className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-primary-500/10 font-bold text-gray-900 outline-none" required />
                              </div>
                              <div className="grid grid-cols-2 gap-6">
                                 <div className="space-y-3">
                                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Support Email</label>
                                    <input type="email" name="siteEmail" defaultValue={settings?.email || settings?.siteEmail} className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-primary-500/10 font-bold text-gray-900 outline-none" />
                                 </div>
                                 <div className="space-y-3">
                                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Official Hotline</label>
                                    <input type="tel" name="sitePhone" defaultValue={settings?.phone || settings?.sitePhone} className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-primary-500/10 font-bold text-gray-900 outline-none" />
                                 </div>
                              </div>
                              <div className="space-y-3">
                                 <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Physical HQ Address</label>
                                 <textarea name="siteAddress" defaultValue={settings?.address || settings?.siteAddress} className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-primary-500/10 font-bold text-gray-900 outline-none min-h-[120px]" rows={3} />
                              </div>
                           </div>
                        </section>

                        <section className="bg-white rounded-[2.5rem] p-10 shadow-[0_10px_40px_-10px_rgba(0,0,0,0.02)] border border-gray-100">
                           <h3 className="text-xl font-black text-gray-900 mb-10 pb-6 border-b border-gray-50 flex items-center gap-3">
                              <div className="p-2 bg-pink-50 text-pink-600 rounded-xl"><Share2 className="w-5 h-5" /></div>
                              Social Presence
                           </h3>
                           <div className="grid grid-cols-2 gap-8">
                               <div className="space-y-3">
                                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">WhatsApp (With Country Code)</label>
                                  <input type="text" name="whatsappNumber" defaultValue={settings?.whatsappNumber} className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-green-500/10 font-bold text-gray-900 outline-none" placeholder="8801XXXXXXXXX" />
                               </div>
                               <div className="space-y-3">
                                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Facebook Page URL</label>
                                  <input type="url" name="facebookUrl" defaultValue={settings?.facebook || settings?.facebookUrl} className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-blue-500/10 font-bold text-gray-900 outline-none" />
                               </div>
                               <div className="space-y-3">
                                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Instagram Handle</label>
                                  <input type="url" name="instagramUrl" defaultValue={settings?.instagramUrl} className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-pink-500/10 font-bold text-gray-900 outline-none" />
                               </div>
                               <div className="space-y-3">
                                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">YouTube Channel</label>
                                  <input type="url" name="youtubeUrl" defaultValue={settings?.youtube || settings?.youtubeUrl} className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-red-500/10 font-bold text-gray-900 outline-none" />
                               </div>
                               <div className="space-y-3">
                                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">bKash Number</label>
                                  <input type="text" name="bkashNumber" defaultValue={settings?.bkashNumber} className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-pink-500/10 font-bold text-gray-900 outline-none" />
                               </div>
                               <div className="space-y-3">
                                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Nagad Number</label>
                                  <input type="text" name="nagadNumber" defaultValue={settings?.nagadNumber} className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-orange-500/10 font-bold text-gray-900 outline-none" />
                               </div>
                               <div className="space-y-3">
                                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Rocket Number</label>
                                  <input type="text" name="rocketNumber" defaultValue={settings?.rocketNumber} className="w-full px-6 py-4 bg-gray-50 border-none rounded-2xl focus:ring-4 focus:ring-purple-500/10 font-bold text-gray-900 outline-none" />
                               </div>
                           </div>
                        </section>
                     </div>

                     <div className="space-y-10">
                        <div className="bg-[#0f172a] rounded-[2.5rem] p-10 text-white shadow-2xl relative overflow-hidden group">
                           <div className="absolute top-0 right-0 p-8 opacity-10 group-hover:scale-110 transition-transform duration-700">
                             <Shield className="w-32 h-32" />
                           </div>
                           <div className="relative z-10">
                              <h4 className="text-xl font-black mb-2 tracking-tight">Security Protocol</h4>
                              <p className="text-white/40 text-[10px] font-bold uppercase tracking-[0.2em] mb-10">System encryption active</p>
                              <div className="space-y-6">
                                 <div className="p-6 bg-white/5 rounded-2xl border border-white/10">
                                    <p className="text-[10px] font-black uppercase tracking-widest text-white/40 mb-2">Encryption Key</p>
                                    <p className="font-mono text-xs text-accent break-all">AES-256-GCM-SYSTEM-CORE</p>
                                 </div>
                                 <div className="p-6 bg-white/5 rounded-2xl border border-white/10">
                                    <p className="text-[10px] font-black uppercase tracking-widest text-white/40 mb-2">Admin Session</p>
                                    <p className="font-bold text-xs text-green-400 flex items-center gap-2">
                                       <span className="w-2 h-2 rounded-full bg-green-400 animate-ping"></span>
                                       Verified & Secure
                                    </p>
                                 </div>
                              </div>
                           </div>
                        </div>
                        
                        <div className="bg-amber-50 rounded-[2.5rem] p-10 border border-amber-100 group">
                           <h4 className="text-sm font-black text-amber-900 mb-4 flex items-center gap-3">
                              <HelpCircle className="w-5 h-5" /> Configuration Tip
                           </h4>
                           <p className="text-xs text-amber-800/70 font-bold leading-relaxed uppercase tracking-wider">
                              Changes made here affect all store modules instantly. Please verify support contact details before persisting to production.
                           </p>
                        </div>

                        <section className="bg-white rounded-[2.5rem] p-10 shadow-[0_10px_40px_-10px_rgba(0,0,0,0.02)] border border-gray-100 overflow-hidden">
                           <h3 className="text-xl font-black text-gray-900 mb-10 pb-6 border-b border-gray-50 flex items-center gap-3">
                              <div className="p-2 bg-orange-50 text-orange-600 rounded-xl"><Database className="w-5 h-5" /></div>
                              Cloud Connector (Firebase)
                           </h3>
                           <div className="p-6 bg-red-50 border border-red-100 rounded-2xl mb-8">
                              <p className="text-[10px] text-red-600 font-black uppercase tracking-widest leading-relaxed">
                                 CAUTION: These credentials connect your admin panel to external data clusters. Incorrect values will break synchronization.
                              </p>
                           </div>
                           <div className="space-y-6">
                              <div className="grid grid-cols-2 gap-6">
                                 <div className="space-y-2">
                                    <label className="text-[9px] font-black uppercase text-gray-400 tracking-widest">API Key</label>
                                    <input type="text" name="fb_apiKey" defaultValue={settings?.firebaseConfig?.apiKey} className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl font-bold text-xs outline-none focus:ring-2 focus:ring-orange-500/20" />
                                 </div>
                                 <div className="space-y-2">
                                    <label className="text-[9px] font-black uppercase text-gray-400 tracking-widest">Project ID</label>
                                    <input type="text" name="fb_projectId" defaultValue={settings?.firebaseConfig?.projectId} className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl font-bold text-xs outline-none focus:ring-2 focus:ring-orange-500/20" />
                                 </div>
                              </div>
                              <div className="grid grid-cols-2 gap-6">
                                 <div className="space-y-2">
                                    <label className="text-[9px] font-black uppercase text-gray-400 tracking-widest">Auth Domain</label>
                                    <input type="text" name="fb_authDomain" defaultValue={settings?.firebaseConfig?.authDomain} className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl font-bold text-xs outline-none focus:ring-2 focus:ring-orange-500/20" />
                                 </div>
                                 <div className="space-y-2">
                                    <label className="text-[9px] font-black uppercase text-gray-400 tracking-widest">App ID</label>
                                    <input type="text" name="fb_appId" defaultValue={settings?.firebaseConfig?.appId} className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl font-bold text-xs outline-none focus:ring-2 focus:ring-orange-500/20" />
                                 </div>
                              </div>
                              <div className="space-y-2">
                                 <label className="text-[9px] font-black uppercase text-gray-400 tracking-widest">Database ID (Optional)</label>
                                 <input type="text" name="fb_databaseId" defaultValue={settings?.firebaseConfig?.databaseId} className="w-full px-4 py-3 bg-gray-50 border-none rounded-xl font-bold text-xs outline-none focus:ring-2 focus:ring-orange-500/20" />
                              </div>
                           </div>
                        </section>
                     </div>
                  </div>
                </form>
              </div>
            )}

            {activeTab === 'returns' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] p-8">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-xl font-black text-gray-900">Return Requests</h2>
                    <p className="text-sm text-gray-500 mt-1">Manage product return and refund requests</p>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead className="bg-gray-50 text-[10px] text-gray-500 uppercase tracking-widest font-black border-b border-gray-100">
                      <tr>
                        <th className="px-6 py-4">Customer</th>
                        <th className="px-6 py-4">Order ID</th>
                        <th className="px-6 py-4">Reason</th>
                        <th className="px-6 py-4">Date</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {returns.map((ret) => (
                        <tr key={ret.id}>
                          <td className="px-6 py-4">
                            <div className="font-bold text-gray-900">{ret.customerName}</div>
                            <div className="text-xs text-gray-400">{ret.phone}</div>
                          </td>
                          <td className="px-6 py-4 font-mono text-xs">#{ret.orderId?.slice(-8).toUpperCase()}</td>
                          <td className="px-6 py-4 text-sm text-gray-600 max-w-xs truncate">{ret.reason}</td>
                          <td className="px-6 py-4 text-xs text-gray-500">{new Date(ret.createdAt).toLocaleDateString()}</td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              ret.status === 'completed' ? 'bg-green-100 text-green-700' : 
                              ret.status === 'rejected' ? 'bg-red-100 text-red-700' :
                              'bg-amber-100 text-amber-700'
                            }`}>
                              {ret.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-right flex items-center justify-end gap-2">
                             <button 
                               onClick={async () => {
                                 if (confirm('Delete this return request?')) {
                                   try {
                                      await deleteReturnRequest(ret.id);
                                      showToast('Return request deleted');
                                   } catch (e: any) {
                                      showToast('Failed to delete', 'error');
                                   }
                                 }
                               }}
                               className="p-2 bg-gray-50 text-gray-400 hover:bg-red-50 hover:text-red-500 rounded"
                               title="Delete"
                             >
                                <Trash2 className="w-4 h-4" />
                             </button>
                             {ret.status === 'pending' && (
                                <>
                                  <button 
                                    onClick={async () => {
                                       await updateReturnStatus(ret.id, 'approved', ret.orderId);
                                       showToast('Return approved successfully!');
                                    }}
                                    className="p-2 bg-green-50 text-green-600 hover:bg-green-100 rounded"
                                    title="Approve"
                                  >
                                    <CheckCircle className="w-4 h-4" />
                                  </button>
                                  <button 
                                    onClick={async () => {
                                       await updateReturnStatus(ret.id, 'approved', ret.orderId);
                                       if (ret.items && ret.items.length) {
                                          await restockItems(ret.items);
                                       }
                                       showToast('Return approved and items restocked!');
                                    }}
                                    className="p-2 bg-blue-50 text-blue-600 hover:bg-blue-100 rounded"
                                    title="Approve & Restock"
                                  >
                                    <RefreshCcw className="w-4 h-4" />
                                  </button>
                                  <button 
                                    onClick={() => updateReturnStatus(ret.id, 'rejected', ret.orderId)}
                                    className="p-2 bg-red-50 text-red-600 hover:bg-red-100 rounded"
                                    title="Reject"
                                  >
                                    <XCircle className="w-4 h-4" />
                                  </button>
                                </>
                              )}
                          </td>
                        </tr>
                      ))}
                      {returns.length === 0 && (
                        <tr>
                          <td colSpan={6} className="px-6 py-12 text-center text-gray-500">No return requests found.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'banners' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] p-8">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-xl font-black text-gray-900">Banners</h2>
                    <p className="text-sm text-gray-500">Manage home page banners and promotional images</p>
                  </div>
                  <button 
                    onClick={() => {
                      setModalConfig({
                        isOpen: true,
                        title: 'Add Site Image',
                        fields: [
                          { name: 'url', label: 'Image URL' },
                          { name: 'title', label: 'Title (optional)', required: false },
                          { 
                            name: 'targetUrl', 
                            label: 'Target Product/Link', 
                            type: 'select', 
                            options: [
                              { label: 'No Link', value: '' },
                              ...products.map(p => ({ label: `Product: ${p.name}`, value: `/product/${p.id}` })),
                              ...categories.map(c => ({ label: `Category: ${c.name}`, value: `/products?category=${c.name}` })),
                              ...brands.map(b => ({ label: `Brand: ${b.name}`, value: `/products?brand=${b.name}` }))
                            ]
                          }
                        ],
                        onSubmit: async (data: any) => {
                          try {
                            await addSiteImage({ 
                              url: data.url, 
                              title: data.title || '',
                              targetUrl: data.targetUrl || '',
                              link: data.targetUrl || '',
                              type: 'hero',
                              section: 'hero'
                            });
                            showToast('Image added!');
                          } catch (e: any) {
                            showToast('Failed: ' + e.message, 'error');
                          }
                        }
                      });
                    }}
                    className="bg-primary-700 text-white px-6 py-2.5 rounded-xl font-bold shadow-md hover:bg-primary-800 transition-all active:scale-[0.98] text-sm"
                  >
                    + Add Slider Image
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {siteImages.map((img) => (
                    <div key={img.id} className="group relative rounded-xl overflow-hidden border border-gray-100 shadow-sm aspect-video">
                      <img src={img.url} referrerPolicy="no-referrer" className="w-full h-full object-cover" alt={img.title} />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                        <button 
                          onClick={() => {
                            if (confirm('Delete image?')) deleteSiteImage(img.id);
                          }}
                          className="bg-white text-red-600 p-2 rounded-full hover:bg-red-50"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                      {img.title && (
                        <div className="absolute bottom-0 inset-x-0 p-3 bg-gradient-to-t from-black/80 to-transparent text-white text-xs font-bold">
                          {img.title}
                        </div>
                      )}
                    </div>
                  ))}
                  {siteImages.length === 0 && <div className="col-span-full py-12 text-center text-gray-500">No site images found.</div>}
                </div>
              </div>
            )}


            {activeTab === 'resellers' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] p-8">
                <div className="flex items-center justify-between mb-8">
                  <h2 className="text-xl font-black text-gray-900">Resellers</h2>
                  <button 
                    onClick={() => {
                      setModalConfig({
                        isOpen: true,
                        title: 'Add Reseller',
                        fields: [
                          { name: 'name', label: 'Reseller Name' },
                          { name: 'phone', label: 'Reseller Phone' }
                        ],
                        onSubmit: async (data: any) => {
                          try {
                            await addReseller({ name: data.name, phone: data.phone });
                            showToast('Reseller added!');
                          } catch (e: any) {
                            showToast('Failed: ' + e.message, 'error');
                          }
                        }
                      });
                    }}
                    className="bg-primary-700 text-white px-6 py-2.5 rounded-xl font-bold shadow-md hover:bg-primary-800 transition-all active:scale-[0.98] text-sm"
                  >
                    + Add Reseller
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead className="bg-gray-50 text-[10px] text-gray-500 uppercase tracking-widest font-black border-b border-gray-100">
                      <tr>
                        <th className="px-6 py-4">Name</th>
                        <th className="px-6 py-4">Contact</th>
                        <th className="px-6 py-4">Balance</th>
                        <th className="px-6 py-4 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {resellers.map((r) => (
                        <tr key={r.id}>
                          <td className="px-6 py-4 font-bold text-gray-900">{r.name}</td>
                          <td className="px-6 py-4 text-gray-600">{r.phone}</td>
                          <td className="px-6 py-4 font-bold text-primary-700">৳ {r.balance || 0}</td>
                          <td className="px-6 py-4 text-right flex items-center justify-end gap-3">
                             <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${r.status === 'approved' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                               {r.status || 'pending'}
                             </span>
                             <button 
                               onClick={async () => {
                                 if (confirm('Delete reseller?')) {
                                   try {
                                     await deleteReseller(r.id);
                                     showToast('Reseller removed');
                                   } catch (e: any) {
                                     showToast('Error', 'error');
                                   }
                                 }
                               }}
                               className="p-1.5 text-red-500 hover:bg-red-50 rounded transition-all"
                             >
                                <Trash2 className="w-4 h-4" />
                             </button>
                             {r.status !== 'approved' && (
                               <button 
                                 onClick={async () => {
                                   if (confirm('Approve this reseller?')) {
                                     
                                     await updateDoc(doc(db, 'resellers', r.id), { status: 'approved' });
                                     showToast('Reseller approved!');
                                   }
                                 }}
                                 className="px-3 py-1 bg-primary-700 text-white text-[10px] font-black rounded hover:bg-primary-800 transition-colors"
                               >
                                 Approve
                               </button>
                             )}
                          </td>
                        </tr>
                      ))}
                      {resellers.length === 0 && (
                        <tr>
                          <td colSpan={4} className="px-6 py-12 text-center text-gray-500">No resellers registered yet.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'withdrawals' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] p-8">
                <h2 className="text-xl font-black text-gray-900 mb-8">Withdrawal Requests</h2>
                <div className="overflow-x-auto">
                  <table className="w-full text-left">
                    <thead className="bg-gray-50 text-[10px] text-gray-500 uppercase tracking-widest font-black border-b border-gray-100">
                      <tr>
                        <th className="px-6 py-4">Reseller ID</th>
                        <th className="px-6 py-4">Amount</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4">Created</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {withdrawals.map((w) => (
                        <tr key={w.id}>
                          <td className="px-6 py-4 font-mono text-xs">{w.resellerId}</td>
                          <td className="px-6 py-4 font-bold">৳ {w.amount}</td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${w.status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                              {w.status}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-gray-500 text-xs">
                             {new Date(w.createdAt).toLocaleDateString()}
                          </td>
                          <td className="px-6 py-4 text-right flex items-center justify-end gap-3">
                             <button 
                               onClick={async () => {
                                 if (confirm('Delete withdrawal record?')) {
                                   try {
                                     await deleteWithdrawal(w.id);
                                     showToast('Record deleted');
                                   } catch (e: any) {
                                     showToast('Error', 'error');
                                   }
                                 }
                               }}
                               className="p-1.5 text-red-500 hover:bg-red-50 rounded transition-all"
                             >
                                <Trash2 className="w-4 h-4" />
                             </button>
                             {w.status === 'pending' && (
                               <button 
                                 onClick={async () => {
                                   if (confirm('Mark this withdrawal as completed?')) {
                                     
                                     await updateDoc(doc(db, 'withdrawals', w.id), { status: 'completed' });
                                     showToast('Withdrawal completed!');
                                   }
                                 }}
                                 className="px-3 py-1 bg-green-600 text-white text-[10px] font-black rounded hover:bg-green-700 transition-colors"
                               >
                                 Mark Done
                               </button>
                             )}
                          </td>
                        </tr>
                      ))}
                      {withdrawals.length === 0 && (
                        <tr>
                          <td colSpan={4} className="px-6 py-12 text-center text-gray-500">No pending withdrawals.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'payment-history' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] p-8">
                <h2 className="text-xl font-black text-gray-900 mb-8">Payment History</h2>
                <div className="overflow-x-auto">
                  <table className="w-full text-left font-sans">
                    <thead className="bg-gray-50 text-[10px] text-gray-500 uppercase tracking-widest font-black border-b border-gray-100">
                      <tr>
                        <th className="px-6 py-4">Transaction ID</th>
                        <th className="px-6 py-4">Order ID</th>
                        <th className="px-6 py-4">Customer</th>
                        <th className="px-6 py-4">Amount</th>
                        <th className="px-6 py-4">Method</th>
                        <th className="px-6 py-4 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {orders.filter(o => o.status === 'delivered').length === 0 ? (
                        <tr><td colSpan={6} className="px-6 py-12 text-center text-gray-500">No payment history available.</td></tr>
                      ) : orders.filter(o => o.status === 'delivered').map((order) => (
                        <tr key={order.id}>
                          <td className="px-6 py-4 font-mono text-xs text-gray-500">TXN-{order.id.slice(-8).toUpperCase()}</td>
                          <td className="px-6 py-4 font-bold text-primary-900">#{order.id.slice(0,8).toUpperCase()}</td>
                          <td className="px-6 py-4 text-gray-600">{order.customerName}</td>
                          <td className="px-6 py-4 font-bold text-gray-900">৳ {order.totalAmount}</td>
                          <td className="px-6 py-4 text-xs font-bold text-gray-500 uppercase">Cash on Delivery</td>
                          <td className="px-6 py-4 text-right">
                             <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase">Success</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {activeTab === 'ui-config' && (
              <div className="space-y-12 max-w-7xl pb-20">
                <form 
                  className="space-y-12"
                  onSubmit={async (e) => {
                    e.preventDefault();
                    const formData = new FormData(e.currentTarget);
                    
                    const data = Object.fromEntries(formData.entries());
                    
                    const uiConfigData = {
                      ...settings,
                      ...data,
                      flashSaleActive: formData.get('flashSaleActive') === 'on',
                    };
                    
                    try {
                      if (settings?.id) {
                        await saveSettings(settings.id, uiConfigData);
                      } else {
                        await saveSettings('global', uiConfigData);
                      }
                      showToast('UI Configuration updated successfully!');
                    } catch (error) {
                      showToast('Error updating configuration', 'error');
                    }
                  }}
                >
                  <div className="flex flex-col sm:flex-row items-center justify-between gap-8 pb-8">
                    <div>
                      <h2 className="text-3xl font-black text-[#0f172a] tracking-tight">UI Configuration</h2>
                      <p className="text-gray-500 mt-1">Manage banners, campaigns, and homepage sections.</p>
                    </div>
                    <button type="submit" className="flex items-center gap-2 px-6 py-3 bg-[#f97316] text-white font-bold rounded-xl hover:bg-[#ea580c] transition-all">
                      <Save className="w-5 h-5" /> Save Changes
                    </button>
                  </div>
                  
                  <div className="flex gap-4 p-2 bg-gray-50 rounded-2xl w-fit mb-8 border border-gray-100 flex-wrap">
                    <button type="button" onClick={() => setUiConfigTab('hero-banners')} className={`px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all ${uiConfigTab === 'hero-banners' ? 'bg-white text-[#f97316] shadow-sm' : 'text-gray-500 hover:bg-gray-100'}`}>
                       <Image className="w-4 h-4" /> Hero Banners
                    </button>
                    <button type="button" onClick={() => setUiConfigTab('top-campaign')} className={`px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all ${uiConfigTab === 'top-campaign' ? 'bg-white text-[#0f172a] shadow-sm' : 'text-gray-500 hover:bg-gray-100'}`}>
                       <ArrowRight className="w-4 h-4" /> Thin Banner
                    </button>
                    <button type="button" onClick={() => setUiConfigTab('promo-banners')} className={`px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all ${uiConfigTab === 'promo-banners' ? 'bg-white text-[#f97316] shadow-sm' : 'text-gray-500 hover:bg-gray-100'}`}>
                       <Layers className="w-4 h-4" /> 3 Promo Banners
                    </button>
                    <button type="button" onClick={() => setUiConfigTab('flash-sale')} className={`px-6 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all ${uiConfigTab === 'flash-sale' ? 'bg-white text-[#f97316] shadow-sm' : 'text-gray-500 hover:bg-gray-100'}`}>
                       <Zap className="w-4 h-4" /> Flash Sale
                    </button>
                  </div>

                  <div className={uiConfigTab === 'hero-banners' ? 'block' : 'hidden'}>
                     <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm">
                        <div className="flex items-center justify-between mb-8 pb-4 border-b border-gray-50">
                           <h3 className="text-xl font-black text-gray-900 tracking-tight">Main Slider Banners</h3>
                        </div>
                        <div className="space-y-6">
                           <div className="p-6 border-2 border-primary-100 bg-primary-50 rounded-2xl flex flex-col md:flex-row gap-8 relative group mb-8">
                              <div className="absolute -top-3 left-6 bg-primary-900 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest italic">Hero Side Banner</div>
                              {settings?.heroSideBannerImage ? (
                                 <img src={settings?.heroSideBannerImage} className="w-full md:w-[300px] h-48 md:h-[160px] object-cover rounded-xl border border-gray-200" />
                              ) : (
                                 <div className="w-full md:w-[300px] h-48 md:h-[160px] bg-primary-100/50 border-2 border-dashed border-primary-200 rounded-xl flex items-center justify-center text-primary-400">
                                    No Image Provided
                                 </div>
                              )}
                              <div className="flex-1 space-y-4">
                                 <div className="space-y-2">
                                    <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Banner Title / Badge</label>
                                    <input type="text" name="heroSideBannerTitle" defaultValue={settings?.heroSideBannerTitle} className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm" placeholder="Weekly Feature" />
                                 </div>
                                 <div className="space-y-2">
                                    <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Image URL</label>
                                    <input type="text" name="heroSideBannerImage" defaultValue={settings?.heroSideBannerImage} className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm" placeholder="https://" />
                                 </div>
                                 <div className="space-y-2">
                                    <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Redirect Link</label>
                                    <input type="text" name="heroSideBannerUrl" defaultValue={settings?.heroSideBannerUrl} className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm" placeholder="/#products" />
                                 </div>
                              </div>
                           </div>

                           {[1, 2, 3].map(num => (
                              <div key={num} className="p-6 border border-gray-100 bg-gray-50/50 rounded-2xl flex flex-col md:flex-row gap-8 relative group">
                                 {settings?.[`belowHeroAd${num}Image` as keyof SiteSettings] ? (
                                    <img src={settings?.[`belowHeroAd${num}Image` as keyof SiteSettings] as string} className="w-full md:w-[300px] h-48 md:h-[160px] object-cover rounded-xl border border-gray-200" />
                                 ) : (
                                    <div className="w-full md:w-[300px] h-48 md:h-[160px] bg-indigo-50 border-2 border-dashed border-indigo-200 rounded-xl flex items-center justify-center text-indigo-400">
                                       No Image Provided
                                    </div>
                                 )}
                                 <div className="flex-1 space-y-6">
                                    <div className="space-y-2">
                                       <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Banner Image</label>
                                       <div className="w-full border border-dashed border-gray-200 rounded-xl p-4 flex flex-col items-center justify-center bg-white text-gray-400 cursor-pointer hover:border-gray-300">
                                          <Image className="w-6 h-6 mb-2" />
                                          <span className="text-sm font-bold">Click to upload</span>
                                       </div>
                                       <p className="text-center text-[10px] uppercase font-bold text-gray-300 my-2">Or URL</p>
                                       <input type="text" name={`belowHeroAd${num}Image`} defaultValue={settings?.[`belowHeroAd${num}Image` as keyof SiteSettings] as string} className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm" placeholder="https://" />
                                    </div>
                                    <div className="space-y-2">
                                       <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Redirect Link</label>
                                       <input type="text" name={`belowHeroAd${num}Url`} defaultValue={settings?.[`belowHeroAd${num}Url` as keyof SiteSettings] as string} className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm" placeholder="/#products" />
                                    </div>
                                 </div>
                              </div>
                           ))}
                        </div>
                     </div>
                  </div>

                  <div className={uiConfigTab === 'top-campaign' ? 'block' : 'hidden'}>
                     <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm space-y-8">
                        <div className="flex items-center justify-between">
                           <h3 className="text-xl font-black text-gray-900 tracking-tight">Focus Campaign Banner (Thin)</h3>
                           <div className="px-3 py-1 bg-[#0f172a] text-white text-[10px] font-black uppercase rounded-lg">Above Flash Sale</div>
                        </div>
                        <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl flex items-start gap-4">
                           <Monitor className="w-6 h-6 text-slate-500 shrink-0" />
                           <p className="text-slate-600 text-sm font-medium italic">This banner is designed to be wide and thin. Recommended aspect ratio is 8:1 (e.g. 1600x200px).</p>
                        </div>
                        <div className="space-y-6">
                           <div className="space-y-2">
                              <label className="text-sm font-bold text-gray-900">Banner Image URL</label>
                              <input type="text" name="topCampaignBannerImage" defaultValue={settings?.topCampaignBannerImage} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 outline-none" placeholder="https://..." />
                           </div>
                           <div className="space-y-2">
                              <label className="text-sm font-bold text-gray-900">Banner Link (Redirect URL)</label>
                              <div className="relative">
                                 <LinkIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                                 <input type="text" name="topCampaignBannerUrl" defaultValue={settings?.topCampaignBannerUrl} className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 outline-none" placeholder="/#products" />
                              </div>
                           </div>
                           {settings?.topCampaignBannerImage && (
                              <div className="space-y-2">
                                 <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Live Preview</label>
                                 <div className="w-full bg-gray-100 rounded-xl overflow-hidden border border-gray-200 p-2">
                                    <img src={settings.topCampaignBannerImage} className="w-full h-auto max-h-[100px] object-cover rounded-lg" alt="Preview" />
                                 </div>
                              </div>
                           )}
                        </div>
                     </div>
                  </div>

                  <div className={uiConfigTab === 'campaign-banner' ? 'block' : 'hidden'}>
                     <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm space-y-8">
                        <h3 className="text-xl font-black text-gray-900 tracking-tight">Campaign Banner (Eid Fest)</h3>
                        <div className="bg-orange-50 border border-orange-200 p-4 rounded-xl flex items-start gap-4">
                           <Activity className="w-6 h-6 text-orange-500 shrink-0" />
                           <p className="text-orange-700 text-sm">This banner appears in the middle of the homepage. You can set separate images for desktop and mobile.</p>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                           <div className="space-y-2">
                              <label className="text-sm font-bold text-gray-900">Campaign Name</label>
                              <input type="text" name="campaignTitle" defaultValue={settings?.campaignTitle} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" placeholder="Eid Fest" />
                           </div>
                           <div className="space-y-2">
                              <label className="text-sm font-bold text-gray-900">Offer Text (e.g. Up to 75% OFF)</label>
                              <input type="text" name="campaignSubtitle" defaultValue={settings?.campaignSubtitle} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" placeholder="Up to 75% OFF" />
                           </div>
                        </div>
                        <div className="space-y-2">
                           <label className="text-sm font-bold text-gray-900">Desktop Image URL</label>
                           <input type="text" name="midPageAd1Image" defaultValue={settings?.midPageAd1Image} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" />
                        </div>
                        <div className="space-y-2">
                           <label className="text-sm font-bold text-gray-900">Mobile Image URL</label>
                           <input type="text" name="midPageAd2Image" defaultValue={settings?.midPageAd2Image} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" />
                        </div>
                        <div className="space-y-2 pt-6 border-t border-gray-100 mt-6">
                           <h4 className="text-md font-bold text-gray-900 mb-4">Cooking Essentials Section Banner</h4>
                           <label className="text-sm font-bold text-gray-900">Banner Image URL</label>
                           <input type="text" name="cookingEssentialsBannerImage" defaultValue={settings?.cookingEssentialsBannerImage} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" placeholder="https://unsplash..." />
                        </div>
                        <div className="space-y-2">
                           <label className="text-sm font-bold text-gray-900">Banner Redirect URL</label>
                           <input type="text" name="cookingEssentialsBannerUrl" defaultValue={settings?.cookingEssentialsBannerUrl} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" placeholder="/category/Spices" />
                        </div>
                     </div>
                  </div>

                  <div className={uiConfigTab === 'promo-banners' ? 'block' : 'hidden'}>
                     <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm space-y-8">
                        <div className="flex items-center justify-between">
                           <h3 className="text-xl font-black text-gray-900 tracking-tight">3 Promo Banners</h3>
                           <div className="px-3 py-1 bg-[#0f172a] text-white text-[10px] font-black uppercase rounded-lg">Home Page</div>
                        </div>
                        <div className="bg-slate-50 border border-slate-100 p-4 rounded-xl flex items-start gap-4">
                           <Layers className="w-6 h-6 text-slate-500 shrink-0" />
                           <p className="text-slate-600 text-sm font-medium">These 3 banners appear side-by-side. On desktop they are 3 columns, on mobile they stack as 1 column.</p>
                        </div>
                        
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                           {[1, 2, 3].map(num => (
                              <div key={num} className="p-6 bg-gray-50 border border-gray-200 rounded-2xl relative">
                                 <div className="absolute top-4 right-4 bg-white text-gray-900 text-xs font-black w-6 h-6 rounded-full flex items-center justify-center border border-gray-200">{num}</div>
                                 <h4 className="font-bold text-gray-900 mb-6">Banner {num}</h4>
                                 <div className="space-y-4">
                                    <div className="space-y-2">
                                       <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Image URL</label>
                                       <input type="text" name={`promoBanner${num}Image`} defaultValue={settings?.[`promoBanner${num}Image` as keyof SiteSettings] as string} className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm" placeholder="https://" />
                                    </div>
                                    <div className="space-y-2">
                                       <label className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Redirect Link</label>
                                       <input type="text" name={`promoBanner${num}Url`} defaultValue={settings?.[`promoBanner${num}Url` as keyof SiteSettings] as string} className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm" placeholder="/#products" />
                                    </div>
                                    {settings?.[`promoBanner${num}Image` as keyof SiteSettings] && (
                                       <img src={settings[`promoBanner${num}Image` as keyof SiteSettings] as string} alt={`Banner ${num}`} className="w-full h-[100px] object-cover rounded-lg border border-gray-200" />
                                    )}
                                 </div>
                              </div>
                           ))}
                        </div>
                     </div>
                  </div>

                  <div className={uiConfigTab === 'flash-sale' ? 'block' : 'hidden'}>
                     <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm space-y-8">
                         <h3 className="text-xl font-black text-gray-900 tracking-tight">Flash Sale Settings</h3>
                         <div className="flex items-center gap-4">
                            <label className="relative inline-flex items-center cursor-pointer">
                              <input type="checkbox" name="flashSaleActive" defaultChecked={settings?.flashSaleActive} className="sr-only peer" />
                              <div className="w-14 h-7 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-[#f97316]"></div>
                            </label>
                           <span className="font-black text-gray-900">Flash Sale Active</span>
                        </div>
                        <div className="space-y-2">
                           <label className="text-sm font-bold text-gray-900">Sale Title</label>
                           <input type="text" name="flashSaleTitle" defaultValue={settings?.flashSaleTitle} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" placeholder="Super Sale Is Live Now" />
                        </div>
                        <div className="grid grid-cols-1 gap-6">
                           <div className="space-y-2">
                              <label className="text-sm font-bold text-gray-900">End Time</label>
                              <input type="datetime-local" name="flashSaleEndTime" defaultValue={settings?.flashSaleEndTime} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" />
                           </div>
                        </div>
                     </div>
                  </div>

                  <div className={uiConfigTab === 'home-sections' ? 'block' : 'hidden'}>
                     <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm space-y-8">
                        <h3 className="text-xl font-black text-gray-900 tracking-tight">Homepage Section Config</h3>
                        <p className="text-sm text-gray-500">Configure which category or product tag is displayed in each homepage section.</p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                           {[1, 2, 3, 4].map(num => (
                              <div key={num} className="p-6 bg-gray-50 border border-gray-100 rounded-2xl space-y-6">
                                 <h4 className="font-black text-primary-950 uppercase text-xs tracking-widest border-b border-gray-100 pb-4">Section {num}</h4>
                                 <div className="space-y-2">
                                    <label className="text-sm font-bold text-gray-900">Section Title</label>
                                    <input type="text" name={`homeSection${num}Title`} defaultValue={settings?.[`homeSection${num}Title` as keyof SiteSettings] as string} className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm" placeholder="e.g. Cooking Essentials" />
                                 </div>
                                 <div className="space-y-2">
                                    <label className="text-sm font-bold text-gray-900">Filter (Category Name or Tag)</label>
                                    <input type="text" name={`homeSection${num}Filter`} defaultValue={settings?.[`homeSection${num}Filter` as keyof SiteSettings] as string} className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm" placeholder="e.g. Honey / Spices / সেরা অফার" />
                                 </div>
                              </div>
                           ))}
                        </div>
                     </div>
                  </div>

                  <div className={uiConfigTab === 'service-icons' ? 'block' : 'hidden'}>
                     <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm">
                        <h3 className="text-xl font-black text-gray-900 tracking-tight mb-8">Service Icons</h3>
                        <p className="text-sm text-gray-500">Service Icons feature implementation requires backend configuration for dynamic icons. Coming soon.</p>
                     </div>
                  </div>

                  <div className={uiConfigTab === 'general' ? 'block' : 'hidden'}>
                     <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm space-y-8">
                         <h3 className="text-xl font-black text-gray-900 tracking-tight">General, Maps & SMS Settings</h3>
                         <div className="space-y-4">
                            <div className="space-y-2">
                               <label className="text-sm font-bold text-gray-900">Contact Number</label>
                               <input type="text" name="contactNumber" defaultValue={settings?.contactNumber} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" placeholder="+880 1878 145559" />
                            </div>
                            <div className="space-y-2">
                               <label className="text-sm font-bold text-gray-900">Contact Email</label>
                               <input type="text" name="contactEmailGeneral" defaultValue={settings?.contactEmailGeneral} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" placeholder="admin@kholosshop.com" />
                            </div>
                            <div className="space-y-2">
                               <label className="text-sm font-bold text-gray-900">Address / Location</label>
                               <input type="text" name="contactAddress" defaultValue={settings?.contactAddress} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" placeholder="Dhaka, Bangladesh" />
                            </div>
                            <div className="space-y-2 pt-4">
                               <label className="text-sm font-bold text-gray-900">Google Map iframe "src" URL</label>
                               <p className="text-xs text-gray-500 mb-2">Paste the "src" URL from Google Maps Embed (https://www.google.com/maps/embed?...)</p>
                               <input type="text" name="googleMapUrl" defaultValue={settings?.googleMapUrl} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" placeholder="https://www.google.com/maps/embed?..." />
                            </div>
                            {settings?.googleMapUrl && (
                               <div className="mt-4 rounded-xl overflow-hidden border border-gray-200 h-64">
                                  <iframe src={settings.googleMapUrl} width="100%" height="100%" style={{border: 0}} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade"></iframe>
                               </div>
                            )}

                            <div className="pt-8 border-t border-gray-100 mt-8 space-y-4">
                               <h3 className="text-xl font-black text-gray-900 tracking-tight">SMS Gateway Config</h3>
                               <p className="text-xs text-gray-500 mb-4">Credentials for automated SMS delivery.</p>
                               <div className="space-y-2">
                                  <label className="text-sm font-bold text-gray-900">SMS API URL</label>
                                  <input type="text" name="smsApiUrl" defaultValue={settings?.smsApiUrl} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" placeholder="https://api.sms-provider.com/send" />
                               </div>
                               <div className="space-y-2">
                                  <label className="text-sm font-bold text-gray-900">API Key / Token</label>
                                  <input type="password" name="smsApiKey" defaultValue={settings?.smsApiKey} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" placeholder="••••••••••••" />
                               </div>
                               <div className="space-y-2">
                                  <label className="text-sm font-bold text-gray-900">Sender ID (Optional)</label>
                                  <input type="text" name="smsSenderId" defaultValue={settings?.smsSenderId} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl" placeholder="KholosShop" />
                               </div>
                            </div>
                         </div>
                     </div>
                  </div>
                </form>
              </div>
            )}

            {activeTab === 'shipping' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] p-8">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-xl font-black text-gray-900">Shipping Settings</h2>
                    <p className="text-sm text-gray-500">Configure delivery charges and rules</p>
                  </div>
                  <button className="flex items-center gap-2 px-6 py-2.5 bg-primary-700 text-white font-bold rounded-xl hover:bg-primary-800 transition-colors shadow-md active:scale-95">
                    <CheckCircle className="w-4 h-4" /> Save
                  </button>
                </div>

                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-b border-gray-100 pb-6">
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-2">Inside Dhaka Charge (৳)</label>
                      <input type="number" defaultValue="60" className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-2">Outside Dhaka Charge (৳)</label>
                      <input type="number" defaultValue="120" className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20" />
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-bold text-gray-900 mb-4">Free Shipping Condition</h3>
                    <div className="flex items-center gap-3 mb-4">
                       <input type="checkbox" id="freeShipping" defaultChecked className="w-5 h-5 text-primary-600 rounded" />
                       <label htmlFor="freeShipping" className="font-bold text-gray-700">Enable automated free shipping</label>
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-gray-700 mb-2">Minimum Order Amount for Free Shipping (৳)</label>
                      <input type="number" defaultValue="2000" className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 max-w-sm" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'payments' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] p-8">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-xl font-black text-gray-900">Payment Methods</h2>
                    <p className="text-sm text-gray-500">Manage available payment gateways</p>
                  </div>
                  <button className="flex items-center gap-2 px-6 py-2.5 bg-primary-700 text-white font-bold rounded-xl hover:bg-primary-800 transition-colors shadow-md active:scale-95">
                    <CheckCircle className="w-4 h-4" /> Save
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="border border-green-200 bg-green-50/50 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="font-bold text-gray-900 text-lg flex items-center gap-2">
                         <Truck className="w-5 h-5 text-green-600" /> Cash on Delivery (COD)
                      </h3>
                      <p className="text-sm text-gray-500 mt-1">Pay when the product arrives at your door.</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" value="" className="sr-only peer" defaultChecked />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
                    </label>
                  </div>

                  <div className="border border-pink-200 bg-pink-50/50 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="font-bold text-gray-900 text-lg flex items-center gap-2">
                         bKash Payment
                      </h3>
                      <p className="text-sm text-gray-500 mt-1 pb-3">Automated or manual bKash processing.</p>
                      <input type="text" placeholder="bKash Merchant/Personal Number" defaultValue="01887814559" className="px-3 py-1.5 border border-pink-300 rounded focus:ring-2 focus:ring-pink-500/20 text-sm w-64" />
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" value="" className="sr-only peer" defaultChecked />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-pink-600"></div>
                    </label>
                  </div>
                  
                  <div className="border border-blue-200 bg-blue-50/50 rounded-xl p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h3 className="font-bold text-gray-900 text-lg flex items-center gap-2">
                         SSLCommerz
                      </h3>
                      <p className="text-sm text-gray-500 mt-1">Accept cards, mobile banking, and net banking.</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" value="" className="sr-only peer" />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'activity-logs' && (
               <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] p-8">
                  <div className="flex items-center justify-between mb-8">
                     <div>
                        <h2 className="text-xl font-black text-gray-900">Activity Logs</h2>
                        <p className="text-sm text-gray-500">System audit trail and event tracking</p>
                     </div>
                     <button className="p-3 bg-gray-50 text-gray-400 hover:text-primary-700 rounded-xl transition-all">
                        <List className="w-5 h-5" />
                     </button>
                  </div>
                  <div className="space-y-4">
                     {[
                       { event: 'Order status updated', user: 'admin@kholosshop.com', time: '2 mins ago', color: 'bg-blue-500' },
                       { event: 'New product added', user: 'admin@kholosshop.com', time: '15 mins ago', color: 'bg-green-500' },
                       { event: 'Settings changed', user: 'nmd032984@gmail.com', time: '1 hour ago', color: 'bg-amber-500' },
                       { event: 'Withdrawal approved', user: 'admin@kholosshop.com', time: '3 hours ago', color: 'bg-indigo-500' },
                       { event: 'User account deleted', user: 'admin@kholosshop.com', time: 'Yesterday', color: 'bg-red-500' }
                     ].map((log, i) => (
                        <div key={i} className="flex items-center justify-between p-4 bg-gray-50/50 rounded-xl hover:bg-white hover:shadow-md transition-all border border-transparent hover:border-gray-100">
                           <div className="flex items-center gap-4">
                              <div className={`w-2 h-10 rounded-full ${log.color}`}></div>
                              <div>
                                 <p className="text-sm font-black text-gray-900">{log.event}</p>
                                 <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{log.user}</p>
                              </div>
                           </div>
                           <span className="text-xs font-bold text-gray-400 italic">{log.time}</span>
                        </div>
                     ))}
                  </div>
               </div>
            )}
            
            {activeTab === 'pos' && (
               <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl p-10">
                  <div className="flex items-center justify-between mb-8">
                     <div>
                        <h2 className="text-2xl font-black text-gray-900">Point of Sale</h2>
                        <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">Direct offline order creation</p>
                     </div>
                     <div className="flex gap-4">
                        <div className="relative">
                           <Search className="w-4 h-4 text-gray-400 absolute left-4 top-1/2 -translate-y-1/2" />
                           <input type="text" placeholder="Search products..." className="pl-10 pr-4 py-3 bg-gray-50 border border-gray-100 rounded-xl text-sm" />
                        </div>
                     </div>
                  </div>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                     <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-6">
                        {products.slice(0, 9).map((product, i) => (
                           <div key={i} className="bg-gray-50 rounded-2xl p-4 border border-gray-100 hover:shadow-lg transition-all cursor-pointer group">
                              <img src={product.image} className="w-full h-32 object-cover rounded-xl mb-4 group-hover:scale-105 transition-transform" />
                              <p className="text-xs font-black text-gray-900 truncate">{product.name}</p>
                              <p className="text-sm font-black text-primary-700 mt-1">৳{product.price}</p>
                              <button className="w-full mt-4 py-2 bg-primary-950 text-white text-[10px] font-black uppercase tracking-widest rounded-lg">Add to Cart</button>
                           </div>
                        ))}
                     </div>
                     <div className="bg-[#0f172a] rounded-[2rem] p-8 text-white flex flex-col justify-between">
                        <div>
                           <h3 className="font-black text-lg mb-6 flex items-center gap-2">
                              <ShoppingCart className="w-5 h-5 text-accent" /> Checkout Cart
                           </h3>
                           <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 scrollbar-hide">
                              <p className="text-white/40 text-xs text-center italic py-10">Cart is empty</p>
                           </div>
                        </div>
                        <div className="mt-8 pt-8 border-t border-white/10">
                           <div className="flex justify-between mb-4">
                              <span className="text-xs text-white/40 uppercase font-black tracking-widest">Total Payable</span>
                              <span className="text-2xl font-black text-accent">৳0</span>
                           </div>
                           <button className="w-full py-4 bg-accent text-primary-950 font-black rounded-2xl shadow-xl shadow-accent/20 active:scale-95 transition-all">
                              Place Order Now (৳0)
                           </button>
                        </div>
                     </div>
                  </div>
               </div>
            )}

            {activeTab === 'sales-report' && (
               <div className="bg-white rounded-3xl border border-gray-100 shadow-xl p-10">
                  <div className="flex items-center justify-between mb-10">
                     <h2 className="text-2xl font-black text-gray-900 italic tracking-tight">Sales Analytics Report</h2>
                     <div className="flex gap-4">
                        <select className="px-6 py-2 bg-gray-50 border border-gray-100 rounded-xl text-xs font-black uppercase">
                           <option>Last 30 Days</option>
                           <option>This Year</option>
                        </select>
                     </div>
                  </div>
                  <div className="h-96 w-full">
                     <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={[
                           {name: 'Jan', sales: 4000}, {name: 'Feb', sales: 3000}, {name: 'Mar', sales: 5000},
                           {name: 'Apr', sales: 8000}, {name: 'May', sales: 6000}, {name: 'June', sales: 9000}
                        ]}>
                           <defs>
                              <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                                 <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                                 <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                              </linearGradient>
                           </defs>
                           <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 900}} />
                           <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fontWeight: 900}} />
                           <Tooltip contentStyle={{borderRadius: '20px', border: 'none', boxShadow: '0 10px 30px rgba(0,0,0,0.1)'}} />
                           <Area type="monotone" dataKey="sales" stroke="#3b82f6" strokeWidth={4} fillOpacity={1} fill="url(#colorSales)" />
                        </AreaChart>
                     </ResponsiveContainer>
                  </div>
               </div>
            )}

            {activeTab === 'low-stock' && (
               <div className="bg-white rounded-3xl border border-gray-100 shadow-xl p-10">
                  <h2 className="text-2xl font-black text-gray-900 mb-8">Low Stock Inventory</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                     {lowStockProducts.map((p, i) => (
                        <div key={i} className="p-6 bg-red-50/50 rounded-2xl border border-red-100 flex flex-col justify-between">
                           <div className="flex items-center gap-4 mb-4">
                              <img src={p.image} className="w-16 h-16 rounded-xl object-cover" />
                              <div>
                                 <p className="text-sm font-black text-gray-900">{p.name}</p>
                                 <p className="text-xs text-red-600 font-bold">Only {p.stock} remaining</p>
                              </div>
                           </div>
                           <button 
                             onClick={() => {
                                 const stock = window.prompt(`Enter amount to add to current stock (${p.stock}) for ${p.name}`);
                                 if (stock && !isNaN(parseInt(stock))) {
                                    const newStock = (p.stock || 0) + parseInt(stock);
                                    updateProduct(p.id, { stock: newStock }).then(() => {
                                        showToast(`Restocked ${p.name} successfully`, 'success');
                                    });
                                 }
                             }}
                             className="w-full py-3 bg-white text-[#0f172a] border border-gray-100 rounded-xl font-bold text-xs hover:bg-gray-50 transition-all">
                              Restock Product
                           </button>
                        </div>
                     ))}
                  </div>
               </div>
            )}

            {activeTab === 'media-library' && (
               <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-xl p-10">
                  <div className="flex items-center justify-between mb-10">
                     <div>
                        <h2 className="text-2xl font-black text-gray-900 tracking-tight">Media Library</h2>
                        <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">Manage global assets and uploads</p>
                     </div>
                     <div className="flex gap-4">
                        <button className="px-6 py-3 bg-gray-100 text-gray-600 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-gray-200 transition-all flex items-center gap-2">
                           <List className="w-4 h-4" /> Filter
                        </button>
                        <button className="px-8 py-3 bg-primary-950 text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl hover:bg-black transition-all active:scale-95 flex items-center gap-2">
                           <Image className="w-4 h-4" /> Upload New
                        </button>
                     </div>
                  </div>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
                     {[...siteImages, ...products.map(p => ({url: p.image, title: p.name}))].slice(0, 18).map((img, i) => (
                        <div key={i} className="group relative aspect-square rounded-[1.5rem] overflow-hidden border border-gray-100 bg-gray-50 shadow-sm hover:shadow-xl transition-all cursor-pointer">
                           <img src={img.url || ''} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={img.title} />
                           <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                              <p className="text-[8px] text-white font-black truncate">{img.title}</p>
                              <div className="flex gap-2 mt-2">
                                 <button className="p-1.5 bg-white/20 hover:bg-white rounded-lg text-white hover:text-red-500 transition-all"><Trash2 className="w-3 h-3" /></button>
                                 <button className="p-1.5 bg-white/20 hover:bg-white rounded-lg text-white hover:text-primary-700 transition-all"><Search className="w-3 h-3" /></button>
                              </div>
                           </div>
                        </div>
                     ))}
                  </div>
               </div>
            )}

            {activeTab === 'endpoint_test' && (
              <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] p-8">
                <h2 className="text-xl font-black text-gray-900 mb-2">Endpoint Connectivity Test</h2>
                <p className="text-sm text-gray-500 mb-8 font-bold uppercase tracking-widest">Verify system API and external service bridge integrity</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                   <div className="space-y-6">
                      <div className="p-6 bg-gray-50 rounded-2xl border border-gray-100">
                         <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                            <Terminal className="w-5 h-5 text-primary-700" /> API Console
                         </h3>
                         <div className="flex gap-4">
                            <input type="text" placeholder="https://api.kholosshop.com/v1/..." className="flex-1 px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm" />
                            <button className="px-6 py-2 bg-primary-700 text-white rounded-xl font-bold text-xs">Run Test</button>
                         </div>
                      </div>
                      
                      <div className="space-y-4">
                         {[
                           { name: 'Inventory Sync', status: 'online', latency: '42ms' },
                           { name: 'Payment Bridge', status: 'online', latency: '128ms' },
                           { name: 'Sms Gateway', status: 'offline', latency: '---' },
                           { name: 'Email Dispatch', status: 'online', latency: '89ms' }
                         ].map((endpoint, i) => (
                           <div key={i} className="flex items-center justify-between p-4 bg-white border border-gray-100 rounded-xl hover:shadow-md transition-shadow">
                              <div className="flex items-center gap-3">
                                 <div className={`w-2 h-2 rounded-full ${endpoint.status === 'online' ? 'bg-green-500' : 'bg-red-500'} animate-pulse`}></div>
                                 <span className="text-sm font-black text-gray-700">{endpoint.name}</span>
                              </div>
                              <span className="text-xs font-bold text-gray-400 font-mono tracking-tighter">{endpoint.latency}</span>
                           </div>
                         ))}
                      </div>
                   </div>
                   
                   <div className="bg-[#0f172a] rounded-2xl p-6 text-emerald-400 font-mono text-[10px] overflow-hidden">
                      <div className="flex items-center gap-2 mb-4 text-gray-500 border-b border-white/5 pb-2">
                         <div className="w-2 h-2 rounded-full bg-red-500/30"></div>
                         <div className="w-2 h-2 rounded-full bg-amber-500/30"></div>
                         <div className="w-2 h-2 rounded-full bg-emerald-500/30"></div>
                         <span className="ml-2 uppercase tracking-widest font-black text-[8px]">Debugger Terminal</span>
                      </div>
                      <div className="space-y-1">
                         <p className="text-gray-500">[2026-05-11 12:44:02] INITIALIZING ENDPOINT SCAN...</p>
                         <p className="text-emerald-400/80">Connecting to Firebase Cluster [asia-southeast1]... OK</p>
                         <p className="text-emerald-400/80">Checking Auth Service persistence... OK</p>
                         <p className="text-amber-400/80">Warning: SSL Certificate for SMS-GW expiring in 14 days.</p>
                         <p className="text-emerald-400/80">Querying Cloud Functions Health... OK</p>
                         <p className="text-white mt-4 tracking-widest animate-pulse">_ EXECUTION_ID: 98AB-44E2-FF01</p>
                      </div>
                   </div>
                </div>
              </div>
            )}

            {activeTab === 'system_metrics' && (
               <div className="bg-white rounded-2xl border border-gray-100 shadow-[0_4px_20px_-4px_rgba(0,0,0,0.05)] p-8">
                  <h2 className="text-xl font-black text-gray-900 mb-8">Live System Resource Monitor</h2>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                     <div className="bg-gray-50 p-8 rounded-[2rem] border border-gray-100">
                        <div className="flex items-center justify-between mb-6">
                           <span className="text-[10px] font-black text-primary-700 uppercase tracking-widest">CPU Utilization</span>
                           <Activity className="w-4 h-4 text-primary-700" />
                        </div>
                        <div className="text-4xl font-black text-gray-900 mb-4">14.2<span className="text-lg opacity-40">%</span></div>
                        <div className="w-full h-1.5 bg-gray-200 rounded-full overflow-hidden">
                           <div className="w-[14.2%] h-full bg-primary-700"></div>
                        </div>
                     </div>
                     <div className="bg-gray-50 p-8 rounded-[2rem] border border-gray-100">
                        <div className="flex items-center justify-between mb-6">
                           <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Memory Heap</span>
                           <Layers className="w-4 h-4 text-emerald-600" />
                        </div>
                        <div className="text-4xl font-black text-gray-900 mb-4">512<span className="text-lg opacity-40">MB</span></div>
                        <div className="w-full h-1.5 bg-gray-200 rounded-full overflow-hidden">
                           <div className="w-[45%] h-full bg-emerald-600"></div>
                        </div>
                     </div>
                     <div className="bg-gray-50 p-8 rounded-[2rem] border border-gray-100">
                        <div className="flex items-center justify-between mb-6">
                           <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Server Uptime</span>
                           <Clock className="w-4 h-4 text-blue-600" />
                        </div>
                        <div className="text-4xl font-black text-gray-900 mb-4">182<span className="text-lg opacity-40">DAYS</span></div>
                        <p className="text-[9px] text-gray-400 font-bold uppercase tracking-widest mt-2">Continuous Production Uptime</p>
                     </div>
                  </div>
                  
                  <div className="mt-10 p-10 bg-[#0f172a] rounded-[3rem] overflow-hidden relative">
                     <div className="absolute top-0 right-0 w-96 h-96 bg-primary-500/10 rounded-full blur-3xl -mr-48 -mt-48"></div>
                     <h3 className="text-white font-black text-lg mb-8 tracking-tight">Database Read/Write Throughput</h3>
                     <div className="h-64">
                         <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={[
                               {t: 1, r: 120, w: 40}, {t: 2, r: 340, w: 90}, {t: 3, r: 210, w: 60},
                               {t: 4, r: 890, w: 120}, {t: 5, r: 450, w: 80}, {t: 6, r: 670, w: 100}, {t: 7, r: 1100, w: 230}
                            ]}>
                               <Area type="monotone" dataKey="r" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.1} />
                               <Area type="monotone" dataKey="w" stroke="#10b981" fill="#10b981" fillOpacity={0.1} />
                            </AreaChart>
                         </ResponsiveContainer>
                     </div>
                     <div className="flex justify-center gap-10 mt-6">
                        <div className="flex items-center gap-3">
                           <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                           <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Read Requests</span>
                        </div>
                        <div className="flex items-center gap-3">
                           <div className="w-3 h-3 rounded-full bg-emerald-500"></div>
                           <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Write Operations</span>
                        </div>
                     </div>
                  </div>
               </div>
            )}

            {/* End of custom views */}
          </div>
        </div>
      </div>

      {/* Modal */}
      {modalConfig?.isOpen && (
        <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm">
           <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
              <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                 <h3 className="text-xl font-black text-gray-900">{modalConfig.title}</h3>
                 <button onClick={() => setModalConfig(null)} className="text-gray-400 hover:text-gray-600 bg-gray-100/50 hover:bg-gray-200/50 p-2 rounded-full transition-all">
                   <X className="w-5 h-5" />
                 </button>
              </div>
              <form onSubmit={(e) => {
                 e.preventDefault();
                 const formData = new FormData(e.currentTarget);
                 const data = Object.fromEntries(formData.entries());
                 modalConfig.onSubmit(data);
                 setModalConfig(null);
              }} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
                 {modalConfig.fields.map(f => (
                    <div key={f.name}>
                       <label className="block text-sm font-bold text-gray-700 mb-1.5">{f.label}</label>
                       {f.type === 'select' ? (
                         <select
                           name={f.name}
                           defaultValue={f.defaultValue}
                           required={f.required !== false}
                           className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all shadow-sm bg-gray-50/50 focus:bg-white text-gray-800"
                         >
                           {f.options?.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
                         </select>
                       ) : (
                         <input 
                           name={f.name} 
                           type={f.type || 'text'} 
                           defaultValue={f.defaultValue} 
                           required={f.required !== false}
                           step="any"
                           min="0"
                           className="w-full px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all shadow-sm bg-gray-50/50 focus:bg-white text-gray-800" 
                         />
                       )}
                    </div>
                 ))}
                 <div className="pt-4 flex justify-end gap-3 sticky bottom-0 bg-white">
                    <button type="button" onClick={() => setModalConfig(null)} className="px-5 py-2.5 text-gray-600 font-bold hover:bg-gray-100 rounded-xl transition-all">Cancel</button>
                    <button type="submit" className="px-6 py-2.5 bg-primary-700 text-white font-bold rounded-xl shadow-md hover:bg-primary-800 transition-all active:scale-[0.98]">Save</button>
                 </div>
              </form>
           </div>
        </div>
      )}

      {/* Order Details Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center p-4 backdrop-blur-sm">
           <div className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
              <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50/50">
                 <h3 className="text-xl font-black text-gray-900">Order Details</h3>
                 <div className="flex items-center gap-4">
                   <select 
                      value={selectedOrder.status} 
                      onChange={(e) => {
                        updateOrderStatus(selectedOrder.id, e.target.value);
                        setSelectedOrder({...selectedOrder, status: e.target.value});
                      }}
                      className="px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest bg-white border border-gray-200 outline-none shadow-sm cursor-pointer"
                   >
                     <option value="pending">Pending</option>
                     <option value="shipped">Shipped</option>
                     <option value="delivered">Delivered</option>
                     <option value="cancelled">Cancelled</option>
                   </select>
                   <button onClick={() => setSelectedOrder(null)} className="text-gray-400 hover:text-gray-600 bg-gray-100/50 hover:bg-gray-200/50 p-2 rounded-full transition-all">
                     <X className="w-5 h-5" />
                   </button>
                 </div>
              </div>
              
              <div className="flex-1 overflow-y-auto bg-gray-50/30 p-2 sm:p-6 relative">
                 <Receipt order={selectedOrder} hideActions />
              </div>
           </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <AnimatePresence>
        {deleteConfirmOrder && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-gray-900/60 backdrop-blur-sm">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-[2rem] p-8 max-w-sm w-full shadow-2xl relative"
            >
              <h3 className="text-xl font-black text-gray-900 mb-2 mt-2">Delete Order?</h3>
              <p className="text-gray-500 font-medium mb-8 text-sm leading-relaxed">
                Are you completely sure you want to delete order <strong className="text-gray-900">#{deleteConfirmOrder.shortId || deleteConfirmOrder.id?.slice(-8).toUpperCase()}</strong>? This action is permanent and cannot be undone.
              </p>
              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setDeleteConfirmOrder(null)}
                  className="flex-1 px-4 py-3 bg-gray-105 text-gray-600 font-bold rounded-xl bg-gray-100 hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    try {
                      await deleteOrder(deleteConfirmOrder.id);
                      showToast('Order deleted permanently');
                    } catch (e: any) {
                      showToast('Failed to delete order', 'error');
                    }
                    setDeleteConfirmOrder(null);
                  }}
                  className="flex-1 px-4 py-3 bg-red-600 text-white font-bold rounded-xl hover:bg-red-700 transition-colors shadow-lg shadow-red-600/20"
                >
                  Yes, Delete
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Toast */}
      {toast && (
        <div className={`fixed bottom-4 right-4 px-6 py-3 rounded-xl text-white font-bold shadow-2xl z-[100] animate-in slide-in-from-bottom flex items-center gap-2 ${toast.type === 'error' ? 'bg-red-600' : 'bg-primary-800'}`}>
          {toast.type === 'error' ? <XCircle className="w-5 h-5" /> : <CheckCircle className="w-5 h-5" />}
          {toast.message}
        </div>
      )}
    </div>
  );
}
