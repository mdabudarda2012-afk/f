import { useState, useEffect } from 'react';
import { Package, Search, CheckCircle, Clock, Truck, XCircle, Hash, RotateCcw } from 'lucide-react';
import { db, auth } from '../lib/firebase';
import { collection, query, where, getDocs, doc, getDoc, onSnapshot } from 'firebase/firestore';
import { addReturnRequest } from '../lib/api';
import Layout from '../layouts/Layout';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';

export default function OrderTracking() {
  const [orderId, setOrderId] = useState('');
  const [order, setOrder] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [returnRequested, setReturnRequested] = useState(false);

  const [targetOrderId, setTargetOrderId] = useState<string | null>(null);

  useEffect(() => {
    if (!targetOrderId) return;
    const unsub = onSnapshot(doc(db, 'orders', targetOrderId), (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setOrder({ id: snap.id, ...data });
        // If the order itself was already returned or we have a flag, keep returnRequested true if needed
        // but for now we just reset on new tracking.
      } else {
        setError('অর্ডার পাওয়া যায়নি।');
      }
    }, (err) => {
      console.error(err);
      setError('ট্র্যাকিং তথ্য পেতে সমস্যা হচ্ছে।');
    });
    return () => unsub();
  }, [targetOrderId]);

  const trackOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    const rawInput = orderId.trim();
    
    if (!rawInput) {
      setError('দয়া করে অর্ডার আইডি প্রদান করুন');
      return;
    }

    setLoading(true);
    setError('');
    setOrder(null);
    setTargetOrderId(null);
    setReturnRequested(false);

    try {
      const bengaliToEnglish = (str: string) => {
        const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
        return str.replace(/[০-৯]/g, (d) => bengaliDigits.indexOf(d).toString());
      };

      const convertedInput = bengaliToEnglish(rawInput);
      let cleanedInput = convertedInput.replace(/^#/, '').toUpperCase();
      cleanedInput = cleanedInput.replace(/^ORD-/, '').trim();
      const onlyNumbers = convertedInput.replace(/\D/g, '');

      let foundOrderId = null;

      try {
        const shortIdQuery = await getDocs(query(collection(db, 'orders'), where('shortId', '==', cleanedInput)));
        if (!shortIdQuery.empty) {
          foundOrderId = shortIdQuery.docs[0].id;
        }
      } catch (err) {}

      if (!foundOrderId && onlyNumbers.length >= 10) {
        try {
          const possiblePhones = Array.from(new Set([
             onlyNumbers,
             `+${onlyNumbers}`,
             onlyNumbers.startsWith('01') ? `88${onlyNumbers}` : onlyNumbers,
             onlyNumbers.startsWith('01') ? `+88${onlyNumbers}` : onlyNumbers,
             onlyNumbers.startsWith('880') ? onlyNumbers.substring(2) : onlyNumbers,
             onlyNumbers.startsWith('880') ? `+${onlyNumbers}` : onlyNumbers
          ])).filter(p => p.length > 0);

          const phoneSnap = await getDocs(query(collection(db, 'orders'), where('customerPhone', 'in', possiblePhones.slice(0, 10))));
          if (!phoneSnap.empty) {
            const sortedDocs = phoneSnap.docs.sort((a, b) => b.data().createdAt - a.data().createdAt);
            foundOrderId = sortedDocs[0].id;
          }
        } catch (err) {}
      }

      if (!foundOrderId && rawInput.length > 15) {
        try {
          const docRef = doc(db, 'orders', rawInput);
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            foundOrderId = docSnap.id;
          }
        } catch (e) {}
      }

      if (foundOrderId) {
        setTargetOrderId(foundOrderId);
      } else {
        setError('দুঃখিত, এই আইডি দিয়ে কোনো অর্ডার তথ্য পাওয়া যায়নি। দয়া করে সঠিক আইডি লিখুন।');
      }
    } catch (err) {
      console.error('Tracking Error:', err);
      setError('সার্ভারে সমস্যা হচ্ছে। দয়া করে কিছুক্ষণ পর আবার চেষ্টা করুন।');
    } finally {
      setLoading(false);
    }
  };

  const statusMap: Record<string, { label: string, icon: any, color: string, step: number, desc: string }> = {
    'pending': { label: 'অর্ডার গ্রহণ করা হয়েছে', icon: Clock, color: 'text-amber-500', step: 1, desc: 'আপনার অর্ডারটি আমাদের কাছে পৌঁছেছে এবং প্রক্রিয়াধীন আছে।' },
    'processing': { label: 'প্রসেসিং হচ্ছে', icon: Package, color: 'text-blue-500', step: 2, desc: 'আপনার পণ্যগুলো গুদাম থেকে বাছাই করা হচ্ছে।' },
    'shipped': { label: 'ডেলিভারির জন্য পাঠানো হয়েছে', icon: Truck, color: 'text-purple-500', step: 3, desc: 'আপনার পার্সেলটি কুরিয়ার সার্ভিসকে হস্তান্তর করা হয়েছে।' },
    'delivered': { label: 'ডেলিভারি সম্পন্ন হয়েছে', icon: CheckCircle, color: 'text-green-500', step: 4, desc: 'অভিনন্দন! আপনি আপনার পণ্যটি বুঝে পেয়েছেন।' },
    'returned': { label: 'পণ্যটি ফেরত নেওয়া হয়েছে', icon: RotateCcw, color: 'text-gray-500', step: 0, desc: 'আপনার রিটার্ন আবেদন অনুযায়ী পণ্যটি ফেরত নেওয়া হয়েছে।' },
    'cancelled': { label: 'অর্ডার বাতিল করা হয়েছে', icon: XCircle, color: 'text-red-500', step: 0, desc: 'দুঃখিত, এই অর্ডারটি বাতিল করা হয়েছে।' }
  };

  return (
    <Layout>
      <div className="bg-[#fdfdfd] min-h-screen py-6 md:py-16">
        <div className="max-w-[1440px] mx-auto px-4">
          
          <div className="max-w-4xl mx-auto">
            {/* Header */}
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-8"
            >
              <div className="inline-flex items-center gap-2 px-6 py-2 bg-primary-50 text-primary-700 rounded-full text-[10px] font-black uppercase tracking-[0.2em] mb-4 border border-primary-100 shadow-sm">
                <Truck className="w-4 h-4" /> Logistics Tracking
              </div>
              <h1 className="text-3xl md:text-5xl lg:text-7xl font-black text-gray-900 mb-4 tracking-tighter">অর্ডার ট্র্যাক করুন</h1>
              <p className="text-gray-400 text-sm md:text-lg max-w-2xl mx-auto font-bold uppercase tracking-wide opacity-80 mb-2">আপনার পার্সেলের বর্তমান অবস্থান জানতে আইডি অথবা ফোন নম্বর লিখুন</p>
              <p className="text-[10px] text-primary-600 font-black uppercase tracking-widest">(অর্ডার কনফার্ম করার সময় যে তথ্য পেয়েছেন তা ব্যবহার করুন)</p>
            </motion.div>

            {/* Tracking Form */}
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-[2.5rem] shadow-[0_30px_70px_-15px_rgba(0,0,0,0.08)] border border-gray-100 p-8 md:p-14 mb-12 relative overflow-hidden"
            >
              <div className="absolute -top-10 -right-10 opacity-5 rotate-12">
                 <Package className="w-64 h-64" />
              </div>
              
              <form onSubmit={trackOrder} className="relative z-10">
                <div className="space-y-6 mb-10">
                  <div className="space-y-3">
                    <label className="text-[11px] font-black text-primary-600 uppercase tracking-[0.4em] ml-2 flex items-center gap-2">
                       <Hash className="w-4 h-4" /> Order Tracking Search
                    </label>
                    <div className="relative group">
                      <Search className="absolute left-7 top-1/2 -translate-y-1/2 w-7 h-7 text-gray-300 group-focus-within:text-primary-600 transition-all duration-500" />
                      <input 
                        type="text" 
                        value={orderId}
                        onChange={(e) => setOrderId(e.target.value)}
                        placeholder="অর্ডার আইডি অথবা ফোন নম্বর দিন"
                        className="w-full pl-18 pr-8 py-7 bg-gray-50/50 border-2 border-gray-100 rounded-[2.5rem] focus:bg-white focus:border-primary-500 focus:shadow-[0_0_0_8px_rgba(0,175,102,0.05)] outline-none transition-all font-black text-2xl text-gray-950 placeholder:text-gray-300 shadow-inner group-hover:border-gray-200"
                      />
                    </div>
                  </div>
                </div>
                
                {error && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="mb-6 p-4 bg-red-50 border border-red-100 text-red-600 rounded-2xl text-sm font-bold flex items-center gap-3">
                    <XCircle className="w-5 h-5" /> {error}
                  </motion.div>
                )}
                
                <button 
                  type="submit" 
                  disabled={loading}
                  className="w-full bg-primary-900 text-white font-black text-lg py-5 rounded-2xl shadow-[0_15px_35px_-5px_rgba(0,0,0,0.2)] hover:shadow-[0_20px_45px_-5px_rgba(0,0,0,0.3)] hover:-translate-y-1 active:scale-[0.98] transition-all flex items-center justify-center gap-3 disabled:opacity-70"
                >
                  {loading ? (
                    <div className="w-6 h-6 border-4 border-white/20 border-t-white rounded-full animate-spin"></div>
                  ) : (
                    <>খুঁজুন <Search className="w-5 h-5" /></>
                  )}
                </button>
              </form>
            </motion.div>

            {/* Results */}
            <AnimatePresence mode="wait">
              {order && (
                <motion.div 
                  key="order-result"
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 20 }}
                  className="space-y-8"
                >
                  {/* Status Card */}
                  <div className="bg-white rounded-[2.5rem] shadow-xl border border-gray-100 overflow-hidden">
                    <div className="p-8 border-b border-gray-50 bg-gray-50/50 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                       <div className="flex items-center gap-4">
                         <div className="w-14 h-14 bg-primary-900 text-white rounded-2xl flex items-center justify-center font-black text-xl shadow-lg">
                           #
                         </div>
                         <div>
                            <h3 className="text-xl font-black text-gray-900">Order {order.shortId || order.id.slice(-8).toUpperCase()}</h3>
                            <p className="text-gray-500 font-bold text-xs uppercase tracking-widest mt-1">
                               Date: {new Date(order.createdAt).toLocaleDateString(undefined, { dateStyle: 'long' })}
                            </p>
                         </div>
                       </div>
                       <div className={`px-6 py-2.5 rounded-full text-xs font-black uppercase tracking-widest shadow-sm ${
                         order.status === 'delivered' ? 'bg-green-100 text-green-700' :
                         order.status === 'cancelled' ? 'bg-red-100 text-red-700' :
                         order.status === 'returned' ? 'bg-gray-100 text-gray-700' :
                         order.status === 'shipped' ? 'bg-purple-100 text-purple-700' :
                         'bg-blue-100 text-blue-700'
                       }`}>
                         {statusMap[order.status || 'pending']?.label}
                       </div>
                    </div>

                    <div className="p-8 md:p-12">
                      {order.status !== 'cancelled' ? (
                        <div className="relative">
                          {/* Animated Desktop Progress Bar */}
                          <div className="hidden md:block absolute top-[28px] left-[10%] right-[10%] h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <motion.div 
                               initial={{ width: 0 }}
                               animate={{ width: `${((statusMap[order.status || 'pending']?.step || 1) - 1) * 33.33}%` }}
                               transition={{ duration: 1, ease: "easeOut" }}
                               className="h-full bg-primary-600 shadow-[0_0_10px_rgba(37,99,235,0.5)]"
                            />
                          </div>

                          <div className="flex flex-col md:flex-row justify-between relative z-10 gap-10 md:gap-4">
                            {['pending', 'processing', 'shipped', 'delivered'].map((statusKey, index) => {
                              const statusInfo = statusMap[statusKey];
                              const currentStep = statusMap[order.status || 'pending']?.step || 1;
                              const isCompleted = currentStep > index + 1;
                              const isCurrent = currentStep === index + 1;
                              
                              return (
                                <div key={statusKey} className="flex md:flex-col items-center gap-6 md:gap-4 md:flex-1">
                                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center border-4 border-white shadow-xl transition-all duration-700 shrink-0 ${
                                    isCompleted ? 'bg-green-500 text-white rotate-0' : 
                                    isCurrent ? 'bg-primary-600 text-white scale-110' : 
                                    'bg-white text-gray-300'
                                  }`}>
                                    {isCompleted ? <CheckCircle className="w-6 h-6" /> : <statusInfo.icon className="w-6 h-6" />}
                                  </div>
                                  <div className="md:text-center">
                                    <h4 className={`font-black text-sm uppercase tracking-tight mb-1 ${isCurrent || isCompleted ? 'text-gray-900' : 'text-gray-300'}`}>
                                      {statusInfo.label}
                                    </h4>
                                    <p className={`text-[10px] font-bold uppercase tracking-widest ${isCurrent ? 'text-primary-600' : isCompleted ? 'text-green-500' : 'text-gray-300'}`}>
                                      {isCompleted ? 'Completed' : isCurrent ? 'Ongoing' : 'Pending'}
                                    </p>
                                    {isCurrent && (
                                       <motion.p 
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className="text-[11px] text-gray-500 mt-2 font-medium max-w-[150px] mx-auto leading-relaxed hidden md:block"
                                       >
                                         {statusInfo.desc}
                                       </motion.p>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-10">
                           <div className="w-20 h-20 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto mb-6">
                             <XCircle className="w-10 h-10" />
                           </div>
                           <h3 className="text-2xl font-black text-gray-900">Order Cancelled</h3>
                           <p className="text-gray-500 mt-2 font-medium">This order was cancelled by the admin. Please contact our support team for more details.</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Summary Card */}
                  <div className="bg-white rounded-[2.5rem] shadow-xl border border-gray-100 overflow-hidden">
                    <div className="p-8 border-b border-gray-50">
                       <h4 className="font-black text-lg text-gray-900 flex items-center gap-2">
                        <Package className="w-5 h-5 text-primary-600" /> আইটেম সামারি
                       </h4>
                    </div>
                    <div className="p-8 md:p-10 space-y-6">
                      {order.items?.map((item: any, idx: number) => (
                        <div key={idx} className="flex items-center gap-6 p-4 hover:bg-gray-50 rounded-2xl transition-colors">
                          <div className="w-20 h-20 bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-inner shrink-0 scale-hover">
                            <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                          </div>
                          <div className="flex-1">
                            <h5 className="font-black text-gray-900 leading-tight mb-1">{item.name}</h5>
                            <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">Quantity: {item.quantity}</p>
                          </div>
                          <div className="text-right">
                             <p className="text-lg font-black text-gray-900 font-mono">৳{item.price * item.quantity}</p>
                             <p className="text-[10px] font-bold text-gray-400 uppercase">৳{item.price} each</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="bg-primary-900 p-8 md:p-10 text-white flex flex-col md:flex-row md:items-center justify-between gap-6">
                       <div>
                          <p className="text-primary-300 font-bold text-sm uppercase tracking-widest mb-1">Total Payable</p>
                          <h3 className="text-4xl font-black">৳{(order.totalAmount || order.total).toLocaleString()}</h3>
                       </div>
                       <div className="flex items-center gap-4">
                         {order.status === 'delivered' && !returnRequested && (
                           <button 
                             onClick={async () => {
                               const reason = prompt('পণ্যটি ফেরৎ দেওয়ার কারণ লিখুন:');
                               if (reason) {
                                 try {
                                   await addReturnRequest({
                                     orderId: order.shortId || order.id,
                                     customerId: auth.currentUser?.uid || '',
                                     items: order.items || [],
                                     reason,
                                     phone: order.customerPhone || '',
                                     customerName: auth.currentUser?.displayName || auth.currentUser?.email || order.customerName || 'Customer'
                                   });
                                   setReturnRequested(true);
                                   alert('আপনার রিটার্ন আবেদন জমা হয়েছে।');
                                 } catch (e: any) {
                                   console.error("Return error:", e);
                                   alert('আবেদন করতে সমস্যা হয়েছে: ' + (e.message || 'Unknown error'));
                                 }
                               }
                             }}
                             className="bg-red-50 text-red-600 px-6 py-4 rounded-xl font-black uppercase text-[10px] tracking-widest hover:bg-red-600 hover:text-white transition-all shadow-lg active:scale-95 flex items-center gap-2"
                           >
                              <RotateCcw className="w-4 h-4" /> Return Request
                           </button>
                         )}
                         {returnRequested && (
                           <div className="bg-amber-50 text-amber-600 px-6 py-4 rounded-xl font-black uppercase text-[10px] tracking-widest border border-amber-200">
                             রিটার্ন আবেদন প্রক্রিয়াধীন
                           </div>
                         )}
                         <Link to="/" className="bg-accent text-primary-950 px-8 py-4 rounded-xl font-black text-center shadow-lg hover:bg-white transition-all active:scale-95">
                           Continue Shopping
                         </Link>
                       </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            
            {!order && !loading && (
               <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center mt-20"
               >
                 <div className="inline-block p-6 bg-white rounded-full shadow-sm border border-gray-100 mb-6">
                    <Truck className="w-12 h-12 text-gray-200" />
                 </div>
                 <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">অর্ডার ইনফরমেশন পেতে সঠিক আইডি দিন</p>
               </motion.div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
