import React, { useState, useEffect } from 'react';
import { subscribeToCollection } from '../lib/api';
import { Link } from 'react-router-dom';
import Layout from '../layouts/Layout';

export default function Blogs() {
  const [blogs, setBlogs] = useState<any[]>([]);

  useEffect(() => {
    const unsub = subscribeToCollection('blogs', setBlogs);
    return unsub;
  }, []);

  return (
    <Layout>
      <div className="bg-gray-50 min-h-screen py-16">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
             <h1 className="text-4xl md:text-5xl font-black text-primary-950 tracking-tighter uppercase italic mb-4">
               Our Latest Blogs
             </h1>
             <p className="text-gray-500 font-medium">
               Read our latest articles, news, and guides.
             </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
             {blogs.map((blog, idx) => (
                <Link to={`/pages/${blog.slug || blog.id}`} key={idx} className="group flex flex-col bg-white rounded-[2rem] overflow-hidden shadow-sm hover:shadow-xl transition-all border border-gray-100 h-full">
                   <div className="relative aspect-[16/9] overflow-hidden">
                      <img src={blog.imageUrl || blog.image || 'https://via.placeholder.com/800x400'} alt={blog.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                      <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-md px-3 py-1.5 rounded-lg text-[10px] font-black tracking-widest text-primary-900 uppercase">
                         {blog.createdAt ? new Date(blog.createdAt).toLocaleDateString() : 'Recent'}
                      </div>
                   </div>
                   <div className="p-8 flex flex-col flex-1">
                      <h3 className="text-2xl font-black text-primary-950 mb-4 group-hover:text-accent transition-colors line-clamp-2 leading-tight">{blog.title}</h3>
                      <p className="text-gray-500 font-medium line-clamp-3 mb-6 flex-1 text-sm">
                        {blog.excerpt || blog.content || blog.description}
                      </p>
                      <div className="flex items-center text-xs font-black text-primary-600 uppercase tracking-widest">
                         Read Article <span className="ml-2 group-hover:translate-x-2 transition-transform">&rarr;</span>
                      </div>
                   </div>
                </Link>
             ))}
          </div>

          {blogs.length === 0 && (
             <div className="text-center py-20 text-gray-500 font-medium">
               No blogs have been published yet. Check back later!
             </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
