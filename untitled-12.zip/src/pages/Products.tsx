import { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import Layout from '../layouts/Layout';
import { Filter, Search as SearchIcon, CheckCircle, TrendingUp } from 'lucide-react';
import { subscribeToProducts } from '../lib/api';
import Fuse from 'fuse.js';

export default function Products() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<any[]>([]);
  const selectedCategory = searchParams.get('category') || 'all';
  const selectedBrand = searchParams.get('brand') || 'all';
  const searchQuery = searchParams.get('q') || '';
  const isComboFilter = searchParams.get('isCombo') === 'true';
  const isHotDealFilter = searchParams.get('isHotDeal') === 'true';
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [sortBy, setSortBy] = useState('newest');
  const [visibleCount, setVisibleCount] = useState(12);

  useEffect(() => {
    const unsub = subscribeToProducts((data) => {
      setProducts(data);
    });
    return unsub;
  }, []);

  const categories = useMemo(() => ['all', ...Array.from(new Set(products.map(p => p.category)))], [products]);
  const brands = useMemo(() => ['all', ...Array.from(new Set(products.map(p => p.brand).filter(Boolean)))], [products]);

  useEffect(() => {
    setVisibleCount(12);
  }, [selectedCategory, selectedBrand, searchQuery, isComboFilter, isHotDealFilter, sortBy]);

  const filteredAndSortedProducts = useMemo(() => {
    let result = [...products];

    // Is Combo Filter
    if (isComboFilter) {
      result = result.filter(p => p.isCombo);
    }
    
    // Is Hot Deal Filter
    if (isHotDealFilter) {
      result = result.filter(p => p.isHotDeal || (p.originalPrice && p.originalPrice > p.price));
    }

    // Category Filter
    if (selectedCategory !== 'all') {
      result = result.filter(p => p.category === selectedCategory);
    }
    
    // Brand Filter
    if (selectedBrand !== 'all') {
      result = result.filter(p => p.brand === selectedBrand);
    }

    // Fuzzy Search
    if (searchQuery.trim()) {
      // Common Banglish mappings
      const banglishMap: Record<string, string[]> = {
        'modhu': ['মধু'],
        'khejur': ['খেজুর'],
        'khejur er gur': ['খেজুরের গুড়', 'খেজুরের গুড়'],
        'badam': ['বাদাম'],
        'ghi': ['ঘি', 'ঘী'],
        'ghee': ['ঘি', 'ঘী'],
        'tel': ['তেল'],
        'sorishar tel': ['সরিষার তেল', 'সরিষার'],
        'mosla': ['মসলা', 'মশলা'],
        'lobon': ['লবণ'],
        'cha': ['চা'],
        'chal': ['চাল'],
        'dal': ['ডাল'],
        'ata': ['আটা'],
        'moyda': ['ময়দা'],
        'chini': ['চিনি'],
        'mangsho': ['মাংস'],
        'mach': ['মাছ'],
        'dim': ['ডিম'],
        'murgi': ['মুরগি']
      };

      // Enhance products with translated search tags
      const searchData = result.map(p => {
        let tags = '';
        Object.entries(banglishMap).forEach(([banglish, banglaOptions]) => {
           if (banglaOptions.some(b => p.name?.includes(b) || p.category?.includes(b) || p.description?.includes(b))) {
             tags += ` ${banglish}`;
           }
        });
        return { ...p, _searchTags: tags };
      });

      const fuse = new Fuse(searchData, {
        keys: ['name', 'category', 'brand', 'description', '_searchTags'],
        threshold: 0.4,
        distance: 200,
      });
      result = fuse.search(searchQuery).map(r => r.item);
    }

    // Sorting
    if (sortBy === 'newest') {
      result.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    } else if (sortBy === 'price-low') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-high') {
      result.sort((a, b) => b.price - a.price);
    }

    return result;
  }, [products, selectedCategory, selectedBrand, searchQuery, isComboFilter, sortBy]);

  return (
    <Layout>
      <div className="bg-primary-950 py-12 border-b border-primary-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h1 className="text-3xl md:text-5xl font-black text-white uppercase italic tracking-tighter drop-shadow-xl animate-slide-up">
            {searchQuery ? `Search: "${searchQuery}"` : isHotDealFilter ? "ফ্ল্যাশ ডিলস" : isComboFilter ? "কম্বো প্যাক" : selectedCategory !== 'all' ? selectedCategory : "আমাদের সকল পণ্য"}
          </h1>
          {searchQuery && (
       <p className="text-gray-300 text-sm mt-4 font-medium max-w-lg mx-auto opacity-80">
         Found {filteredAndSortedProducts.length} items
       </p>
     )}
        </div>
      </div>
      
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6 relative z-20">
        <div className="flex flex-col md:flex-row gap-8">
          
          {/* Mobile Filter Button */}
          <div className="md:hidden flex flex-col gap-3 bg-white p-4 rounded-xl border border-gray-200 shadow-sm relative z-20">
             <div className="flex justify-between items-center">
               <button onClick={() => setShowMobileFilters(!showMobileFilters)} className="flex items-center gap-2 text-primary-900 font-bold px-4 py-2 bg-gray-50 rounded-lg border border-gray-100">
                  <Filter className="w-5 h-5" /> <span>ফিল্টার ও ক্যাটাগরি</span>
               </button>
               <span className="text-sm font-bold text-primary-700">{filteredAndSortedProducts.length} পণ্য</span>
             </div>
             {(searchQuery || isHotDealFilter || isComboFilter) && (
               <div className="flex flex-wrap items-center justify-between gap-2 bg-primary-50 px-3 py-2 rounded-lg border border-primary-100">
                  <span className="text-xs font-medium text-primary-800">
                     Active Filters: <span className="font-bold">{searchQuery || (isHotDealFilter ? 'Hot Deals' : isComboFilter ? 'Combo Packs' : '')}</span>
                  </span>
                  <button onClick={() => {
                    setSearchParams(prev => {
                      const next = new URLSearchParams(prev);
                      next.delete('q');
                      next.delete('isCombo');
                      next.delete('isHotDeal');
                      return next;
                    });
                  }} className="text-primary-600 font-bold text-xs uppercase tracking-wider">মুছে ফেলুন</button>
               </div>
             )}
          </div>

          {/* Filters Sidebar */}
          <div className={`${showMobileFilters ? 'block' : 'hidden'} md:block w-full md:w-72 flex-shrink-0 relative z-20`}>
            <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm md:sticky md:top-24 space-y-8">
              <div>
                <h2 className="text-lg font-black text-gray-900 mb-5 flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Filter className="w-4 h-4 text-primary-600" /> ক্যাটাগরি
                  </span>
                  {selectedCategory !== 'all' && (
                    <button 
                      onClick={() => setSearchParams(prev => { const n = new URLSearchParams(prev); n.delete('category'); return n; })}
                      className="text-[10px] uppercase tracking-widest text-primary-600 hover:text-primary-800 font-black"
                    >
                      Reset
                    </button>
                  )}
                </h2>
                <div className="grid grid-cols-1 gap-2">
                  {categories.map((category) => (
                    <button
                      key={category}
                      onClick={() => {
                         setSearchParams(prev => {
                           const next = new URLSearchParams(prev);
                           next.set('category', category);
                           return next;
                         });
                         setShowMobileFilters(false);
                      }}
                      className={`flex items-center justify-between px-4 py-3 rounded-lg text-sm font-bold transition-all border ${
                        selectedCategory === category
                          ? 'bg-[#f37920] text-white border-[#f37920] shadow-sm'
                          : 'text-gray-600 bg-white border-gray-100 hover:border-gray-200 hover:bg-white hover:text-[#f37920]'
                      }`}
                    >
                      <span className="truncate">{category === 'all' ? 'সব পণ্য সমূহ' : category}</span>
                      {selectedCategory === category && <CheckCircle className="w-4 h-4 text-white" />}
                    </button>
                  ))}
                </div>
              </div>

              {brands.length > 1 && (
                <div>
                  <h2 className="text-lg font-black text-gray-900 mb-5 flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-primary-600" /> জনপ্রিয় ব্র্যান্ড
                    </span>
                  </h2>
                  <div className="flex flex-wrap gap-2">
                    {brands.map((brand) => (
                      <button
                        key={brand}
                        onClick={() => {
                           setSearchParams(prev => {
                             const next = new URLSearchParams(prev);
                             next.set('brand', brand);
                             return next;
                           });
                           setShowMobileFilters(false);
                        }}
                        className={`px-4 py-2 rounded-full text-xs font-bold transition-all border ${
                          selectedBrand === brand
                            ? 'bg-[#f37920] text-white border-[#f37920] shadow-sm'
                            : 'text-gray-600 bg-white border-gray-200 hover:border-[#f37920] hover:text-[#f37920]'
                        }`}
                      >
                        {brand === 'all' ? 'সব ব্র্যান্ড' : brand}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="pt-8 border-t border-gray-100">
                 <h2 className="text-lg font-black text-gray-900 mb-5 flex items-center gap-2">
                   <SearchIcon className="w-4 h-4 text-primary-600" /> রিফাইন সার্চ
                 </h2>
                 <form onSubmit={(e) => {
                   e.preventDefault();
                   const form = e.currentTarget;
                   const q = (form.elements.namedItem('q') as HTMLInputElement).value;
                   setSearchParams(prev => {
                     const next = new URLSearchParams(prev);
                     if (q) next.set('q', q); else next.delete('q');
                     return next;
                   });
                 }} className="relative">
                    <input 
                      name="q"
                      type="text" 
                      defaultValue={searchQuery}
                      placeholder="পণ্য খুঁজুন..."
                      className="w-full pl-3 pr-10 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all"
                    />
                    <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-gray-400 hover:text-primary-600">
                      <SearchIcon className="w-4 h-4" />
                    </button>
                 </form>
              </div>
            </div>
          </div>

          {/* Product Grid */}
          <div className="flex-1">
            <div className="hidden md:flex mb-6 justify-between items-center bg-white p-4 px-6 rounded-xl border border-gray-200 shadow-sm relative z-20">
               <div className="flex items-center gap-4">
                  <p className="text-sm text-gray-600 font-medium">
                    Show <span className="font-black text-gray-900">{filteredAndSortedProducts.length}</span> products
                  </p>
                  {searchQuery && (
                    <span className="bg-primary-50 text-primary-700 px-3 py-1 rounded-full text-xs font-bold border border-primary-100">
                      Search: {searchQuery}
                    </span>
                  )}
               </div>
               <select 
                 value={sortBy}
                 onChange={(e) => setSortBy(e.target.value)}
                 className="text-sm border border-gray-200 rounded-lg bg-gray-50 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-primary-500/20 font-bold text-gray-700 cursor-pointer hover:bg-white transition-colors"
                >
                  <option value="newest">Newest & Best Sellers</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
               </select>
            </div>

            {filteredAndSortedProducts.length > 0 ? (
               <>
                 <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-6">
                   {filteredAndSortedProducts.slice(0, visibleCount).map((product) => (
                     <ProductCard key={product.id} product={product} />
                   ))}
                 </div>
                 {visibleCount < filteredAndSortedProducts.length && (
                   <div className="mt-12 text-center">
                     <button 
                       onClick={() => setVisibleCount(v => v + 12)}
                       className="inline-flex items-center gap-3 bg-white border-2 border-gray-100 px-8 py-3.5 rounded-2xl font-black text-[11px] uppercase tracking-widest text-primary-950 hover:border-primary-500 hover:text-primary-600 transition-all shadow-sm active:scale-95"
                     >
                        Load More Products
                     </button>
                   </div>
                 )}
               </>
            ) : (
               <div className="bg-white p-20 text-center rounded-2xl border border-gray-100 flex flex-col items-center justify-center">
                 <div className="w-20 h-20 bg-gray-50 flex items-center justify-center rounded-full mb-6">
                    <SearchIcon className="w-10 h-10 text-gray-300" />
                 </div>
                 <h3 className="text-xl font-black text-gray-900">No products found</h3>
                 <p className="text-gray-500 mt-2 max-w-xs mx-auto">We couldn't find anything matching your search. Try adjusting your filters or search terms.</p>
                 <button 
                  onClick={() => {
                    setSearchParams({});
                  }}
                  className="mt-8 px-6 py-2.5 bg-[#f37920] text-white font-bold rounded-md hover:bg-[#d66616] transition-all shadow-sm"
                 >
                   সব পণ্য দেখুন
                 </button>
               </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
