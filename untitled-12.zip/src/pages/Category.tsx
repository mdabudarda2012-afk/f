import { useState, useEffect, useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import Layout from '../layouts/Layout';
import { Filter, Search as SearchIcon, ChevronRight } from 'lucide-react';
import { subscribeToProducts, subscribeToCategories } from '../lib/api';
import { motion } from 'motion/react';
import { Product } from '../store';

export default function Category() {
  const { categoryName: rawCategoryName } = useParams();
  const categoryName = rawCategoryName ? decodeURIComponent(rawCategoryName) : '';
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [sortBy, setSortBy] = useState('newest');

  useEffect(() => {
    const unsub = subscribeToProducts((data) => {
      setProducts(data);
    });
    const unsubCat = subscribeToCategories((data) => {
      setCategories(data);
    });
    return () => {
      unsub();
      unsubCat();
    };
  }, []);

  const currentCategory = useMemo(() => {
    return categories.find(c => c.name === categoryName) || { name: categoryName, description: '' };
  }, [categories, categoryName]);

  const filteredAndSortedProducts = useMemo(() => {
    const result = products.filter(p => p.category === categoryName);

    if (sortBy === 'newest') {
      result.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    } else if (sortBy === 'price-low') {
      result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'price-high') {
      result.sort((a, b) => b.price - a.price);
    }

    return result;
  }, [products, categoryName, sortBy]);

  return (
    <Layout>
      {/* Category Header */}
      <div className="bg-white border-b border-gray-100 py-12 md:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-gray-400 mb-6">
            <Link to="/" className="hover:text-primary-600 transition-colors">Home</Link>
            <ChevronRight className="w-3 h-3" />
            <Link to="/products" className="hover:text-primary-600 transition-colors">Categories</Link>
            <ChevronRight className="w-3 h-3" />
            <span className="text-primary-700">{categoryName}</span>
          </nav>
          
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <h1 className="text-4xl md:text-5xl font-black text-gray-900 tracking-tighter uppercase italic leading-none md:mb-0">
                {categoryName}
              </h1>
              {currentCategory.description && (
                 <p className="text-gray-500 max-w-2xl font-medium mt-4">
                   {currentCategory.description}
                 </p>
              )}
            </div>
            <div className="flex items-center gap-4">
              <div className="px-5 py-2.5 bg-primary-50 rounded-2xl border border-primary-100">
                <span className="text-primary-800 font-black text-sm">{filteredAndSortedProducts.length} Items</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          
          {/* Filters Sidebar */}
          <div className="w-full md:w-64 flex-shrink-0">
            <div className="sticky top-24 space-y-8">
              <div>
                <h2 className="text-sm font-black text-gray-900 uppercase tracking-[0.2em] mb-6 flex items-center gap-2">
                  <Filter className="w-4 h-4 text-primary-600" /> Categories
                </h2>
                <div className="flex flex-col gap-1.5">
                  {categories.map((cat) => (
                    <Link
                      key={cat.id}
                      to={`/category/${encodeURIComponent(cat.name)}`}
                      className={`px-4 py-3 rounded-xl font-bold text-sm transition-all ${
                        categoryName === cat.name
                          ? 'bg-primary-900 text-white shadow-lg shadow-primary-900/10'
                          : 'text-gray-600 hover:bg-gray-100'
                      }`}
                    >
                      {cat.name}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Product Grid */}
          <div className="flex-1">
            <div className="flex mb-8 justify-between items-center bg-white p-4 rounded-2xl border border-gray-100 shadow-sm transition-all duration-500">
              <span className="text-sm font-bold text-gray-400 uppercase tracking-widest hidden sm:inline">Sort By</span>
              <div className="flex gap-2">
                {['newest', 'price-low', 'price-high'].map((option) => (
                  <button
                    key={option}
                    onClick={() => setSortBy(option)}
                    className={`px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider transition-all ${
                      sortBy === option
                        ? 'bg-primary-100 text-primary-700'
                        : 'text-gray-400 hover:bg-gray-50'
                    }`}
                  >
                    {option === 'newest' ? 'Newest' : option === 'price-low' ? 'Price Low' : 'Price High'}
                  </button>
                ))}
              </div>
            </div>

            {filteredAndSortedProducts.length > 0 ? (
              <div className="grid grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredAndSortedProducts.map((product, idx) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                  >
                    <ProductCard product={product} />
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-24 bg-white rounded-3xl border border-gray-100">
                <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6">
                  <SearchIcon className="w-10 h-10 text-gray-200" />
                </div>
                <h3 className="text-xl font-black text-gray-900 mb-2">No products in this category</h3>
                <p className="text-gray-500 font-medium">Check back later or explore other categories.</p>
                <Link to="/products" className="mt-8 inline-block px-8 py-3 bg-primary-700 text-white font-black rounded-xl hover:bg-primary-800 transition-all uppercase tracking-widest text-xs italic">
                  সব পণ্য দেখুন
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}
