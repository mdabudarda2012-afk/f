import { useState } from 'react';
import { User, ShieldCheck, Mail, Lock, AlertCircle } from 'lucide-react';
import Layout from '../layouts/Layout';
import { auth } from '../lib/firebase';
import { signInWithPopup, GoogleAuthProvider, signInWithEmailAndPassword, signOut } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';

const ADMIN_EMAILS = [
  'tipsandtechunlimited@gmail.com',
  'mdjaberboss2@gmail.com', 
  'admin@example.com', 
  'admin@kholosshop.com', 
  'nmd032984@gmail.com'
];

export default function Account() {
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleAdminAuth = async (userObj: any) => {
    if (userObj?.email && ADMIN_EMAILS.includes(userObj.email.toLowerCase())) {
        navigate('/dashboard');
    } else {
        await signOut(auth);
        setError('দুঃখিত, এই লগইনটি শুধুমাত্র অ্যাডমিনদের জন্য। আপনার অনুমতি নেই। (This login is only for administrators.)');
    }
  }

  const handleGoogleLogin = async () => {
    try {
      setError('');
      const provider = new GoogleAuthProvider();
      const res = await signInWithPopup(auth, provider);
      await handleAdminAuth(res.user);
    } catch (e: any) {
      console.error(e);
      setError(e.message || 'Login failed');
    }
  };

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    try {
      setLoading(true);
      setError('');
      const res = await signInWithEmailAndPassword(auth, email, password);
      await handleAdminAuth(res.user);
    } catch (e: any) {
      console.error(e);
      setError('Invalid email or password.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <Layout>
      <div className="bg-primary-50 min-h-[70vh] flex items-center justify-center py-16 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-accent/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-primary-200/40 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-md w-full relative z-10">
          <div className="bg-white/80 backdrop-blur-xl p-8 md:p-12 rounded-[2.5rem] shadow-2xl border border-white relative overflow-hidden group">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-accent via-yellow-400 to-accent"></div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-tr from-accent to-yellow-400 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg shadow-accent/20 transform rotate-3 group-hover:rotate-6 transition-transform duration-500">
                <User className="w-10 h-10 text-white transform -rotate-3 group-hover:-rotate-6 transition-transform duration-500" />
              </div>
              <h2 className="mt-4 text-3xl font-black text-primary-950 tracking-tight">Access Portal</h2>
              
              <div className="mt-8 bg-black/5 rounded-3xl p-6 border border-black/5 shadow-inner">
                 <h3 className="text-lg font-black text-primary-950 mb-2">Dear Customer,</h3>
                 <p className="text-primary-700 font-medium leading-relaxed text-sm">
                   You don't need an account to place an order! You can simply <span className="font-bold underline decoration-accent decoration-2 underline-offset-2">checkout as guest</span> and easily buy anything from our store.
                 </p>
                 <button 
                   onClick={() => navigate('/products')}
                   className="mt-6 w-full py-4 bg-primary-950 text-white rounded-2xl font-bold hover:bg-accent transition-all duration-300 shadow-xl shadow-primary-900/10 hover:shadow-accent/20 hover:-translate-y-1"
                 >
                   Start Shopping Now
                 </button>
              </div>
            </div>

            <div className="pt-8 flex justify-center opacity-30 hover:opacity-100 transition-opacity duration-300">
              <button 
                onClick={() => { setShowAdminLogin(!showAdminLogin); setError(''); }}
                className="text-[10px] font-black text-primary-400 uppercase tracking-widest flex items-center gap-1.5 hover:text-accent transition-colors"
              >
                <ShieldCheck className="w-4 h-4" /> Secure Admin Access
              </button>
            </div>

            {showAdminLogin && (
              <div className="pt-6 mt-6 border-t border-primary-100 animate-in fade-in slide-in-from-top-4 duration-500">
                
                {error && (
                  <div className="mb-6 p-4 bg-red-50 text-red-600 rounded-2xl flex items-start gap-3 border border-red-100 text-sm font-medium animate-in shake">
                     <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                     <p>{error}</p>
                  </div>
                )}

                <form onSubmit={handleEmailLogin} className="space-y-4 mb-6">
                   <div className="relative group/input">
                      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                         <Mail className="w-5 h-5 text-primary-400 group-focus-within/input:text-accent transition-colors" />
                      </div>
                      <input 
                         type="email" 
                         value={email}
                         onChange={(e) => setEmail(e.target.value)}
                         required
                         className="w-full pl-12 pr-4 py-4 bg-white border-2 border-primary-100 rounded-2xl focus:ring-4 focus:ring-accent/10 focus:border-accent outline-none text-sm font-medium transition-all"
                         placeholder="Administrator Email"
                      />
                   </div>
                   <div className="relative group/input">
                      <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                         <Lock className="w-5 h-5 text-primary-400 group-focus-within/input:text-accent transition-colors" />
                      </div>
                      <input 
                         type="password" 
                         value={password}
                         onChange={(e) => setPassword(e.target.value)}
                         required
                         className="w-full pl-12 pr-4 py-4 bg-white border-2 border-primary-100 rounded-2xl focus:ring-4 focus:ring-accent/10 focus:border-accent outline-none text-sm font-medium transition-all"
                         placeholder="Secure Password"
                      />
                   </div>
                   <button 
                     type="submit"
                     disabled={loading}
                     className="w-full py-4 bg-accent text-white rounded-2xl font-black flex items-center justify-center gap-2 hover:bg-accent-hover transition-all duration-300 disabled:opacity-70 shadow-lg shadow-accent/20 hover:shadow-accent/40 hover:-translate-y-1 relative overflow-hidden"
                   >
                     <span className="relative z-10">{loading ? 'Authenticating...' : 'Sign In'}</span>
                     <div className="absolute inset-0 bg-white/20 transform -skew-x-12 -translate-x-full group-hover:animate-[shine_1.5s_ease-in-out]"></div>
                   </button>
                </form>

                <div className="flex items-center gap-4 mb-6">
                  <div className="h-px bg-primary-100 flex-1"></div>
                  <span className="text-[10px] font-black text-primary-300 uppercase tracking-widest">Single Sign-On</span>
                  <div className="h-px bg-primary-100 flex-1"></div>
                </div>

                <button 
                  type="button"
                  onClick={handleGoogleLogin}
                  className="w-full py-4 bg-white text-primary-950 border-2 border-primary-100 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-primary-50 transition-colors shadow-sm hover:border-primary-200"
                >
                  <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
                  Continue with Google
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
}