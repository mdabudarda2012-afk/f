import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, ChevronLeft, ShieldCheck, Truck, RotateCcw, Minus, Plus, Star, PhoneCall, Share2, Facebook, MessageCircle, Copy, Check } from 'lucide-react';
import { useStore, Product } from '../store';
import { subscribeToProducts, subscribeToProductReviews, addReview, subscribeToBrands, getSettings } from '../lib/api';
import Layout from '../layouts/Layout';
import ProductCard from '../components/ProductCard';
import { motion, AnimatePresence } from 'motion/react';

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useStore();
  const [product, setProduct] = useState<Product | null>(null);
  const [activeTab, setActiveTab] = useState('Details');
  const [mainImage, setMainImage] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [selectedOption, setSelectedOption] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [settings, setSettings] = useState<any>({});
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const [brands, setBrands] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '', reviewerName: '', reviewerPhone: '' });
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);

  useEffect(() => {
    getSettings().then(setSettings);
    
    const unsub = subscribeToProducts((products) => {
      setAllProducts(products as Product[]);
      const found = products.find((p: any) => p.id === id);
      if (found) {
        setProduct(found as Product);
        setMainImage(found.image);
      }
      setIsLoading(false);
    });

    const unsubBrands = subscribeToBrands((data) => {
       setBrands(data);
    });

    return () => {
      unsub();
      unsubBrands();
    };
  }, [id]);

  useEffect(() => {
    if (id) {
       const unsubReviews = subscribeToProductReviews(id, (data) => {
         // Show only approved or pending reviews as is for now, depending on rules
         setReviews(data);
       });
       return unsubReviews;
    }
  }, [id]);

  if (isLoading) {
    return (
      <Layout>
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-700"></div>
        </div>
      </Layout>
    );
  }

  if (!product) {
    return (
      <Layout>
        <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Product Not Found</h1>
          <Link to="/products" className="text-primary-700 font-bold flex items-center gap-2">
            <ChevronLeft className="w-5 h-5" /> Back to Products
          </Link>
        </div>
      </Layout>
    );
  }

  const handleAddToCart = () => {
    const opts = product.options ? product.options.split(',').map((o:any)=>o.trim()).filter(Boolean) : [];
    if (opts.length > 0 && !selectedOption) {
       alert('দয়া করে একটি অপশন নির্বাচন করুন।');
       return false;
    }
    for (let i = 0; i < quantity; i++) {
      addToCart(product, selectedOption);
    }
    return true;
  };

  const handleBuyNow = () => {
    if (handleAddToCart()) {
      navigate('/checkout');
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: product.name,
          text: product.shortDescription || `Check out this product: ${product.name}`,
          url: window.location.href,
        });
      } catch (error) {
        if ((error as any).name !== 'AbortError') {
          setShowShareMenu(!showShareMenu);
        }
      }
    } else {
      setShowShareMenu(!showShareMenu);
    }
  };

  const shareOnFacebook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`, '_blank');
    setShowShareMenu(false);
  };

  const shareOnWhatsApp = () => {
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(product.name + ' ' + window.location.href)}`, '_blank');
    setShowShareMenu(false);
  };

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setLinkCopied(true);
    setTimeout(() => setLinkCopied(false), 2000);
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!id || !reviewForm.comment || !reviewForm.reviewerName || !reviewForm.reviewerPhone) return;
    setIsSubmittingReview(true);
    await addReview(id, reviewForm);
    setReviewForm({ rating: 5, comment: '', reviewerName: '', reviewerPhone: '' });
    setIsSubmittingReview(false);
    alert('Thank you for your review! It has been submitted successfully.');
  };

  const totalRating = reviews.reduce((acc, r) => acc + (r.rating || 5), 0);
  const avgRating = reviews.length > 0 ? (totalRating / reviews.length).toFixed(1) : '0';
  const reviewCount = reviews.length;

  const relatedProducts = allProducts.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);

  return (
    <Layout>
      <div className="bg-gray-50 min-h-screen py-4 md:py-8 pb-32 md:pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          {/* Breadcrumbs */}
          <nav className="flex mb-6 text-sm text-gray-500 gap-2 whitespace-nowrap overflow-x-auto pb-2 scrollbar-hide">
            <Link to="/" className="hover:text-primary-700">Home</Link>
            <span>/</span>
            <Link to="/products" className="hover:text-primary-700">Products</Link>
            <span>/</span>
            <span className="text-gray-900 font-medium truncate">{product.name}</span>
          </nav>

          <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-4 md:p-8">
              
              {/* Product Images */}
              <div className="space-y-4">
                <div className="aspect-square bg-gray-50 rounded-lg overflow-hidden border border-gray-100 relative group">
                  <img 
                    src={mainImage || product.image} 
                    alt={product.name} 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-contain mix-blend-multiply group-hover:scale-105 transition-transform duration-500" 
                  />
                  {product.originalPrice && (
                    <div className="absolute top-4 left-4 bg-red-600 text-white text-xs font-bold px-3 py-1 rounded shadow-md">
                      SAVE {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}%
                    </div>
                  )}
                </div>
                {/* Thumbnails */}
                {((product.images && product.images.length > 0) || product.image) && (
                  <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
                    {[product.image, ...(product.images || [])].map((img, idx) => (
                      <button 
                        key={idx} 
                        onClick={() => setMainImage(img)}
                        className={`w-20 h-20 rounded-md overflow-hidden bg-gray-50 flex-shrink-0 transition-all border-2 ${mainImage === img ? 'border-primary-700 opacity-100' : 'border-transparent opacity-60 hover:opacity-100 hover:border-primary-300'}`}
                      >
                         <img src={img} alt="" referrerPolicy="no-referrer" className="w-full h-full object-cover mix-blend-multiply" />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Product Info */}
              <div className="flex flex-col">
                <div className="mb-4 flex items-center justify-between">
                   <div className="flex flex-wrap items-center gap-3">
                     {product.brand && (
                       <Link to={`/products?brand=${encodeURIComponent(product.brand)}`} className="group flex items-center gap-2">
                         {brands.find(b => b.name === product.brand)?.image && (
                           <img src={brands.find(b => b.name === product.brand)?.image} alt={product.brand} referrerPolicy="no-referrer" className="h-6 w-auto object-contain rounded drop-shadow-sm group-hover:scale-105 transition-transform" />
                         )}
                         <span className="text-primary-800 font-black text-[11px] uppercase tracking-wider bg-primary-50 px-2.5 py-1 rounded-md border border-primary-100 group-hover:bg-primary-100 transition-colors">
                           {product.brand}
                         </span>
                       </Link>
                     )}
                     <span className="text-gray-500 font-bold text-[10px] uppercase tracking-wider bg-gray-100 px-2.5 py-1 rounded-md border border-gray-200">{product.category}</span>
                     {product.isVerified && (
                        <span className="flex items-center gap-1 text-[10px] font-black text-green-600 bg-green-50 px-2.5 py-1 rounded-md border border-green-200 uppercase tracking-widest"><ShieldCheck className="w-3 h-3" /> Verified Product</span>
                     )}
                  </div>
                  <div className="relative">
                    <button 
                      onClick={handleShare}
                      className="p-2.5 bg-gray-50 text-gray-400 hover:text-primary-700 hover:bg-primary-50 rounded-full transition-all border border-gray-100 flex items-center gap-2 group"
                    >
                      <Share2 className="w-4 h-4 group-hover:scale-110 transition-transform" />
                      <span className="text-[10px] font-black uppercase tracking-widest hidden sm:inline">Share</span>
                    </button>

                    <AnimatePresence>
                      {showShareMenu && (
                        <>
                          <motion.div 
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            exit={{ opacity: 0 }}
                            onClick={() => setShowShareMenu(false)}
                            className="fixed inset-0 z-40"
                          />
                          <motion.div 
                            initial={{ opacity: 0, scale: 0.95, y: 10 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.95, y: 10 }}
                            className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden z-50 p-2"
                          >
                            <div className="flex flex-col gap-1">
                              <button 
                                onClick={shareOnFacebook}
                                className="flex items-center gap-3 px-4 py-3 hover:bg-blue-50 text-blue-600 rounded-xl transition-colors font-bold text-sm"
                              >
                                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                                  <Facebook className="w-4 h-4" />
                                </div>
                                Facebook
                              </button>
                              <button 
                                onClick={shareOnWhatsApp}
                                className="flex items-center gap-3 px-4 py-3 hover:bg-green-50 text-green-600 rounded-xl transition-colors font-bold text-sm"
                              >
                                <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                                  <MessageCircle className="w-4 h-4" />
                                </div>
                                WhatsApp
                              </button>
                              <button 
                                onClick={copyLink}
                                className="flex items-center justify-between px-4 py-3 hover:bg-gray-50 text-gray-700 rounded-xl transition-colors font-bold text-sm"
                              >
                                <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center">
                                    {linkCopied ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
                                  </div>
                                  {linkCopied ? 'Copied!' : 'Copy Link'}
                                </div>
                              </button>
                            </div>
                          </motion.div>
                        </>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
                <h1 className="text-2xl md:text-3xl font-extrabold text-gray-900 mb-4 leading-tight">
                  {product.name} 
                  {product.unit && <span className="text-lg md:text-xl font-normal text-gray-500 ml-2">({product.unit})</span>}
                </h1>
                
                <div className="flex items-center gap-4 mb-6">
                   <div className="flex items-center gap-1.5 bg-yellow-50 px-3 py-1.5 rounded-xl border border-yellow-100">
                      <div className="flex items-center gap-0.5">
                        {[1,2,3,4,5].map(i => <Star key={i} className={`w-4 h-4 ${i <= Math.floor(parseFloat(avgRating)) ? 'text-accent' : 'text-gray-200'}`} strokeWidth={1.5} />)}
                      </div>
                      <span className="text-yellow-700 text-sm ml-1 font-black">{avgRating} <span className="font-medium text-yellow-600/60 ml-0.5">({reviewCount} Reviews)</span></span>
                   </div>
                   {product.inStock && (
                     <>
                       <span className="h-6 w-px bg-gray-200"></span>
                       <span className="text-xs font-black text-primary-700 bg-primary-50 px-3 py-1.5 rounded-xl border border-primary-100 uppercase tracking-widest flex items-center gap-2">
                         <ShieldCheck className="w-3.5 h-3.5" /> In Stock
                       </span>
                     </>
                   )}
                </div>

                <div className="flex items-baseline gap-3 mb-4">
                  <span className="text-3xl font-black text-primary-900">৳{product.price}</span>
                  {product.originalPrice && (
                    <span className="text-lg text-gray-400 line-through font-medium">৳{product.originalPrice}</span>
                  )}
                </div>

                {product.shortDescription && (
                  <p className="text-gray-700 font-medium text-lg leading-relaxed mb-6 italic bg-primary-50 p-4 rounded-xl border border-primary-100/50">
                    "{product.shortDescription}"
                  </p>
                )}

                {product.options && (
                  <div className="mb-6 bg-gray-50 p-5 rounded-2xl border border-gray-100">
                    <span className="font-extrabold text-gray-500 uppercase tracking-widest text-[11px] block mb-3">অপশন নির্বাচন করুন</span>
                    <div className="flex flex-wrap gap-2.5">
                      {product.options.split(',').map((o: any) => o.trim()).filter(Boolean).map((opt: string, i: number) => (
                        <button
                          key={i}
                          type="button"
                          onClick={() => setSelectedOption(opt)}
                          className={`px-5 py-3 rounded-xl border-2 text-sm font-bold transition-all ${
                            selectedOption === opt
                              ? 'border-primary-700 bg-primary-50 text-primary-950 shadow-md shadow-primary-700/5'
                              : 'border-gray-200 bg-white text-gray-600 hover:border-gray-300 active:scale-95'
                          }`}
                        >
                          {opt}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Quantity and Actions */}
                <div className="space-y-8 mt-auto">
                   <div className="flex items-center gap-6 p-4 bg-gray-50 rounded-2xl border border-gray-100">
                      <span className="font-black text-gray-400 uppercase tracking-widest text-[10px]">পরিমাণ নির্বাচন করুন</span>
                      <div className="flex items-center bg-white rounded-xl shadow-sm border border-gray-100 p-1 ml-auto">
                        <button 
                          onClick={() => setQuantity(Math.max(1, quantity - 1))}
                          className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-red-50 hover:text-red-500 transition-all active:scale-95 disabled:opacity-50"
                          disabled={!product.inStock}
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="w-12 text-center font-black text-primary-950 text-lg">{quantity}</span>
                        <button 
                          onClick={() => setQuantity(quantity + 1)}
                          className="w-10 h-10 flex items-center justify-center rounded-lg hover:bg-primary-50 hover:text-primary-700 transition-all active:scale-95 disabled:opacity-50"
                          disabled={!product.inStock}
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                   </div>

                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {product.inStock ? (
                        <>
                          <motion.button 
                            onClick={() => {
        const opts = product.options ? product.options.split(',').map((o:any)=>o.trim()).filter(Boolean) : [];
        if (opts.length > 0 && !selectedOption) {
           alert('দয়া করে একটি অপশন নির্বাচন করুন।');
           return;
        }
        handleBuyNow();
      }}
                            animate={{ 
                              scale: [1, 1.05, 1],
                              backgroundColor: ['#059669', '#10b981', '#059669'],
                              boxShadow: [
                                "0 20px 40px rgba(16, 185, 129, 0.3)",
                                "0 22px 50px rgba(16, 185, 129, 0.6)",
                                "0 20px 40px rgba(16, 185, 129, 0.3)"
                              ]
                            }}
                            transition={{ 
                              repeat: Infinity, 
                              duration: 1.2,
                              ease: "easeInOut"
                            }}
                            className="bg-primary-600 text-white font-black py-5 rounded-[1.5rem] hover:bg-primary-700 transition-all active:scale-95 flex items-center justify-center gap-3 text-lg uppercase tracking-widest italic"
                          >
                            <ShoppingCart className="w-6 h-6" /> অর্ডার করুন
                          </motion.button>
                          <button 
                            onClick={handleAddToCart}
                            className="bg-white text-primary-700 border-2 border-primary-100 font-extrabold py-5 rounded-[1.5rem] hover:border-primary-700 transition-all flex items-center justify-center gap-3 text-lg uppercase tracking-widest italic shadow-sm hover:shadow-md"
                          >
                            <Plus className="w-6 h-6" /> কার্টে যোগ করুন
                          </button>
                        </>
                      ) : (
                        <div className="sm:col-span-2">
                          <button disabled className="w-full bg-red-100 text-red-600 font-black py-5 rounded-[1.5rem] flex items-center justify-center gap-3 text-lg uppercase tracking-widest italic shadow-sm opacity-60 cursor-not-allowed">
                            <ShoppingCart className="w-6 h-6" /> আউট অফ স্টক
                          </button>
                        </div>
                      )}
                   </div>
                   
                   <div className="grid grid-cols-2 gap-3">
                      <a 
                        href={`https://wa.me/${settings?.phone?.replace(/\D/g, '') || '880187814559'}?text=I want to order: ${product.name}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1 bg-[#25D366] text-white font-black py-4 rounded-2xl hover:bg-[#128C7E] transition-all shadow-md active:scale-95 flex items-center justify-center gap-3 text-xs uppercase tracking-widest"
                      >
                        <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" /></svg>
                        WHATSAPP
                      </a>
                      <a 
                        href={`tel:0187814559`}
                        className="flex-1 bg-primary-950 text-white font-black py-4 rounded-2xl hover:bg-black transition-all shadow-md active:scale-95 flex items-center justify-center gap-3 text-xs uppercase tracking-widest"
                      >
                        <PhoneCall className="w-5 h-5 text-accent" />
                        ০১৮৭৮১৪৫৫৯
                      </a>
                   </div>
                </div>

                {/* Benefits */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-10 pt-8 border-t border-gray-100">
                   <div className="flex flex-col items-center text-center">
                      <Truck className="w-6 h-6 text-primary-600 mb-2" />
                      <span className="text-[10px] font-bold text-gray-500 uppercase">Fast Delivery</span>
                   </div>
                   <div className="flex flex-col items-center text-center">
                      <ShieldCheck className="w-6 h-6 text-primary-600 mb-2" />
                      <span className="text-[10px] font-bold text-gray-500 uppercase">100% Authentic</span>
                   </div>
                   <div className="flex flex-col items-center text-center">
                      <RotateCcw className="w-6 h-6 text-primary-600 mb-2" />
                      <span className="text-[10px] font-bold text-gray-500 uppercase">Return Policy</span>
                   </div>
                </div>
              </div>

            </div>
          </div>

          {/* Related/Info Tabs */}
          <div className="mt-12 space-y-8" id="details-section">
             <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
               {/* Tab Navigation */}
               <div className="flex flex-wrap sm:flex-nowrap sm:overflow-x-auto no-scrollbar border-b border-gray-100 bg-gray-50/50">
                 {['Details', 'Specifications', 'Seller', 'Reviews', 'Questions'].map((tab) => (
                   <button
                     key={tab}
                     onClick={() => setActiveTab(tab)}
                     className={`px-3 py-3 sm:px-6 sm:py-4 font-bold text-xs sm:text-sm whitespace-nowrap transition-colors relative ${['Details', 'Specifications', 'Seller'].includes(tab) ? 'w-[33.33%] sm:w-auto' : 'w-[50%] border-t border-gray-100 sm:border-t-0 sm:w-auto'} ${activeTab === tab ? 'text-primary-700 bg-white shadow-sm' : 'text-gray-500 hover:text-gray-900 bg-gray-50/50'}`}
                   >
                     {tab}
                     {activeTab === tab && (
                       <motion.div layoutId="activeTabIndicator" className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-700" />
                     )}
                   </button>
                 ))}
               </div>

               {/* Tab Content */}
               <div className="p-6 md:p-8 min-h-[400px]">
                 <AnimatePresence mode="wait">
                   {activeTab === 'Details' && (
                     <motion.div key="details" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="prose prose-sm md:prose-base max-w-none text-gray-600 font-medium">
                       {product.description ? (
                         <div dangerouslySetInnerHTML={{ __html: product.description.replace(/\n/g, '<br/>') }} />
                       ) : (
                         <>
                           <p>আমরা আমাদের গ্রাহকদের জন্য সরাসরি খামার ও প্রকৃতি থেকে সংগৃহীত সেরা মানের পণ্য নিশ্চিত করি। আমাদের পণ্যগুলো কোনো প্রকার কেমিক্যাল বা ভেজাল মুক্ত।</p>
                           <ul className="list-disc pl-5 space-y-2 mt-4 font-medium">
                               <li>১০০% প্রাকৃতিক ও বিশুদ্ধ</li>
                               <li>স্বাস্থ্যসম্মত উপায়ে প্যাকেটজাত</li>
                               <li>সেরা স্বাদের এবং গুনাগুণের নিশ্চয়তা</li>
                               <li>ডেলিভারি পাওয়ার পর পণ্য চেক করে পেমেন্ট করার সুযোগ</li>
                           </ul>
                         </>
                       )}
                     </motion.div>
                   )}

                   {activeTab === 'Specifications' && (
                     <motion.div key="specs" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                       <table className="w-full text-left border-collapse max-w-xl">
                         <tbody>
                           <tr className="border-b border-gray-100">
                             <th className="py-3 pr-4 text-gray-500 font-medium w-1/3">Category</th>
                             <td className="py-3 text-gray-900 font-bold">{product.category}</td>
                           </tr>
                           <tr className="border-b border-gray-100">
                             <th className="py-3 pr-4 text-gray-500 font-medium w-1/3">Brand</th>
                             <td className="py-3 text-gray-900 font-bold">{product.brand || 'No Brand'}</td>
                           </tr>
                           <tr>
                             <th className="py-3 pr-4 text-gray-500 font-medium w-1/3">Stock Status</th>
                             <td className="py-3 text-gray-900 font-bold">{product.inStock ? 'In Stock' : 'Out of Stock'}</td>
                           </tr>
                         </tbody>
                       </table>
                     </motion.div>
                   )}

                   {activeTab === 'Seller' && (
                     <motion.div key="seller" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="flex items-start gap-6 bg-gray-50 p-6 rounded-xl border border-gray-100">
                       <div className="w-20 h-20 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 text-2xl font-black shrink-0">
                         KS
                       </div>
                       <div>
                         <h4 className="text-xl font-bold text-gray-900">KholosShop Official</h4>
                         <p className="text-gray-500 text-sm mt-1">Premium Organic Products Retailer</p>
                         <div className="flex flex-wrap items-center gap-4 mt-3">
                           <span className="flex items-center gap-1 text-sm font-bold text-green-700 bg-green-100 px-2 py-1 rounded"><ShieldCheck className="w-4 h-4" /> Verified Seller</span>
                           <span className="flex items-center gap-1 text-sm font-bold text-orange-700 bg-orange-100 px-2 py-1 rounded"><Star className="w-4 h-4" fill="currentColor" /> 4.9/5 Rating</span>
                         </div>
                       </div>
                     </motion.div>
                   )}

                   {activeTab === 'Reviews' && (
                     <motion.div key="reviews" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                       <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
                         <div className="md:col-span-1 border-b md:border-b-0 md:border-r border-gray-100 pb-6 md:pb-0 md:pr-6 text-center md:text-left flex flex-col justify-center">
                           <span className="text-6xl font-black text-gray-900 leading-none">{avgRating}</span>
                           <div className="flex justify-center md:justify-start mt-3">
                              {[1,2,3,4,5].map(i => <Star key={i} className={`w-6 h-6 ${i <= Math.floor(parseFloat(avgRating)) ? 'text-accent' : 'text-gray-200'}`} strokeWidth={1.5} />)}
                           </div>
                           <p className="text-gray-500 font-medium text-sm mt-2">Based on {reviewCount} reviews</p>
                         </div>
                         <div className="md:col-span-2 space-y-3">
                           {[5,4,3,2,1].map((star) => {
                             const countForStar = reviews.filter(r => (r.rating || 5) === star).length;
                             const percentage = reviewCount > 0 ? (countForStar / reviewCount) * 100 : 0;
                             return (
                               <div key={star} className="flex items-center gap-3">
                                 <span className="text-sm font-bold text-gray-600 w-12">{star} Star</span>
                                 <div className="flex-1 h-3 bg-gray-100 rounded-full overflow-hidden">
                                   <div className="h-full bg-accent rounded-full transition-all" style={{ width: `${percentage}%` }}></div>
                                 </div>
                                 <span className="text-xs font-medium text-gray-400 w-8">{Math.round(percentage)}%</span>
                               </div>
                             );
                           })}
                         </div>
                       </div>

                       {reviews.length > 0 ? (
                         <div className="space-y-4 mb-10">
                           {reviews.map((review, idx) => (
                             <div key={idx} className="bg-gray-50/50 p-6 rounded-2xl border border-gray-100">
                               <div className="flex justify-between items-start mb-3">
                                 <div>
                                   <h4 className="font-bold text-gray-900">{review.reviewerName}</h4>
                                   <div className="flex items-center mt-1">
                                     {[1,2,3,4,5].map(i => <Star key={i} className={`w-4 h-4 ${i <= review.rating ? 'text-accent' : 'text-gray-200'}`} strokeWidth={1.5} />)}
                                   </div>
                                 </div>
                                 {review.createdAt && (
                                   <span className="text-xs text-gray-400 font-medium">{new Date(review.createdAt.seconds * 1000).toLocaleDateString()}</span>
                                 )}
                               </div>
                               <p className="text-gray-600 font-medium leading-relaxed">{review.comment}</p>
                             </div>
                           ))}
                         </div>
                       ) : (
                         <div className="text-center py-10 bg-gray-50 rounded-2xl border border-gray-100 border-dashed mb-10">
                           <p className="text-gray-500 font-medium">No reviews yet. Be the first to review!</p>
                         </div>
                       )}

                       <div className="bg-white rounded-2xl p-6 md:p-8 border border-primary-100 shadow-[0_4px_20px_rgba(20,83,45,0.05)] border-t-4 border-t-primary-700">
                          <h4 className="text-xl font-bold text-gray-900 mb-6">Write a Review</h4>
                          <form onSubmit={handleReviewSubmit} className="space-y-4">
                            <div>
                              <label className="block text-sm font-bold text-gray-700 mb-2">Rating</label>
                              <div className="flex gap-2">
                                {[1,2,3,4,5].map(star => (
                                  <button 
                                    key={star} 
                                    type="button" 
                                    onClick={() => setReviewForm(prev => ({ ...prev, rating: star }))}
                                  >
                                    <Star className={`w-8 h-8 ${star <= reviewForm.rating ? 'text-accent' : 'text-gray-300 hover:text-accent/50 transition-colors'}`} fill={star <= reviewForm.rating ? "currentColor" : "none"} />
                                  </button>
                                ))}
                              </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div>
                                <label className="block text-sm font-bold text-gray-700 mb-2">Full Name <span className="text-red-500">*</span></label>
                                <input 
                                  type="text" 
                                  required
                                  value={reviewForm.reviewerName}
                                  onChange={e => setReviewForm(prev => ({ ...prev, reviewerName: e.target.value }))}
                                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all" 
                                  placeholder="John Doe" 
                                />
                              </div>
                              <div>
                                <label className="block text-sm font-bold text-gray-700 mb-2">Phone Number <span className="text-red-500">*</span></label>
                                <input 
                                  type="tel" 
                                  required
                                  value={reviewForm.reviewerPhone}
                                  onChange={e => setReviewForm(prev => ({ ...prev, reviewerPhone: e.target.value }))}
                                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all" 
                                  placeholder="Phone used for order" 
                                />
                              </div>
                            </div>
                            <div>
                              <label className="block text-sm font-bold text-gray-700 mb-2">Your Review <span className="text-red-500">*</span></label>
                              <textarea 
                                required
                                rows={4} 
                                value={reviewForm.comment}
                                onChange={e => setReviewForm(prev => ({ ...prev, comment: e.target.value }))}
                                className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20 focus:border-primary-500 outline-none transition-all" 
                                placeholder="Share your experience with this product..."
                              ></textarea>
                            </div>
                            <button 
                              type="submit" 
                              disabled={isSubmittingReview}
                              className="px-8 py-3 bg-primary-950 text-white font-black uppercase tracking-widest text-xs rounded-xl hover:bg-black transition-all shadow-md disabled:bg-gray-400 disabled:cursor-not-allowed"
                            >
                              {isSubmittingReview ? 'Submitting...' : 'Submit Review'}
                            </button>
                          </form>
                       </div>
                     </motion.div>
                   )}

                   {activeTab === 'Questions' && (
                     <motion.div key="questions" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} className="text-center py-12">
                       <MessageCircle className="w-16 h-16 text-gray-200 mx-auto mb-4" />
                       <h4 className="text-xl font-bold text-gray-900 mb-2">Have a question about this product?</h4>
                       <p className="text-gray-500 mb-8 font-medium">Ask our community or the seller directly.</p>
                       <a href="https://wa.me/880187814559" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-8 py-4 bg-white border-2 border-primary-700 text-primary-700 font-black uppercase tracking-widest text-xs rounded-xl hover:bg-primary-50 transition-all shadow-sm">
                         <MessageCircle className="w-4 h-4" /> Ask Question
                       </a>
                     </motion.div>
                   )}
                 </AnimatePresence>
               </div>
             </div>

             <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 md:p-8">
                <h3 className="text-xl font-bold text-gray-900 mb-6 border-b border-gray-100 pb-4">Related Products</h3>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  {relatedProducts.map((related) => (
                    <ProductCard key={related.id} product={related} />
                  ))}
                </div>
             </div>
          </div>

        </div>
      </div>

      {/* Mobile Fixed Bottom Actions */}
      <div className="md:hidden fixed bottom-6 left-4 right-4 bg-white/95 backdrop-blur-xl border border-gray-100 z-50 flex gap-3 p-3 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.15)] animate-in fade-in slide-in-from-bottom-5">
        {product?.inStock ? (
          <>
            <button 
              onClick={() => {
                 if (handleAddToCart()) {
                    alert('পণ্যটি কার্টে যোগ করা হয়েছে!');
                 }
              }}
              className="flex-1 bg-primary-50 text-primary-900 border border-primary-200 font-extrabold py-3.5 rounded-xl flex items-center justify-center gap-2 active:scale-95 transition-all uppercase tracking-wider text-[10px]"
            >
              <ShoppingCart className="w-5 h-5" />
              Add to Cart
            </button>
            <motion.button 
              onClick={handleBuyNow}
              animate={{ 
                scale: [1, 1.02, 1],
              }}
              transition={{ 
                repeat: Infinity, 
                duration: 2,
                ease: "easeInOut"
              }}
              className="flex-[1.2] bg-primary-950 hover:bg-black text-white font-black py-3.5 rounded-xl active:scale-95 transition-all shadow-xl uppercase tracking-widest text-[11px]"
            >
              Order Now
            </motion.button>
          </>
        ) : (
          <button disabled className="w-full bg-red-100 text-red-600 font-extrabold py-3.5 rounded-xl transition-all uppercase tracking-widest text-xs flex justify-center items-center gap-2 opacity-80">
            <ShoppingCart className="w-5 h-5" /> আউট অফ স্টক
          </button>
        )}
      </div>
    </Layout>
  );
}
