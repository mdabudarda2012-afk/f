import { useState, useEffect } from 'react';
import Layout from '../layouts/Layout';
import { addReseller, getUserProfile } from '../lib/api';
import { auth } from '../lib/firebase';
import { useNavigate } from 'react-router-dom';

export default function ResellerRegistration() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    businessType: 'Social Media Seller',
    experience: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const fetchProfile = async () => {
      if (auth.currentUser?.uid) {
        const profile = await getUserProfile(auth.currentUser.uid) as any;
        if (profile) {
          setFormData(prev => ({
            ...prev,
            name: profile.displayName || auth.currentUser?.displayName || '',
            phone: profile.phone || '',
            address: profile.address || ''
          }));
        }
      }
    };
    fetchProfile();
  }, [auth.currentUser?.uid]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) {
      alert("Please login first to apply as a reseller!");
      return;
    }
    setIsSubmitting(true);
    try {
      await addReseller({
        ...formData,
        userId: auth.currentUser.uid,
        email: auth.currentUser.email || ''
      });
      alert('Your application has been submitted to the Admin!');
      navigate('/account');
    } catch (error: any) {
      alert('Error submitting application: ' + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Layout>
      <div className="bg-gray-50 min-h-[70vh] py-12">
        <div className="max-w-2xl mx-auto px-4">
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
            <h1 className="text-2xl font-black text-gray-900 mb-2">Reseller Registration</h1>
            <p className="text-gray-500 mb-8 border-b border-gray-100 pb-6">Join our reseller program and start earning. Fill in the details below and an admin will review your application.</p>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Full Name</label>
                <input required type="text" value={formData.name} onChange={e => setFormData(prev => ({ ...prev, name: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Phone Number</label>
                <input required type="tel" value={formData.phone} onChange={e => setFormData(prev => ({ ...prev, phone: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20" />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Address</label>
                <textarea required value={formData.address} onChange={e => setFormData(prev => ({ ...prev, address: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20" rows={2}></textarea>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Business Type</label>
                <select value={formData.businessType} onChange={e => setFormData(prev => ({ ...prev, businessType: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20">
                  <option>Social Media Seller</option>
                  <option>Physical Store</option>
                  <option>E-commerce Website</option>
                  <option>Other</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">Prior Experience (optional)</label>
                <textarea value={formData.experience} onChange={e => setFormData(prev => ({ ...prev, experience: e.target.value }))} className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-primary-500/20" rows={2}></textarea>
              </div>
              
              <button disabled={isSubmitting} type="submit" className="w-full py-4 bg-primary-950 hover:bg-black text-white font-black uppercase tracking-widest rounded-xl disabled:opacity-50">
                {isSubmitting ? 'Submitting...' : 'Submit Application'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </Layout>
  );
}
