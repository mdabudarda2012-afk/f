import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import Layout from '../layouts/Layout';
import { subscribeToBrands } from '../lib/api';

export default function Brands() {
  const [brands, setBrands] = useState<any[]>([]);

  useEffect(() => {
    const unsub = subscribeToBrands(setBrands);
    return unsub;
  }, []);

  return (
    <Layout>
      <div className="bg-white py-16">
        <div className="px-4 mx-auto max-w-[1440px] sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
             <h1 className="text-4xl md:text-5xl font-black text-gray-900 tracking-tighter uppercase italic leading-none mb-4">
                Our Brands
             </h1>
             <p className="text-gray-500 font-medium">
                Explore our full directory of premium and trusted brands.
             </p>
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
             {brands.map((brand, idx) => (
                <Link key={idx} to={`/products?brand=${encodeURIComponent(brand.name)}`} className="bg-gray-50/50 border border-gray-100 rounded-2xl h-[160px] flex items-center justify-center p-6 hover:bg-white hover:border-gray-200 hover:shadow-xl transition-all group scale-100 ease-out duration-300">
                   {brand.image ? (
                      <img src={brand.image} alt={brand.name} referrerPolicy="no-referrer" className="w-full h-full object-contain filter grayscale group-hover:grayscale-0 opacity-70 group-hover:opacity-100 group-hover:scale-110 transition-all duration-300" />
                   ) : (
                      <span className="font-black text-xl text-gray-400 group-hover:text-primary-950 transition-colors uppercase tracking-tight text-center">{brand.name}</span>
                   )}
                </Link>
             ))}
          </div>
          
          {brands.length === 0 && (
             <div className="text-center py-20 text-gray-400">
                <p>No brands found.</p>
             </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
