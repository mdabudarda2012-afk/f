import { Minus, Plus, Trash2, ArrowLeft, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useStore } from '../store';
import Layout from '../layouts/Layout';

export default function Cart() {
  const { cart, removeFromCart, updateQuantity, cartTotal } = useStore();

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'BDT',
      maximumFractionDigits: 0,
    }).format(price).replace('BDT', '৳');
  };

  const deliveryCharge = cart.length > 0 ? 100 : 0;
  const total = cartTotal() + deliveryCharge;

  if (cart.length === 0) {
    return (
      <Layout>
        <div className="flex flex-col items-center justify-center min-h-[60vh] px-4 py-16 bg-gray-50">
          <div className="w-32 h-32 mb-8 text-primary-200">
            <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
            </svg>
          </div>
          <h2 className="mb-4 text-2xl font-bold text-gray-900">আপনার কার্ট খালি</h2>
          <p className="mb-8 text-gray-500 text-center max-w-md">আপনার কার্টে বর্তমানে কোনো পণ্য নেই। সেরা মানের পণ্যগুলো দেখতে শপিং শুরু করুন।</p>
          <Link
            to="/products"
            className="flex items-center gap-2 px-8 py-3.5 text-sm font-bold text-primary-900 bg-accent rounded-md hover:bg-accent-hover transition-colors shadow-sm hover:-translate-y-0.5 transform duration-200"
          >
            <ArrowLeft className="w-4 h-4" />
            কেনাকাটা চালিয়ে যান
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12 bg-gray-50 min-h-screen">
        <h1 className="text-2xl font-extrabold text-gray-900 mb-8 border-l-4 border-primary-700 pl-3 leading-none">শপিং কার্ট</h1>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          {/* Cart Items */}
          <div className="lg:col-span-8">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              <ul className="divide-y divide-gray-100">
                {cart.map((item) => (
                  <li key={item.id} className="p-4 sm:p-6 flex flex-col sm:flex-row gap-4 sm:gap-6 hover:bg-gray-50/50 transition-colors">
                    <div className="flex-shrink-0 w-24 h-24 sm:w-32 sm:h-32 bg-gray-50 rounded-md border border-gray-100 p-2 relative overflow-hidden group flex items-center justify-center">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-contain group-hover:scale-105 transition-transform"
                      />
                    </div>

                    <div className="flex flex-col flex-1">
                      <div className="flex justify-between">
                        <div>
                          <h3 className="text-base sm:text-lg font-bold text-gray-900 line-clamp-2">{item.name}</h3>
                          <p className="mt-1 text-sm text-gray-500">{item.category}</p>
                        </div>
                        <p className="text-lg font-extrabold text-primary-700 ml-4 whitespace-nowrap">
                          {formatPrice(item.price * item.quantity)}
                        </p>
                      </div>

                      <div className="flex items-end justify-between flex-1 mt-4 sm:mt-0">
                        <div className="flex items-center bg-gray-50 border border-gray-200 rounded-md">
                          <button
                            onClick={() => updateQuantity(item.cartItemId, Math.max(1, item.quantity - 1))}
                            className="p-2 text-gray-500 hover:text-primary-700 hover:bg-gray-100 transition-colors"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="w-10 text-center font-bold text-gray-900 text-sm">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.cartItemId, item.quantity + 1)}
                            className="p-2 text-gray-500 hover:text-primary-700 hover:bg-gray-100 transition-colors"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>

                        <button
                          onClick={() => removeFromCart(item.cartItemId)}
                          className="flex items-center gap-1.5 text-sm font-medium text-red-500 hover:text-red-700 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                          <span className="hidden sm:inline">রিমুভ করুন</span>
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-4">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sticky top-24">
              <h2 className="text-lg font-bold text-gray-900 mb-6 border-b border-gray-100 pb-4">অর্ডার সামারি</h2>
              
              <div className="space-y-4 mb-6">
                <div className="flex justify-between text-sm text-gray-600 font-medium">
                  <span>সাবটোটাল</span>
                  <span className="font-bold text-gray-900">{formatPrice(cartTotal())}</span>
                </div>
                <div className="flex justify-between text-sm text-gray-600 font-medium">
                  <span>ডেলিভারি চার্জ</span>
                  <span className="font-bold text-gray-900">{formatPrice(deliveryCharge)}</span>
                </div>
                <div className="h-px bg-gray-100 my-4" />
                <div className="flex justify-between text-lg font-extrabold text-gray-900">
                  <span>মোট</span>
                  <span>{formatPrice(total)}</span>
                </div>
              </div>

              <Link to="/checkout" className="w-full py-4 text-primary-900 bg-accent rounded-xl hover:bg-accent-hover font-black transition-all shadow-md hover:shadow-lg transform active:scale-[0.98] flex items-center justify-center gap-2 mt-8">
                চেকআউট করুন <ArrowRight className="w-5 h-5"/>
              </Link>

              <div className="mt-4 text-center">
                <Link to="/products" className="text-sm font-bold text-primary-700 hover:text-primary-800 transition-colors">
                  বা আরও কেনাকাটা করুন
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
