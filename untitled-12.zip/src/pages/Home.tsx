import { useState, useEffect } from 'react';
import { ArrowRight, Star, Truck, ShieldCheck, Leaf, PhoneCall, Package, HeadphonesIcon, LayoutDashboard, RefreshCcw, Zap } from 'lucide-react';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { subscribeToProducts, subscribeToSiteImages, getSettings, subscribeToCategories, subscribeToBrands } from '../lib/api';
import Layout from '../layouts/Layout';
import ProductCard from '../components/ProductCard';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay, EffectFade } from 'swiper/modules';
import { motion } from 'motion/react';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/effect-fade';

export default function Home() {
  const [products, setProducts] = useState<any[]>([]);
  const [siteImages, setSiteImages] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>(null);
  const [categories, setCategories] = useState<any[]>([]);
  const [brands, setBrands] = useState<any[]>([]);
  const [searchParams, setSearchParams] = useSearchParams();
  const [timeLeft, setTimeLeft] = useState({ h: 12, m: 34, s: 56 });
  const navigate = useNavigate();
  const [visibleProductsCount, setVisibleProductsCount] = useState(10); // Load more state

  useEffect(() => {
    const unsubProducts = subscribeToProducts(setProducts);
    const unsubImages = subscribeToSiteImages(setSiteImages);
    const unsubCats = subscribeToCategories(setCategories);
    const unsubBrands = subscribeToBrands(setBrands);
    getSettings().then(setSettings);

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.s > 0) return { ...prev, s: prev.s - 1 };
        if (prev.m > 0) return { ...prev, m: 59, s: 59, h: prev.h };
        if (prev.h > 0) return { h: prev.h - 1, m: 59, s: 59 };
        return { h: 24, m: 0, s: 0 };
      });
    }, 1000);

    return () => {
      unsubProducts();
      unsubImages();
      unsubCats();
      unsubBrands();
      clearInterval(timer);
    };
  }, []);

  const heroBanners = siteImages.filter(img => !img.type || img.type === 'hero' || img.section === 'hero' || img.type === 'slider');

  const filteredProducts = products.filter(p => searchParams.get('homeCategory') ? p.category === searchParams.get('homeCategory') : true);
  const displayProducts = filteredProducts.slice(0, visibleProductsCount);
  
  const hasFlashDeals = products.filter(p => p.isHotDeal || (p.originalPrice && p.originalPrice > p.price)).length > 0;

  return (
    <Layout>
      {/* 1. HERO SECTION */}
      <section className="bg-white pt-4 pb-4 md:pb-6 lg:py-6">
        <div className="px-4 mx-auto max-w-[1440px] sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-6">
            {/* Slider Main */}
            <div className="flex-1 min-w-0">
              {heroBanners.length > 0 && (
                <Swiper
                  modules={[Navigation, Pagination, Autoplay, EffectFade]}
                  effect="fade"
                  navigation
                  pagination={{ clickable: true, dynamicBullets: true }}
                  autoplay={{ delay: 6000 }}
                  loop={heroBanners.length > 1}
                  className="h-[250px] sm:h-[400px] lg:h-[500px] rounded-[2rem] shadow-[0_20px_50px_-10px_rgba(0,0,0,0.15)] overflow-hidden"
                >
                  {heroBanners.map((banner, index) => (
                    <SwiperSlide key={index}>
                      <div className="relative w-full h-full overflow-hidden block cursor-pointer bg-gray-100" onClick={() => {
        if (banner.link || banner.targetUrl) {
           window.location.href = banner.link || banner.targetUrl;
        }
      }}>
                        <img src={banner.url} alt="Slider" className="w-full h-full object-cover" />
                      </div>
                    </SwiperSlide>
                  ))}
                </Swiper>
              )}
            </div>

            {/* Right Side: Hero Side Banner & App Link */}
            {settings?.heroSideBannerImage && (
              <aside className="hidden lg:flex flex-col w-[280px] xl:w-[320px] shrink-0 gap-6 h-[500px]">
         {settings?.heroSideBannerImage && (
           <Link to={settings.heroSideBannerUrl || '/products'} className="relative w-full flex-1 rounded-[2rem] overflow-hidden group shadow-lg border border-primary-100 flex-shrink-0 min-h-0 bg-gray-100">
              <img src={settings.heroSideBannerImage} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" alt="Special Banner" />
           </Link>
         )}
         
               {/* App Download Promo */}
         <div className="bg-gradient-to-br from-[#024430] to-[#012a1e] rounded-[2rem] p-6 text-center border border-emerald-900/50 flex flex-col items-center justify-center relative overflow-hidden group shrink-0 shadow-lg h-[210px]">
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-emerald-500/20 rounded-full blur-2xl group-hover:scale-150 transition-all duration-700"></div>
            <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl group-hover:scale-150 transition-all duration-700"></div>
            
            <h4 className="font-black text-white text-md tracking-tight z-10">খোলস শপ অ্যাপ ব্যবহার করুন</h4>
            <p className="text-[9px] font-black uppercase tracking-widest text-amber-400 mt-1.5 z-10 animate-pulse">Official Android App</p>
            <p className="text-gray-300 text-[11px] mt-2 font-bold leading-normal max-w-[210px] z-10">সহজে অর্ডার করুন এবং নিয়মিত আকর্ষণীয় ডিসকাউন্ট উপভোগ করুন!</p>
            
            <a 
              href="https://play.google.com/store/apps/details?id=com.kholosshop.app" 
              target="_blank" 
              rel="noopener noreferrer"
              className="mt-3.5 z-10 inline-flex items-center gap-2 px-5 py-2.5 bg-amber-500 hover:bg-white text-[#012a1e] hover:text-[#012a1e] font-black text-[9px] uppercase tracking-widest rounded-xl active:scale-95 transition-all shadow-md hover:shadow-amber-500/20 duration-300"
            >
               অ্যাপটি ডাউনলোড করুন <span className="text-xs">📥</span>
            </a>
         </div>
       </aside>
            )}
          </div>

          {/* Trust Features Bar (Hidden on Mobile) */}
          <div className="hidden md:grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 pt-6">
             {[
               { icon: Truck, title: 'বিশ্বস্ত ডেলিভারি', sub: 'সারা বাংলাদেশে দ্রুত ও নিরাপদ ডেলিভারি সার্ভিস।', color: 'text-primary-600', bg: 'bg-primary-50 border-primary-100', iconBg: 'bg-white text-primary-600 shadow-sm' },
               { icon: ShieldCheck, title: '১০০% পিউর পণ্য', sub: 'সরাসরি প্রাকৃতিক উৎস থেকে সংগৃহীত।', color: 'text-emerald-600', bg: 'bg-emerald-50 border-emerald-100', iconBg: 'bg-white text-emerald-600 shadow-sm' },
               { icon: HeadphonesIcon, title: 'সার্বক্ষণিক সাপোর্ট', sub: 'সাপোর্ট টিম আপনার পাশেই আছে।', color: 'text-amber-600', bg: 'bg-amber-50 border-amber-100', iconBg: 'bg-white text-amber-600 shadow-sm' },
               { icon: RefreshCcw, title: 'সহজ রিটার্ন', sub: 'দ্রুত রিটার্ন ও রিফান্ড সুবিধা।', color: 'text-red-500', bg: 'bg-red-50 border-red-100', iconBg: 'bg-white text-red-500 shadow-sm' },
             ].map((feature, i) => (
               <div key={i} className={`flex items-center gap-4 group cursor-default p-4 lg:p-5 rounded-2xl md:rounded-[2rem] transition-all border ${feature.bg} hover:shadow-md hover:-translate-y-1`}>
                  <div className={`w-10 h-10 lg:w-12 lg:h-12 rounded-full ${feature.iconBg} flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform duration-300`}>
                     <feature.icon className="w-4 h-4 lg:w-5 lg:h-5" strokeWidth={2.5} />
                  </div>
                  <div>
                     <h4 className="text-xs lg:text-sm font-black text-gray-900 tracking-tight leading-none mb-1.5">{feature.title}</h4>
                     <p className={`text-[8px] lg:text-[9px] font-bold uppercase tracking-wider ${feature.color}`}>{feature.sub}</p>
                  </div>
               </div>
             ))}
          </div>
        </div>
      </section>

      {/* 2. 3 Promo Banners */}
      {(settings?.promoBanner1Image || settings?.promoBanner2Image || settings?.promoBanner3Image) && (
        <section className="py-6 bg-white relative overflow-hidden">
          <div className="px-4 mx-auto max-w-[1440px] sm:px-6 lg:px-8 relative z-10">
             <div className="grid grid-cols-3 gap-2 sm:gap-4 lg:gap-6">
                {[1, 2, 3].map(num => {
                   const img = settings?.[('promoBanner' + num + 'Image') as keyof typeof settings];
                   const url = settings?.[('promoBanner' + num + 'Url') as keyof typeof settings];
                   if (!img) return null;
                   return (
                     <Link key={num} to={(url as string) || '/products'} className="block relative w-full h-[80px] sm:h-[120px] md:h-[200px] rounded-xl md:rounded-[2rem] overflow-hidden group shadow-md md:shadow-lg bg-gray-100">
                        <img src={img as string} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" />
                     </Link>
                   )
                })}
             </div>
          </div>
        </section>
      )}

      {/* 3. Flash Deals */}
      {settings?.flashSaleActive !== false && hasFlashDeals && (
        <section className="py-6 md:py-8 bg-primary-950 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_20%,rgba(251,191,36,0.08),transparent_50%)]"></div>
          <div className="px-4 mx-auto max-w-[1440px] sm:px-6 lg:px-8 relative z-10">
            <div className="flex flex-col lg:flex-row items-center lg:items-end justify-between mb-4 gap-4 text-center lg:text-left">
              <div className="w-full lg:w-1/2">
                <motion.div 
                   initial={{ opacity: 0, y: 30 }}
                   whileInView={{ opacity: 1, y: 0 }}
                   viewport={{ once: true }}
                   className="flex flex-col items-center lg:items-start"
                >
                  <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-accent text-primary-950 rounded-full mb-3 shadow-xl animate-pulse">
                     <span className="flex h-1.5 w-1.5 rounded-full bg-red-600"></span>
                     <span className="text-[9px] font-black uppercase tracking-[0.2em] font-sans">Limited Time</span>
                  </div>
                  <h2 className="text-2xl md:text-4xl font-black text-white leading-none uppercase tracking-tighter italic">
                    {settings?.flashSaleTitle?.split(' ')[0] || 'ফ্ল্যাশ'} <span className="text-accent underline decoration-white/20 underline-offset-4">{settings?.flashSaleTitle?.split(' ')[1] || 'ডিলস'}</span>
                  </h2>
                </motion.div>
              </div>
              
              <div className="w-full lg:w-auto">
                 <div className="bg-white/5 backdrop-blur-md border border-white/10 p-3 lg:p-4 rounded-xl lg:rounded-[2rem] shadow-xl flex items-center justify-center gap-3">
                    <div className="flex items-center gap-1.5 lg:gap-2 text-white font-black text-xl lg:text-3xl font-mono">
                       <span className="w-8 h-8 lg:w-12 lg:h-12 flex items-center justify-center rounded-lg lg:rounded-xl bg-white/10 text-white">{timeLeft.h.toString().padStart(2, '0')}</span>
                       <span className="opacity-40 translate-y-[-2px] text-base lg:text-lg">:</span>
                       <span className="w-8 h-8 lg:w-12 lg:h-12 flex items-center justify-center rounded-lg lg:rounded-xl bg-white/10 text-white">{timeLeft.m.toString().padStart(2, '0')}</span>
                       <span className="opacity-40 translate-y-[-2px] text-base lg:text-lg">:</span>
                       <span className="w-8 h-8 lg:w-12 lg:h-12 flex items-center justify-center rounded-lg lg:rounded-xl bg-white/10 text-white">{timeLeft.s.toString().padStart(2, '0')}</span>
                    </div>
                    <div className="w-px h-8 lg:h-10 bg-white/10 mx-1 lg:mx-2"></div>
                    <Link to="/products?isHotDeal=true" className="bg-white text-primary-950 px-3 lg:px-6 py-2 lg:py-3 rounded-lg lg:rounded-xl font-black uppercase text-[9px] lg:text-[10px] tracking-widest hover:bg-accent transition-all shadow-md active:scale-95 italic whitespace-nowrap">
                       See All
                    </Link>
                 </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 lg:gap-4">
              {products.filter(p => p.isHotDeal || (p.originalPrice && p.originalPrice > p.price)).slice(0, 5).map((product, idx) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                  className="h-full"
                >
                  <div className="bg-white/5 backdrop-blur-sm p-1 rounded-[1.5rem] lg:rounded-[2rem] shadow-xl group hover:-translate-y-1 transition-all h-full border border-white/5 hover:border-accent/40">
                    <ProductCard product={product} />
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* 4. Categories */}
      {categories.length > 0 && (
         <section className="py-6 md:py-8 bg-gray-50/50">
           <div className="px-4 mx-auto max-w-[1440px] sm:px-6 lg:px-8">
              <div className="flex items-center justify-between mb-4 gap-4">
                 <h2 className="text-xl md:text-3xl font-bold text-gray-900">
                   জনপ্রিয় <span className="text-primary-600">ক্যাটাগরি</span>
                 </h2>
                 <Link to="/products" className="text-primary-600 font-bold text-[10px] md:text-xs uppercase tracking-widest flex items-center gap-1 hover:text-primary-800">
                    See All <ArrowRight className="w-3 h-3 md:w-4 md:h-4" />
                 </Link>
              </div>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3 md:gap-4">
                 {categories.slice(0,8).map((cat, idx) => (
                    <Link key={idx} to={`/category/${cat.name}`} className="flex flex-col items-center gap-2 p-2.5 md:p-3 bg-white rounded-2xl shadow-sm hover:shadow-md transition-all border border-gray-100 hover:border-primary-100 group">
                       <div className="w-14 h-14 sm:w-20 sm:h-20 rounded-xl overflow-hidden bg-gray-50 flex items-center justify-center p-2 group-hover:scale-105 transition-transform">
                         {cat.image ? (
                            <img src={cat.image} alt={cat.name} className="w-full h-full object-cover rounded-lg" />
                         ) : (
                            <span className="text-gray-300 font-bold text-[10px] uppercase">{cat.name.slice(0,2)}</span>
                         )}
                       </div>
                       <h3 className="font-bold text-gray-900 text-[10px] md:text-xs text-center leading-tight line-clamp-2">{cat.name}</h3>
                    </Link>
                 ))}
              </div>
           </div>
         </section>
      )}

      {/* 5. Brands with Swiper automatically scrolling */}
      {brands.length > 0 && (
         <section className="py-8 md:py-12 bg-white">
           <div className="px-4 mx-auto max-w-[1440px] sm:px-6 lg:px-8">
              <div className="flex flex-col items-center mb-4">
                 <h2 className="text-xl md:text-3xl font-bold text-gray-900 text-center">
                   আমাদের <span className="text-accent underline decoration-accent/30 underline-offset-4">ব্র্যান্ডসমূহ</span>
                 </h2>
              </div>
              <div className="w-full">
                 <Swiper
                    modules={[Autoplay]}
                    spaceBetween={16}
                    slidesPerView={4}
                    breakpoints={{
                      640: { slidesPerView: 5, spaceBetween: 20 },
                      768: { slidesPerView: 6, spaceBetween: 30 },
                      1024: { slidesPerView: 8, spaceBetween: 40 },
                    }}
                    autoplay={{ delay: 2500, disableOnInteraction: false }}
                    loop={brands.length >= 4}
                    className="py-4"
                 >
                    {brands.map((brand, idx) => (
                       <SwiperSlide key={idx}>
                          <Link to={`/products?brand=${encodeURIComponent(brand.name)}`} className="flex flex-col items-center gap-2 group">
                             <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 rounded-full bg-white shadow-md border border-gray-100 flex items-center justify-center p-2 group-hover:scale-110 group-hover:border-accent group-hover:shadow-lg transition-all">
                                {brand.image ? (
                                   <img src={brand.image} alt={brand.name} className="w-full h-full object-contain" />
                                ) : (
                                   <span className="font-black text-gray-300 text-xl">{brand.name.charAt(0)}</span>
                                )}
                             </div>
                             <span className="text-[10px] md:text-xs font-bold text-gray-600 group-hover:text-primary-900 transition-colors uppercase text-center">{brand.name}</span>
                          </Link>
                       </SwiperSlide>
                    ))}
                 </Swiper>
              </div>
           </div>
         </section>
      )}

      {/* 6. Our Products */}
      <section id="explore-section" className="py-6 md:py-8 bg-gray-50 border-t border-gray-100">
        <div className="px-4 mx-auto max-w-[1440px] sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center md:items-end justify-between mb-4 gap-4 text-center md:text-left">
            <h2 className="text-2xl md:text-4xl font-bold text-gray-900 leading-[1.1]">
              সর্বোচ্চ বিক্রিত <br className="hidden md:block" /> <span className="text-primary-600 font-black block mt-1">পণ্যসমূহ</span>
            </h2>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 md:gap-4 lg:gap-6 mb-10">
            {displayProducts.map((product, idx) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: (idx % 5) * 0.1 }}
              >
                <div className="bg-white rounded-2xl md:rounded-[2rem] shadow-sm border border-gray-100 h-full p-1.5 md:p-2 hover:border-accent hover:shadow-xl transition-all group overflow-hidden">
                   <ProductCard product={product} />
                </div>
              </motion.div>
            ))}
          </div>

          {filteredProducts.length > visibleProductsCount && (
            <div className="flex justify-center">
               <button 
                  onClick={() => setVisibleProductsCount(prev => prev + 10)}
                  className="inline-flex items-center gap-3 bg-white border-2 border-primary-900 text-primary-950 px-8 py-3.5 rounded-xl font-black uppercase text-[10px] md:text-xs tracking-widest hover:bg-primary-900 hover:text-white transition-all shadow-sm active:scale-95"
               >
                  Load More
               </button>
            </div>
          )}
        </div>
      </section>

      {/* 7. Thin Campaign Banner (Chikon banner) */}
      {settings?.topCampaignBannerImage && (
        <section className="py-6 bg-white border-t border-gray-100">
           <div className="px-4 mx-auto max-w-[1440px] sm:px-6 lg:px-8">
              <Link to={settings.topCampaignBannerUrl || '/products'} className="block w-full overflow-hidden rounded-[1.5rem] md:rounded-[2rem] shadow-md group border border-gray-100 relative bg-gray-50 h-[100px] sm:h-[150px] md:h-auto md:max-h-[250px]">
                 <img src={settings.topCampaignBannerImage} className="w-full h-full object-cover md:object-contain lg:object-cover group-hover:scale-105 transition-transform duration-1000" />
              </Link>
           </div>
        </section>
      )}

      {/* 8. Combos (Recommended Combos) */}
      {products.filter(p => p.isCombo).length > 0 && (
        <section className="py-6 md:py-8 bg-gray-50 border-t border-gray-100 relative overflow-hidden">
          <div className="px-4 mx-auto max-w-[1440px] sm:px-6 lg:px-8 relative z-10">
            <div className="flex flex-col md:flex-row items-center md:items-end justify-between mb-4 gap-4 text-center md:text-left">
              <div className="flex flex-col items-center md:items-start">
                <h2 className="text-2xl md:text-4xl font-bold text-primary-950 leading-[1.1]">
                   সাশ্রয়ী <span className="text-primary-600 block sm:inline mt-1">কম্বো প্যাকেজ</span>
                </h2>
              </div>
              <Link to="/products?isCombo=true" className="group flex items-center gap-2 bg-primary-950 text-white px-6 py-3.5 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-black transition-all shadow-md active:scale-95 italic">
                Explore All <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
            
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 md:gap-4 lg:gap-6">
              {products.filter(p => p.isCombo).slice(0, 5).map((product, idx) => (
                   <motion.div
                     key={product.id}
                     initial={{ opacity: 0, scale: 0.95 }}
                     whileInView={{ opacity: 1, scale: 1 }}
                     viewport={{ once: true }}
                     transition={{ delay: idx * 0.1 }}
                   >
                     <div className="bg-white rounded-2xl md:rounded-[2rem] shadow-sm border border-gray-100 h-full p-1.5 md:p-2 hover:border-accent hover:shadow-xl transition-all">
                        <ProductCard product={product} />
                     </div>
                   </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* 9. Latest Blogs */}
      <section className="py-6 md:py-8 bg-white border-t border-gray-100">
        <div className="px-4 mx-auto max-w-[1440px] sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-4 gap-4">
             <h2 className="text-xl md:text-3xl font-bold text-gray-900">
               স্বাস্থ্য কথা ও <span className="text-primary-600">ব্লগ</span>
             </h2>
             <Link to="/products" className="text-primary-600 font-bold text-[10px] md:text-xs uppercase tracking-widest flex items-center gap-1 hover:text-primary-800">
                See All <ArrowRight className="w-3 h-3 md:w-4 md:h-4" />
             </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-6">
             {[
               { title: "Healthy Eating & Nutritional Wellness", img: "https://images.unsplash.com/photo-1490645935967-10de6ba17061?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80", date: "Oct 24, 2026" },
               { title: "Healthy Food Habits for Everyday Health", img: "https://images.unsplash.com/photo-1505253758473-96b7015fcd40?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80", date: "Nov 02, 2026" },
               { title: "The Ultimate Guide to Organic Living", img: "https://images.unsplash.com/photo-1493770348161-369560ae357d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80", date: "Dec 12, 2026" }
             ].map((blog, idx) => (
                <div key={idx} className="bg-gray-50 rounded-[1rem] md:rounded-[1.5rem] overflow-hidden group border border-gray-100 hover:border-accent hover:shadow-md transition-all cursor-pointer">
                   <div className="h-28 sm:h-40 overflow-hidden relative">
                      <img src={blog.img} alt={blog.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                      <div className="absolute top-2 left-2 md:top-3 md:left-3 bg-white/90 backdrop-blur-sm px-2 py-1 md:px-3 md:py-1.5 rounded-md text-[8px] md:text-[9px] font-black uppercase tracking-widest text-primary-950 shadow-sm">
                         {blog.date}
                      </div>
                   </div>
                   <div className="p-3 md:p-5">
                      <h3 className="text-[11px] md:text-[14px] font-black text-gray-900 mb-1.5 md:mb-3 group-hover:text-primary-700 leading-tight line-clamp-2 md:line-clamp-none">{blog.title}</h3>
                      <div className="hidden md:flex items-center gap-1.5 text-primary-600 font-bold text-[9px] uppercase tracking-widest group-hover:translate-x-1.5 transition-transform">
                         Read More <ArrowRight className="w-3 h-3" />
                      </div>
                   </div>
                </div>
             ))}
          </div>
        </div>
      </section>

    </Layout>
  );
}
