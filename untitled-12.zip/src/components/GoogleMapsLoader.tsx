import React from 'react';
import { APIProvider } from '@vis.gl/react-google-maps';

export const GOOGLE_MAPS_API_KEY =
  (typeof process !== 'undefined' ? process.env?.GOOGLE_MAPS_PLATFORM_KEY : '') ||
  (import.meta as any).env?.VITE_GOOGLE_MAPS_PLATFORM_KEY ||
  (globalThis as any).GOOGLE_MAPS_PLATFORM_KEY ||
  '';

export const hasValidMapsKey = Boolean(GOOGLE_MAPS_API_KEY) && GOOGLE_MAPS_API_KEY !== 'YOUR_API_KEY';

export default function GoogleMapsLoader({ children }: { children: React.ReactNode }) {
  if (!hasValidMapsKey) {
    return <>{children}</>;
  }

  return (
    <APIProvider apiKey={GOOGLE_MAPS_API_KEY} version="weekly">
      {children}
    </APIProvider>
  );
}

export function MapsKeyRequiredSplash() {
  return (
    <div className="flex items-center justify-center min-h-[400px] bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200 p-8 text-center">
      <div className="max-w-md">
        <h2 className="text-xl font-black text-gray-900 mb-4 uppercase">Google Maps API Key Required</h2>
        <p className="text-sm text-gray-500 mb-6 font-medium">To enable automatic location detection and maps, please add your Google Maps API key.</p>
        <div className="text-left space-y-4 bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <p className="text-xs font-bold text-gray-400 uppercase tracking-widest leading-none">Setup Instructions:</p>
          <ol className="text-xs font-bold text-gray-600 space-y-3 list-decimal pl-4">
            <li>Get an API key: <a href="https://console.cloud.google.com/google/maps-apis/start" target="_blank" rel="noopener" className="text-primary-600 underline">Maps Console</a></li>
            <li>Open <strong>Settings</strong> (⚙️ icon) → <strong>Secrets</strong></li>
            <li>Add <code>GOOGLE_MAPS_PLATFORM_KEY</code> as name</li>
            <li>Paste your key as value and press Enter</li>
          </ol>
        </div>
      </div>
    </div>
  );
}
