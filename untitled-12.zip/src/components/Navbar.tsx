import { useState, useEffect, useRef } from 'react';
import { ShoppingCart, Menu, Search, User, PhoneCall, MessageCircle, LayoutDashboard, Truck, ArrowRight, Leaf, Heart } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import { auth } from '../lib/firebase';
import { subscribeToProducts, subscribeToSettings } from '../lib/api';
import Fuse from 'fuse.js';
import { motion, AnimatePresence } from 'motion/react';

const ADMIN_EMAILS = ['mdjaberboss2@gmail.com', 'admin@example.com', 'admin@kholosshop.com', 'nmd032984@gmail.com'];

export default function Navbar({ onMenuClick }: { onMenuClick?: () => void }) {
  const [settings, setSettings] = useState<any>(null);
  const cart = useStore((state) => state.cart);
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);
  const [user, setUser] = useState(auth.currentUser);
  const isTempAdmin = localStorage.getItem('isTempAdmin') === 'true';
  const isUserAdmin = (user?.email && ADMIN_EMAILS.includes(user.email.toLowerCase())) || isTempAdmin;

  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [products, setProducts] = useState<any[]>([]);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [showResults, setShowResults] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const unsubscribeAuth = auth.onAuthStateChanged((u) => setUser(u));
    const unsubProducts = subscribeToProducts(setProducts);
    const unsubSettings = subscribeToSettings(setSettings);

    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowResults(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      unsubscribeAuth();
      unsubProducts();
      unsubSettings();
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  useEffect(() => {
    const handler = setTimeout(() => {
      if (searchQuery.trim().length > 1 && products.length > 0) {
        const fuse = new Fuse(products, {
          keys: ['name', 'category'],
          threshold: 0.4,
        });
        const results = fuse.search(searchQuery).slice(0, 6).map(r => r.item);
        setSearchResults(results);
        setShowResults(true);
      } else {
        setSearchResults([]);
        setShowResults(false);
      }
    }, 200);

    return () => clearTimeout(handler);
  }, [searchQuery, products]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/products?q=${encodeURIComponent(searchQuery.trim())}`);
      setSearchQuery('');
      setShowResults(false);
    }
  };

  return (
    <>
      {/* Top Notification Bar (Optional) */}
      

      <header className="sticky top-0 z-50 w-full bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        <div className="px-4 mx-auto max-w-[1440px] sm:px-6 lg:px-8">
          <div className="flex items-center justify-between lg:justify-start h-20 md:h-24 lg:h-[110px] gap-4 lg:gap-10">
            
            {/* 1. Hamburger (Mobile Only) */}
            <div className="lg:hidden w-12 flex items-center">
              <button 
                onClick={onMenuClick}
                className="p-2.5 text-primary-950 hover:bg-gray-100 rounded-2xl transition-all"
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>

            {/* 2. Logo */}
            <div className="flex-1 lg:flex-none flex justify-center lg:justify-start">
              <Link to="/" className="flex items-center gap-2 sm:gap-3 group">
                 <div className="w-9 h-9 sm:w-[50px] sm:h-[50px] bg-primary-900 rounded-xl sm:rounded-2xl flex items-center justify-center text-white shadow-xl rotate-[-5deg] group-hover:rotate-0 transition-transform shrink-0">
                    <Leaf className="w-5 h-5 sm:w-6 sm:h-6" />
                 </div>
                 <div className="flex flex-col text-left">
                    <span className="text-lg sm:text-2xl font-black text-primary-950 uppercase tracking-tighter italic leading-none">
                       Kholos<span className="text-primary-500">Shop</span>
                    </span>
                    <span className="text-[6px] sm:text-[8px] font-black text-gray-400 uppercase tracking-widest pl-0.5 mt-1 opacity-70">Pure Organic Goodness</span>
                 </div>
              </Link>
            </div>

            {/* 3. Search (Desktop Only) */}
            <div className="hidden lg:flex flex-1 max-w-2xl relative group" ref={searchRef}>
               <form onSubmit={handleSearch} className="w-full relative shadow-sm border-2 border-gray-50 focus-within:border-primary-100 rounded-3xl overflow-hidden transition-all bg-gray-50/50">
                  <input 
                     type="text" 
                     value={searchQuery}
                     onChange={(e) => setSearchQuery(e.target.value)}
                     onFocus={() => searchQuery.length > 1 && setShowResults(true)}
                     placeholder="খুঁজুন আপনার পছন্দের পণ্য..." 
                     className="w-full pl-8 pr-32 py-5 bg-transparent focus:outline-none font-bold text-sm"
                  />
                  <button type="submit" className="absolute right-2 top-2 bottom-2 px-8 bg-primary-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-black transition-all">
                     <Search className="w-4 h-4" />
                  </button>
               </form>

               <AnimatePresence>
                 {showResults && searchResults.length > 0 && (
                   <motion.div 
                     initial={{ opacity: 0, y: 10 }}
                     animate={{ opacity: 1, y: 0 }}
                     exit={{ opacity: 0, y: 10 }}
                     className="absolute top-full left-0 right-0 mt-4 bg-white rounded-[2rem] shadow-2xl border border-gray-100 overflow-hidden p-3 z-50"
                   >
                     {searchResults.map((product) => (
                       <Link
                         key={product.id}
                         to={`/product/${product.id}`}
                         onClick={() => { setSearchQuery(''); setShowResults(false); }}
                         className="flex items-center gap-4 p-3 hover:bg-primary-50 rounded-2xl transition-all"
                       >
                         <img src={product.image} alt="" className="w-12 h-12 rounded-xl object-cover bg-gray-50" />
                         <div className="flex-1">
                            <h4 className="text-xs font-black uppercase italic tracking-tight text-primary-950">{product.name}</h4>
                            <p className="text-xs font-bold text-primary-500">৳{product.price}</p>
                         </div>
                         <ArrowRight className="w-4 h-4 text-gray-300" />
                       </Link>
                     ))}
                   </motion.div>
                 )}
               </AnimatePresence>
            </div>

            {/* 4. Contact/Call & WhatsApp (Tablet/Desktop) */}
            <div className="hidden xl:flex items-center gap-4">
               {settings?.whatsappNumber && (
                 <a href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}`} target="_blank" rel="noreferrer" className="flex items-center gap-3 bg-green-50 px-5 py-3 rounded-[1.5rem] border border-green-100 group">
                    <div className="w-10 h-10 bg-green-500 text-white rounded-xl flex items-center justify-center p-2 shadow-lg shadow-green-500/20 group-hover:rotate-12 transition-transform">
                       <MessageCircle className="w-5 h-5" />
                    </div>
                    <div className="flex flex-col">
                       <span className="text-[9px] font-black text-green-700 uppercase tracking-widest mb-0.5 opacity-70">WhatsApp</span>
                       <span className="text-sm font-black text-green-950 tracking-tighter">{settings.whatsappNumber}</span>
                    </div>
                 </a>
               )}
               <a href={`tel:${settings?.phone || '০১৮৭৮-১৪৫৫৫৯'}`} className="flex items-center gap-3 bg-gray-50 px-5 py-3 rounded-[1.5rem] border border-gray-100 group">
                  <div className="w-10 h-10 bg-primary-600 text-white rounded-xl flex items-center justify-center p-2 shadow-lg shadow-primary-600/20 group-hover:rotate-12 transition-transform">
                     <PhoneCall className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col">
                     <span className="text-[9px] font-black text-primary-600 uppercase tracking-widest mb-0.5 opacity-70">Order Now</span>
                     <span className="text-sm font-black text-primary-950 tracking-tighter">{settings?.phone || '০১৮৭৮-১৪৫৫৫৯'}</span>
                  </div>
               </a>
            </div>

            {/* 5. User Tools (Desktop Only) */}
            <div className="hidden lg:flex items-center gap-3">
               {isUserAdmin && (
                 <Link to="/admin" className="p-4 bg-red-500 text-white rounded-2xl shadow-lg border border-red-600 active:scale-95 transition-all">
                    <LayoutDashboard className="w-6 h-6" />
                 </Link>
               )}
               <Link to="/track" className="hidden lg:flex p-4 bg-gray-50 text-gray-400 hover:text-primary-600 rounded-2xl shadow-sm border border-gray-100 hover:border-primary-100 active:scale-95 transition-all group">
         <Truck className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
       </Link>
       <Link to="/cart" className="flex items-center gap-4 bg-accent p-4 pl-6 pr-8 rounded-[1.5rem] shadow-xl shadow-accent/20 active:scale-95 transition-all group">
                  <div className="relative">
                     <ShoppingCart className="w-7 h-7 text-primary-950 group-hover:rotate-6 transition-transform" />
                     {cartCount > 0 && (
                        <span className="absolute -top-3 -right-3 w-6 h-6 bg-primary-900 text-white text-[10px] font-black flex items-center justify-center rounded-full border-2 border-accent">
                           {cartCount}
                        </span>
                     )}
                  </div>
                  <div className="flex flex-col leading-none">
                     <span className="text-[8px] font-black uppercase text-primary-900 tracking-widest opacity-60 mb-1">My Cart</span>
                     <span className="text-xl font-black italic tracking-tighter text-primary-950">৳{useStore(state => state.cartTotal()).toLocaleString()}</span>
                  </div>
               </Link>
            </div>

            {/* 6. Cart Icon (Mobile Only) */}
            <div className="lg:hidden flex items-center justify-end gap-3">
               {isUserAdmin && (
                 <Link to="/admin" className="p-2 bg-red-500 text-white rounded-xl shadow-lg border border-red-600 active:scale-95 transition-all">
                    <LayoutDashboard className="w-5 h-5" />
                 </Link>
               )}
               <Link to="/cart" className="relative p-2.5 bg-accent text-primary-950 rounded-2xl shadow-xl shadow-accent/20 block active:scale-90 transition-all">
                  <ShoppingCart className="w-5.5 h-5.5" />
                  {cartCount > 0 && (
                     <span className="absolute -top-1 -right-1 w-5 h-5 bg-primary-900 text-white text-[9px] font-black flex items-center justify-center rounded-full border border-accent">
                        {cartCount}
                     </span>
                  )}
               </Link>
            </div>

          </div>
        </div>

        {/* 7. Mobile Search Bar (Mobile Only) */}
        <div className="lg:hidden px-4 pb-4">
           <form onSubmit={handleSearch} className="w-full relative bg-gray-100 rounded-2xl border border-gray-200 focus-within:border-primary-300 transition-colors">
              <input 
                 type="text" 
                 value={searchQuery}
                 onChange={(e) => setSearchQuery(e.target.value)}
                 placeholder="খুঁজুন আপনার পছন্দের পণ্য..." 
                 className="w-full pl-6 pr-12 py-3.5 bg-transparent focus:outline-none font-bold text-xs"
              />
              <button type="submit" className="absolute right-2 top-2 bottom-2 w-10 bg-primary-900 text-white rounded-xl flex items-center justify-center">
                 <Search className="w-4 h-4" />
              </button>
           </form>
        </div>
      </header>
    </>
  );
}
