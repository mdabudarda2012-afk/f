// @ts-nocheck
import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MapPin, Phone, User, CheckCircle2, Navigation, Loader2, Save } from 'lucide-react';
import { auth } from '../lib/firebase';
import { updateUserProfile, getUserProfile } from '../lib/api';
import { hasValidMapsKey, GOOGLE_MAPS_API_KEY } from './GoogleMapsLoader';

export default function ProfileCompletionModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    phone: '',
    address: '',
    displayName: auth.currentUser?.displayName || ''
  });
  
  const autocompleteRef = useRef<any>(null);
  const inputContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const checkProfile = async () => {
      if (auth.currentUser) {
        const p = await getUserProfile(auth.currentUser.uid);
        if (!p || !p.phone || !p.address || !p.displayName) {
          if (p) {
            setFormData({
              phone: p.phone || '',
              address: p.address || '',
              displayName: p.displayName || auth.currentUser?.displayName || ''
            });
          }
          setIsOpen(true);
          // Auto detect location if address is empty
          if (!p || !p.address) {
            setTimeout(() => {
              if ("geolocation" in navigator) {
                navigator.geolocation.getCurrentPosition(async (position) => {
                  const { latitude, longitude } = position.coords;
                  try {
                    const response = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${GOOGLE_MAPS_API_KEY}`);
                    const data = await response.json();
                    if (data.results && data.results[0]) {
                      setFormData(prev => ({ ...prev, address: data.results[0].formatted_address }));
                    }
                  } catch (e) {
                    // Ignore errors on auto-detect
                  }
                });
              }
            }, 1000);
          }
        }
      }
    };

    const unsubAuth = auth.onAuthStateChanged((user) => {
      if (user) {
        checkProfile();
      } else {
        setIsOpen(false);
      }
    });

    return () => unsubAuth();
  }, []);

  useEffect(() => {
    if (isOpen && hasValidMapsKey && inputContainerRef.current && !autocompleteRef.current) {
      // Imperative initialization as per GMP skill CF8
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}&libraries=places&v=weekly`;
      script.async = true;
      script.onload = () => {
        const { PlaceAutocompleteElement } = (window as any).google.maps.places;
        if (PlaceAutocompleteElement) {
          const autocomplete = new PlaceAutocompleteElement();
          autocomplete.classList.add('w-full', 'maps-autocomplete-input');
          inputContainerRef.current?.appendChild(autocomplete);
          autocompleteRef.current = autocomplete;

          autocomplete.addEventListener('gmp-placeselect', (event: any) => {
            const place = event.detail.place;
            if (place && place.formattedAddress) {
              setFormData(prev => ({ ...prev, address: place.formattedAddress }));
            }
          });
        }
      };
      document.head.appendChild(script);
    }
  }, [isOpen]);

  const handleDismiss = () => {
    sessionStorage.setItem('profile-modal-dismissed', 'true');
    setIsOpen(false);
  };

  const handleDetectLocation = () => {
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(async (position) => {
        const { latitude, longitude } = position.coords;
        try {
          const response = await fetch(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${latitude},${longitude}&key=${GOOGLE_MAPS_API_KEY}`);
          const data = await response.json();
          if (data.results && data.results[0]) {
            setFormData(prev => ({ ...prev, address: data.results[0].formatted_address }));
          } else {
            setFormData(prev => ({ ...prev, address: `Lat: ${latitude.toFixed(4)}, Lng: ${longitude.toFixed(4)}` }));
          }
        } catch {
          setFormData(prev => ({ ...prev, address: `Lat: ${latitude.toFixed(4)}, Lng: ${longitude.toFixed(4)}` }));
        }
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    
    setIsLoading(true);
    try {
      if (!formData.address || !formData.displayName) {
         alert('অনুগ্রহ করে নাম এবং ঠিকানা প্রদান করুন।');
         setIsLoading(false);
         return;
      }
      await updateUserProfile(auth.currentUser.uid, {
        ...formData,
        email: auth.currentUser.email
      });
      setIsOpen(false);
    } catch (error) {
      console.error('Failed to update profile', error);
      alert('প্রোফাইল আপডেট করতে সমস্যা হয়েছে।');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-primary-950/40 backdrop-blur-sm"
        />
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-lg bg-white rounded-[2.5rem] shadow-2xl overflow-hidden"
        >
          <div className="p-8 md:p-12">
            <div className="text-center mb-10">
              <div className="w-16 h-16 bg-primary-50 text-primary-900 flex items-center justify-center rounded-2xl mx-auto mb-6">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h2 className="text-3xl font-black text-gray-900 mb-3 tracking-tight uppercase italic">প্রোফাইল সম্পন্ন করুন</h2>
              <p className="text-gray-500 font-medium text-sm leading-relaxed px-4">
                আপনার সঠিক তথ্য দিন যাতে আমরা দ্রুত এবং নির্ভুলভাবে পণ্য পৌঁছে দিতে পারি।
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-4 block">আপনার নাম</label>
                <div className="relative">
                  <User className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-primary-300" />
                  <input 
                    type="text" 
                    required
                    placeholder="আপনার পুরো নাম" 
                    value={formData.displayName}
                    onChange={(e) => setFormData({...formData, displayName: e.target.value})}
                    className="w-full pl-14 pr-6 py-4.5 bg-gray-50 border border-gray-100 rounded-2xl focus:outline-none focus:border-primary-500 focus:bg-white transition-all font-bold text-gray-900 text-sm"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest ml-4 block">ফোন নম্বর</label>
                <div className="relative">
                  <Phone className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-primary-300" />
                  <input 
                    type="tel" 
                    required
                    placeholder="আপনার মোবাইল নম্বর" 
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    className="w-full pl-14 pr-6 py-4.5 bg-gray-50 border border-gray-100 rounded-2xl focus:outline-none focus:border-primary-500 focus:bg-white transition-all font-bold text-gray-900 text-sm"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center ml-4 mb-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">ডেলিভারি ঠিকানা</label>
                  <button 
                    type="button" 
                    onClick={handleDetectLocation}
                    className="text-[9px] font-black text-primary-600 uppercase tracking-[0.2em] flex items-center gap-1 hover:text-primary-800 transition-colors bg-primary-50 px-3 py-1 rounded-full"
                  >
                    Auto Detect
                  </button>
                </div>
                <div className="relative">
                  <MapPin className="absolute left-5 top-[1.375rem] w-5 h-5 text-primary-300 z-10" />
                  
                  {hasValidMapsKey ? (
                    <div className="relative">
                      <div ref={inputContainerRef} className="maps-autocomplete-container" />
                      {!formData.address && (
                        <div className="absolute left-14 top-1/2 -translate-y-1/2 text-gray-400 text-sm font-bold pointer-events-none">
                          ম্যাপ থেকে ঠিকানা নির্বাচন করুন...
                        </div>
                      )}
                    </div>
                  ) : (
                    <textarea 
                      required
                      placeholder="আপনার পূর্ণাঙ্গ ঠিকানা লিখুন..." 
                      value={formData.address}
                      onChange={(e) => setFormData({...formData, address: e.target.value})}
                      className="w-full pl-14 pr-6 py-4.5 bg-gray-50 border border-gray-100 rounded-2xl focus:outline-none focus:border-primary-500 focus:bg-white transition-all font-bold text-gray-900 text-sm min-h-[100px] resize-none"
                    />
                  )}
                  
                  {hasValidMapsKey && formData.address && (
                    <div className="mt-4 p-4 bg-primary-50 rounded-xl border border-primary-100 flex items-start gap-3">
                      <Navigation className="w-4 h-4 text-primary-600 mt-1 shrink-0" />
                      <p className="text-xs font-bold text-primary-900 leading-relaxed">{formData.address}</p>
                    </div>
                  )}
                </div>
              </div>

              <button 
                type="submit" 
                disabled={isLoading}
                className="w-full bg-primary-950 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-black transition-all shadow-xl shadow-primary-900/20 flex items-center justify-center gap-3 active:scale-95 disabled:opacity-50 mt-4"
              >
                {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                {isLoading ? 'সংরক্ষণ করা হচ্ছে...' : 'প্রোফাইল আপডেট করুন'}
              </button>
              
              <button 
                type="button" 
                onClick={handleDismiss}
                className="w-full text-gray-400 font-bold uppercase tracking-widest text-[10px] hover:text-gray-900 transition-colors"
              >
                পরে করবো
              </button>
            </form>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
