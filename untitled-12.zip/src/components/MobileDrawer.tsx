
import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Home, ShoppingBag, Phone, Leaf, ChevronRight, LayoutDashboard, Truck } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { subscribeToCategories } from '../lib/api';
import { auth } from '../lib/firebase';

const ADMIN_EMAILS = ['mdjaberboss2@gmail.com', 'admin@example.com', 'admin@kholosshop.com', 'nmd032984@gmail.com'];

interface MobileDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function MobileDrawer({ isOpen, onClose }: MobileDrawerProps) {
  const location = useLocation();
  const [categories, setCategories] = useState<any[]>([]);
  const [user, setUser] = useState(auth.currentUser);
  const isTempAdmin = localStorage.getItem('isTempAdmin') === 'true';
  const isUserAdmin = (user?.email && ADMIN_EMAILS.includes(user.email.toLowerCase())) || isTempAdmin;

  useEffect(() => {
    const unsubCat = subscribeToCategories(setCategories);
    const unsubAuth = auth.onAuthStateChanged(setUser);
    return () => {
      unsubCat();
      unsubAuth();
    };
  }, []);

  const menuItems = [
    { icon: Home, label: 'হোম', path: '/' },
    { icon: ShoppingBag, label: 'সকল পণ্য', path: '/products' },
    { icon: Truck, label: 'অর্ডার ট্র্যাক', path: '/order-tracking' },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100] lg:hidden"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-y-0 left-0 w-[85%] max-w-xs bg-white z-[101] lg:hidden shadow-2xl flex flex-col"
          >
            {/* Header */}
            <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-primary-900 text-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-white/20 backdrop-blur-md rounded-xl flex items-center justify-center">
                  <Leaf className="w-6 h-6 text-white" />
                </div>
                <span className="text-xl font-black italic tracking-tight">Kholos<span className="text-primary-400">Shop</span></span>
              </div>
              <button 
                onClick={onClose}
                className="w-10 h-10 flex items-center justify-center rounded-xl bg-white/10 hover:bg-white/20 transition-colors"
                aria-label="Close menu"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto pt-6 px-4 pb-20">
              <div className="mb-8">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] mb-4 pl-4 italic">প্রধান মেনু</p>
                <div className="space-y-1">
                  {menuItems.map((item) => {
                    const isActive = location.pathname === item.path;
                    return (
                      <Link
                        key={item.path}
                        to={item.path}
                        onClick={onClose}
                        className={`flex items-center gap-4 px-6 py-4 rounded-xl transition-all font-black text-sm uppercase tracking-tight italic ${
                          isActive 
                            ? 'bg-primary-900 text-white shadow-lg' 
                            : 'text-gray-600 hover:bg-gray-50'
                        }`}
                      >
                        <item.icon className={`w-5 h-5 ${isActive ? 'text-primary-400' : 'text-gray-400'}`} />
                        {item.label}
                      </Link>
                    );
                  })}
                  {isUserAdmin && (
                    <Link
                      to="/admin"
                      onClick={onClose}
                      className="flex items-center gap-4 px-6 py-4 rounded-xl text-red-600 hover:bg-red-50 transition-all font-black text-sm uppercase tracking-tight italic"
                    >
                      <LayoutDashboard className="w-5 h-5" />
                      অ্যাডমিন প্যানেল
                    </Link>
                  )}
                </div>
              </div>

              <div className="mb-8">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] mb-4 pl-4 italic">ক্যাটাগরি সমূহ</p>
                <div className="space-y-1">
                  {categories.map((cat) => (
                    <Link
                      key={cat.id}
                      to={`/category/${cat.name}`}
                      onClick={onClose}
                      className={`flex items-center justify-between px-6 py-4 rounded-xl transition-all font-bold text-sm text-gray-600 hover:bg-gray-50 hover:text-primary-700`}
                    >
                      <span className="flex items-center gap-4">
                        <div className="w-8 h-8 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                          <img src={cat.image || 'https://images.unsplash.com/photo-1587049352847-81a56d773c1c?w=100'} alt="" className="w-full h-full object-cover" />
                        </div>
                        {cat.name}
                      </span>
                      <ChevronRight className="w-4 h-4 text-gray-300" />
                    </Link>
                  ))}
                </div>
              </div>

              {/* Contact Info */}
              <div className="mt-8 pt-8 border-t border-gray-100">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] mb-4 pl-4 italic">সাহায্য দরকার?</p>
                <a href="tel:01878145559" className="flex items-center gap-4 px-6 py-5 bg-gray-50 rounded-2xl group active:scale-95 transition-transform">
                  <div className="w-10 h-10 bg-primary-100 text-primary-900 rounded-xl flex items-center justify-center">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black text-primary-600 uppercase tracking-widest leading-none mb-1">Call Us Now</span>
                    <span className="text-lg font-black text-primary-950 tracking-tighter text-nowrap">০১৮৭৮-১৪৫৫৫৫৯</span>
                  </div>
                </a>
              </div>
            </div>

            {/* Footer shadow fade */}
            <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-white to-transparent pointer-events-none"></div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
