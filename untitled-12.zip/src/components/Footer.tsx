import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { getSettings } from '../lib/api';

export default function Footer() {
  const [settings, setSettings] = useState<any>({});

  useEffect(() => {
    getSettings().then(setSettings);
  }, []);

  return (
    <footer className="bg-primary-950 text-white pt-16 pb-8 border-t-[8px] border-accent relative overflow-hidden">
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 bg-primary-800 rounded-full blur-3xl opacity-20"></div>
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-64 h-64 bg-accent rounded-full blur-3xl opacity-10"></div>
      
      <div className="px-4 mx-auto max-w-[1440px] sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-2 gap-x-6 gap-y-10 md:grid-cols-3 lg:grid-cols-12 mb-16">
          <div className="col-span-2 md:col-span-3 lg:col-span-4 pr-4 border-b border-primary-800/30 pb-10 lg:border-none lg:pb-0">
            <Link to="/" className="flex items-center gap-3 mb-6 group inline-flex">
              <div className="flex items-center justify-center w-10 h-10 text-primary-900 bg-accent rounded-xl shadow-lg group-hover:scale-105 transition-transform duration-300">
                <span className="font-extrabold text-xl">{settings?.siteName ? settings.siteName[0].toUpperCase() : 'K'}</span>
              </div>
              <span className="text-2xl font-black tracking-tight text-white">{settings?.siteName || 'Kholos'}</span>
            </Link>
            <p className="text-sm text-primary-200/80 mb-8 leading-relaxed max-w-sm">
              Bangladesh's best online shopping destination. We are committed to delivering authentic and quality products.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-primary-800/50 flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-primary-400 uppercase tracking-wider mb-1">Office Address</h4>
                  <p className="text-sm text-primary-100">{settings?.address || 'Dhaka, Bangladesh'}</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-primary-800/50 flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-primary-400 uppercase tracking-wider mb-1">Phone</h4>
                  <p className="text-sm text-primary-100">{settings?.phone || '+8801887814559'}</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-primary-800/50 flex items-center justify-center flex-shrink-0 mt-1">
                  <svg className="w-4 h-4 text-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                </div>
                <div>
                  <h4 className="text-xs font-bold text-primary-400 uppercase tracking-wider mb-1">Email</h4>
                  <p className="text-sm text-primary-100">{settings?.email || 'support@kholosshop.com'}</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="col-span-1 lg:col-span-2">
             <h3 className="mb-6 text-sm font-bold tracking-widest text-primary-300 uppercase">Support</h3>
             <ul className="space-y-3 text-sm text-primary-100/70">
               <li><Link to="/pages/support-center" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Support Center</Link></li>
               <li><Link to="/pages/how-to-order" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>How to Order</Link></li>
               <li><Link to="/order-tracking" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Order Tracking</Link></li>
               <li><Link to="/pages/payment" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Payment API</Link></li>
               <li><Link to="/pages/shipping" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Shipping Info</Link></li>
               <li><Link to="/pages/faq" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>FAQs</Link></li>
             </ul>
          </div>
          
          <div className="col-span-1 lg:col-span-2">
             <h3 className="mb-6 text-sm font-bold tracking-widest text-primary-300 uppercase">Consumer Policy</h3>
             <ul className="space-y-3 text-sm text-primary-100/70">
               <li><Link to="/pages/happy-return" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Happy Return</Link></li>
               <li><Link to="/pages/refund-policy" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Refund Policy</Link></li>
               <li><Link to="/pages/exchange" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Exchange Policy</Link></li>
               <li><Link to="/pages/cancellation" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Cancellation</Link></li>
               <li><Link to="/pages/pre-order" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Pre-Order Rules</Link></li>
               <li><Link to="/pages/extra-discount" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Discounts</Link></li>
             </ul>
          </div>

          <div className="col-span-1 lg:col-span-2">
            <h3 className="mb-6 text-sm font-bold tracking-widest text-primary-300 uppercase">Information</h3>
            <ul className="space-y-3 text-sm text-primary-100/70">
              <li><Link to="/pages/about-us" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>About us</Link></li>
              <li><Link to="/pages/contact-us" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Contact us</Link></li>
              <li><Link to="/reseller-registration" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Reseller Apply</Link></li>
              <li><Link to="/return-request" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Return Request</Link></li>
              <li><Link to="/pages/terms-and-conditions" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Terms & Config</Link></li>
              <li><Link to="/pages/privacy-policy" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Privacy Policy</Link></li>
              <li><Link to="/pages/careers" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Careers</Link></li>
            </ul>
          </div>

          <div className="col-span-1 lg:col-span-2">
            <h3 className="mb-6 text-sm font-bold tracking-widest text-primary-300 uppercase">Shop By</h3>
            <ul className="space-y-3 text-sm text-primary-100/70">
              <li><Link to="/products" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>All Products</Link></li>
              <li><Link to="/products?category=Honey" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Pure Honey</Link></li>
              <li><Link to="/products?category=Dates" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Ajwa Dates</Link></li>
              <li><Link to="/products?category=Oil" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Black Seed & Oil</Link></li>
              <li><Link to="/products?category=Attar" className="hover:text-accent transition-colors flex items-center gap-2"><span className="w-1.5 h-1.5 bg-primary-800 rounded-full"></span>Premium Attar</Link></li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-primary-800/50 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-primary-300/80">© {new Date().getFullYear()} {settings?.siteName || 'Kholos Shop'}. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <Link to="/dashboard" className="text-xs text-primary-900 opacity-5 hover:opacity-10 transition-opacity">Adm</Link>
            <div className="w-10 h-6 bg-white/10 rounded flex items-center justify-center text-[10px] font-bold text-white/50">VISA</div>
            <div className="w-10 h-6 bg-white/10 rounded flex items-center justify-center text-[10px] font-bold text-white/50">MC</div>
            <div className="w-10 h-6 bg-white/10 rounded flex items-center justify-center text-[10px] font-bold text-white/50">BKASH</div>
          </div>
        </div>
      </div>
    </footer>
  );
}
