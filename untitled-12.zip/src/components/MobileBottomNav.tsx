import { Home, Grid, ShoppingCart, Truck } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { useStore } from '../store';
import { motion } from 'motion/react';

export default function MobileBottomNav() {
  const location = useLocation();
  const cartCount = useStore(state => state.cart.reduce((a, c) => a + c.quantity, 0));

  const navItems = [
    { path: '/', icon: Home, label: 'হোম' },
    { path: '/products', icon: Grid, label: 'পণ্য' },
    { path: '/cart', icon: ShoppingCart, label: 'কার্ট', count: cartCount },
    { path: '/track', icon: Truck, label: 'ট্র্যাক' },
  ];

  return (
    <div className="lg:hidden fixed bottom-4 left-1/2 -translate-x-1/2 w-[95%] max-w-[500px] z-[90]">
      <div className="bg-white/80 backdrop-blur-2xl border border-white/20 shadow-[0_20px_50px_rgba(0,0,0,0.15)] rounded-[2.5rem] flex justify-around items-center h-20 px-2 relative overflow-hidden">
        {/* Sublte Glass Highlight */}
        <div className="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent pointer-events-none"></div>

        {navItems.map((item, idx) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path || (item.path === '/products' && location.pathname.includes('/products'));
          
          return (
            <Link 
              key={idx} 
              to={item.path}
              onClick={() => window.scrollTo(0, 0)} 
              className="relative flex flex-col items-center justify-center w-full h-full transition-all group pt-1"
            >
              {isActive && (
                <motion.div
                  layoutId="activeTabMobile"
                  className="absolute inset-x-2 inset-y-2 bg-primary-950 rounded-[1.5rem] z-0"
                  transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                />
              )}
              
              <div className="relative z-10 flex flex-col items-center">
                <div className="relative">
                  <Icon className={`w-5.5 h-5.5 transition-all duration-500 ${isActive ? 'text-white' : 'text-gray-400 group-hover:text-primary-700'}`} />
                  {item.count ? (
                    <span className={`absolute -top-2.5 -right-2.5 text-[8px] font-black w-5 h-5 flex items-center justify-center rounded-full border-2 shadow-sm transition-all ${
                      isActive ? 'bg-accent text-primary-950 border-primary-900' : 'bg-primary-900 text-white border-white'
                    }`}>
                      {item.count}
                    </span>
                  ) : null}
                </div>
                <span className={`text-[8px] font-black uppercase tracking-[0.1em] mt-1.5 transition-all duration-500 ${
                  isActive ? 'text-white' : 'text-gray-500 opacity-60'
                }`}>
                  {item.label}
                </span>
              </div>
            </Link>
          )
        })}
      </div>
    </div>
  );
}
