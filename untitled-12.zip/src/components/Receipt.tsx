import { CheckCircle2, Calendar, MapPin, Phone, User, ShoppingBag, ArrowRight, Printer, Leaf } from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';

interface ReceiptProps {
  order: any;
  hideActions?: boolean;
}

export default function Receipt({ order, hideActions }: ReceiptProps) {
  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  const formattedDate = new Date(order.createdAt).toLocaleDateString('bn-BD', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  return (
    <div id="printable-receipt" className="bg-white rounded-3xl overflow-hidden shadow-[0_10px_50px_rgba(0,0,0,0.04)] border border-gray-100 w-full mx-auto print:shadow-none print:border-none print:my-0 print:p-0">
      
      {/* Visual Success Header */}
      <div className="bg-primary-950 p-8 sm:p-12 text-white text-center relative overflow-hidden print:bg-white print:text-black print:border-b print:border-gray-200 print:py-6">
        <div className="absolute inset-0 opacity-5 print:hidden">
          <div className="absolute top-[-50%] left-[-20%] w-[100%] h-[200%] bg-white/20 rotate-12 blur-3xl animate-pulse" />
        </div>
        
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-16 h-16 bg-white/10 backdrop-blur-md rounded-2xl flex items-center justify-center mx-auto mb-4 relative z-10 print:hidden"
        >
          <CheckCircle2 className="w-8 h-8 text-primary-400" strokeWidth={2.5} />
        </motion.div>
        
        <h1 className="text-2xl sm:text-4xl font-black  tracking-tighter leading-tight relative z-10 print:text-black">
          Kholos<span className="text-primary-400 print:text-black">Shop</span>
        </h1>
        <p className="text-primary-200 text-xs font-bold  mt-1 relative z-10 print:text-gray-500">
          Pure Organic Goodness
        </p>
        
        <div className="mt-4 bg-primary-900/40 border border-primary-800/40 inline-flex items-center px-4 py-1.5 rounded-full text-xs text-primary-300 font-bold tracking-wider relative z-10 print:hidden">
          অর্ডারটি সফলভাবে গ্রহণ করা হয়েছে (Order Confirmed!)
        </div>
      </div>

      {/* Main Body */}
      <div className="p-6 sm:p-10 space-y-8">
        
        {/* Receipt Slip Layout */}
        <div className="border-4 border-dashed border-gray-100 rounded-3xl p-6 sm:p-8 bg-gray-50/50 space-y-8 print:border-none print:p-0 print:bg-transparent">
          
          {/* Top Bar with IDs & Metas */}
          <div className="flex flex-col sm:flex-row justify-between gap-4 border-b border-gray-100 pb-6">
            <div className="space-y-1">
              <span className="text-[10px] font-bold text-gray-500 text-[11px] block">অর্ডার আইডি # (Order ID)</span>
              <div className="flex items-center gap-2">
                <p className="font-mono text-base font-black text-gray-900 uppercase">#{order.shortId || order.id?.slice(-8).toUpperCase()}</p>
              </div>
            </div>
            <div className="space-y-1 sm:text-right">
              <span className="text-[10px] font-bold text-gray-500 text-[11px] block">অর্ডার তারিখ (Date)</span>
              <div className="flex items-center sm:justify-end gap-2 text-gray-900 font-bold">
                 <Calendar className="w-3.5 h-3.5 text-gray-400" />
                 <p className="text-sm font-black">{formattedDate} ({new Date(order.createdAt).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' })})</p>
              </div>
            </div>
          </div>

          {/* Delivery Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
            
            {/* Customer Info */}
            <div className="space-y-4">
              <h3 className="text-xs font-bold text-gray-800 text-[13px] flex items-center gap-2 border-b border-gray-100 pb-2">
                <User className="w-4 h-4 text-primary-600" />
                ক্রেতার বিবরণ (Customer Information)
              </h3>
              
              <div className="space-y-3 text-sm">
                <div className="flex items-start gap-3">
                  <span className="w-24 text-gray-400 font-bold">নাম (Name):</span>
                  <span className="font-black text-gray-900">{order.customerName}</span>
                </div>
                <div className="flex items-start gap-3">
                  <span className="w-24 text-gray-400 font-bold">মোবাইল (Phone):</span>
                  <span className="font-bold text-gray-900 font-mono">{order.customerPhone}</span>
                </div>
              </div>
            </div>

            {/* Delivery address */}
            <div className="space-y-4 font-sans">
              <h3 className="text-xs font-bold text-gray-800 text-[13px] flex items-center gap-2 border-b border-gray-100 pb-2">
                <MapPin className="w-4 h-4 text-primary-600" />
                ডেলিভারি ঠিকানা (Shipping Address)
              </h3>
              
              <div className="space-y-1">
                <p className="font-bold text-gray-800 leading-relaxed text-sm bg-white p-3 border border-gray-100 rounded-xl shadow-xs print:border-none print:p-0">
                  {order.customerAddress}
                </p>
              </div>
            </div>
          </div>

          {/* Product list */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold text-gray-800 text-[13px] flex items-center gap-2 border-b border-gray-100 pb-2">
              <ShoppingBag className="w-4 h-4 text-primary-600" />
              পণ্যসমূহ (Items Ordered)
            </h3>
            
            <div className="divide-y divide-gray-100">
              {order.items?.map((item: any, index: number) => (
                <div key={item.id || index} className="flex items-center gap-4 py-3.5 group">
                  <div className="w-12 h-12 bg-gray-100 rounded-xl overflow-hidden flex-shrink-0 border border-gray-100 flex items-center justify-center p-1 print:hidden">
                    <img src={item.image} alt={item.name} className="w-full h-full object-contain" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-black text-gray-900 text-sm line-clamp-1">{item.name}</h4>
                    <p className="text-[11px] text-gray-400 font-bold mt-1">
                      {item.quantity} × ৳{item.price} {item.unit ? `(${item.unit})` : ''}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-mono font-black text-gray-950 text-sm">৳{item.price * item.quantity}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Summary values */}
          <div className="pt-6 border-t border-gray-100 space-y-3.5">
             <div className="flex justify-between text-gray-500 text-sm font-bold">
               <span>পণ্য মূল্য (Subtotal)</span>
               <span className="font-mono">৳{order.totalAmount - (order.deliveryCharge || 0)}</span>
             </div>
             
             {order.couponCode && (
               <div className="flex justify-between text-green-600 text-sm font-bold">
                 <span>কুপন ছাড় (Coupon Discount: {order.couponCode})</span>
                 <span className="font-mono">-৳{order.discountAmount || 0}</span>
               </div>
             )}

             <div className="flex justify-between text-gray-500 text-sm font-bold">
               <span>ডেলিভারি চার্জ (Delivery Fee)</span>
               <span className="font-mono">৳{order.deliveryCharge || 0}</span>
             </div>
             
             <div className="flex justify-between items-center bg-primary-950 text-white p-5 rounded-2xl border border-primary-900 mt-4 print:bg-white print:text-black print:border print:border-black">
               <div>
                 <p className="text-[10px] font-black text-primary-300 uppercase tracking-widest mb-1 print:text-gray-500">মোট পরিশোধযোগ্য (Total Payable)</p>
                 <p className="text-xs text-primary-200/80 font-medium italic print:text-gray-400">মেথড: ক্যাশ অন ডেলিভারি (Cash on Delivery)</p>
               </div>
               <span className="text-2xl sm:text-3xl font-black font-mono tracking-tight text-white print:text-black">৳{order.totalAmount}</span>
             </div>
          </div>

        </div>

        {/* Action Buttons */}
        {!hideActions && (
          <div className="flex flex-col sm:flex-row gap-4 pt-4 print:hidden">
            <button 
              onClick={handlePrint}
              className="flex-1 bg-white border-2 border-gray-900 text-gray-900 py-4 rounded-2xl font-bold text-gray-500 text-[11px] text-xs hover:bg-gray-50 transition-all flex items-center justify-center gap-3 shadow-sm active:scale-95"
            >
              <Printer className="w-4 h-4" />
              প্রিন্ট রশিদ (Print / PDF)
            </button>
            <Link 
              to="/"
              className="flex-1 bg-primary-950 text-white py-4 rounded-2xl font-bold text-gray-500 text-[11px] text-xs hover:bg-black transition-all flex items-center justify-center gap-3 shadow-xl active:scale-95"
            >
              আরো অর্ডার করুন (Continue Shopping)
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        )}
      </div>
      
      {/* Decorative Bottom Bar */}
      <div className="bg-gray-50 p-6 text-center border-t border-gray-100 italic font-bold text-gray-400 text-xs">
        Kholos Shop থেকে কেনাকাটা করার জন্য আপনাকে ধন্যবাদ!
      </div>
    </div>
  );
}
