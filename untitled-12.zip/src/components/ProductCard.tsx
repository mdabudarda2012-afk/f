import { ShoppingCart, Star } from 'lucide-react';
import { Product, useStore } from '../store';
import { Link } from 'react-router-dom';

export default function ProductCard({ product }: { product: Product }) {
  const addToCart = useStore((state) => state.addToCart);

  const discountPercent = product.originalPrice ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100) : 0;
  
  return (
    <div className={`bg-white text-center rounded-[1.5rem] sm:rounded-[2.5rem] group hover:shadow-2xl transition-all duration-500 flex flex-col h-full relative overflow-hidden ${product.isCombo ? 'border-2 border-amber-500/80 shadow-[0_12px_30px_rgba(245,158,11,0.08)] bg-gradient-to-b from-amber-50/10 to-white' : 'border border-gray-100'}`}>
      <Link to={`/product/${product.id}`} className="block relative aspect-[4/3] sm:aspect-square overflow-hidden bg-gradient-to-br from-gray-50/50 to-white px-2 py-4 sm:p-4 group/img">
        {product.isCombo && (
           <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-amber-500 via-orange-500 to-red-600 text-white text-[10px] font-black uppercase tracking-widest text-center py-2 z-20 shadow-md">
              🔥 কম্বো প্যাকেজ
           </div>
        )}
        {discountPercent > 0 && (
           <div className="absolute top-4 left-4 bg-red-600 text-white text-[9px] font-black px-4 py-1.5 rounded-full shadow-lg z-10 uppercase tracking-[0.2em] italic animate-pulse">
              {discountPercent}% OFF
           </div>
        )}
        <img
          src={product.image}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="object-contain w-full h-full transition-all duration-1000 group-hover:scale-110 group-hover:rotate-1"
        />
        <div className="absolute inset-0 bg-primary-950/0 group-hover/img:bg-primary-950/5 transition-all duration-700"></div>
        {!product.inStock && (
          <div className="absolute inset-0 bg-white/80 backdrop-blur-[4px] flex items-center justify-center z-20">
            <span className="px-6 py-2.5 font-black text-red-600 bg-white border-2 border-red-100 rounded-full text-[10px] uppercase tracking-[0.3em] shadow-2xl">স্টক আউট</span>
          </div>
        )}
      </Link>

      <div className="p-5 sm:p-8 flex flex-col flex-1 items-center">
        {/* Rating Section */}
        <div className="flex items-center justify-between gap-1.5 mb-4">
          <div className="flex items-center gap-1.5">
            <div className="flex gap-0.5">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star 
                    key={star} 
                    className="w-3.5 h-3.5 text-accent" 
                    strokeWidth={1.5}
                 />
              ))}
            </div>
            <span className="text-[10px] font-black text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">(5.0)</span>
          </div>
          
        </div>

        <div className="w-full text-left mb-1">
          {product.brand && (
            <Link to={`/products?brand=${encodeURIComponent(product.brand)}`} className="text-[10px] sm:text-xs font-bold text-gray-400 hover:text-primary-600 uppercase tracking-widest mb-1 transition-colors">
              {product.brand}
            </Link>
          )}
        </div>
        <Link to={`/product/${product.id}`} className="w-full text-left">
          <h3 className="font-bold text-gray-800 text-[13px] sm:text-[15px] line-clamp-2 h-10 sm:h-12 mb-2 sm:mb-4 leading-tight group-hover:text-primary-600 transition-colors">
            {product.name}
          </h3>
        </Link>
        
        <div className="flex items-center justify-center gap-3 mb-6 mt-auto">
            {product.originalPrice && (
              <span className="text-[11px] text-gray-400 line-through font-bold opacity-60 italic">
                ৳{product.originalPrice}
              </span>
            )}
            <span className="font-black text-primary-900 text-[17px] sm:text-xl md:text-2xl tracking-tight">৳{product.price}</span>
        </div>
        
        <button
           onClick={(e) => {
             e.preventDefault();
             e.stopPropagation();
             addToCart(product);
           }}
           disabled={!product.inStock}
           className="w-full flex items-center justify-center gap-3 px-6 py-4 rounded-2xl text-white font-black text-[10px] md:text-xs transition-all bg-primary-800 hover:bg-primary-950 disabled:opacity-50 disabled:grayscale mt-auto uppercase tracking-[0.2em] shadow-[0_10px_20px_rgba(5,46,22,0.15)] hover:shadow-primary-900/30 active:scale-95 italic border border-transparent hover:border-white/20"
        >
           <ShoppingCart className="w-3.5 h-3.5" /> 
           <span className="whitespace-nowrap leading-none mt-0.5">{product.inStock ? "কিনুন এখনই" : "স্টক আউট"}</span>
        </button>
      </div>
    </div>
  );
}
