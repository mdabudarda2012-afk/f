export const MOCK_PRODUCTS = [
  {
    id: "1",
    name: "অরজিনাল মধু (৩০০ গ্রাম)",
    price: 350,
    originalPrice: 400,
    image: "https://images.unsplash.com/photo-1587049352847-81a56d773c1c?w=500&q=80",
    category: "Organic Food",
    inStock: true,
    description: "খাঁটি প্রাকৃতিক মধু। কোনো ধরনের ভেজাল নেই।"
  },
  {
    id: "2",
    name: "অজওয়া খেজুর (৫০০ গ্রাম)",
    price: 1200,
    originalPrice: 1350,
    image: "https://images.unsplash.com/photo-1596431221768-3e4a2bc0a4c2?w=500&q=80",
    category: "Dates",
    inStock: true,
    description: "মদিনার বিখ্যাত অজওয়া খেজুর। সরাসরি আমদানিকৃত।"
  },
  {
    id: "3",
    name: "কালোজিরা তেল (১০০ মিলি)",
    price: 350,
    originalPrice: 400,
    image: "https://images.unsplash.com/photo-1611078810059-4bf47353f86e?w=500&q=80",
    category: "Oils",
    inStock: true,
    description: "১০০% খাঁটি কোল্ড প্রেসড কালোজিরা তেল।"
  },
  {
    id: "4",
    name: "আতর আল কাবাহ (৬ মিলি)",
    price: 450,
    image: "https://images.unsplash.com/photo-1615560124376-74dbb8e19e71?w=500&q=80",
    category: "Perfume",
    inStock: true,
    description: "অ্যালকোহল মুক্ত প্রিমিয়াম আতর। দীর্ঘস্থায়ী সুবাস।"
  },
  {
    id: "5",
    name: "জায়নামাজ (তুর্কি)",
    price: 1550,
    image: "https://images.unsplash.com/photo-1608094858882-62bda5ff060b?w=500&q=80",
    category: "Lifestyle",
    inStock: false,
    description: "তুরস্ক থেকে আমদানিকৃত মখমলের জায়নামাজ।"
  },
  {
    id: "6",
    name: "গোলাপ জল (২০০ মিলি)",
    price: 150,
    image: "https://images.unsplash.com/photo-1606992850020-f576e279b90c?w=500&q=80",
    category: "Organic Food",
    inStock: true,
  },
  {
    id: "7",
    name: "মরিয়ম খেজুর (১ কেজি)",
    price: 850,
    originalPrice: 950,
    image: "https://images.unsplash.com/photo-1550828520-4cb496926fc9?w=500&q=80",
    category: "Dates",
    inStock: true,
    description: "সৌদি আরব থেকে সরাসরি আমদানি করা সেরা মানের মরিয়ম খেজুর।"
  },
  {
    id: "8",
    name: "কাঠবাদাম (২৫০ গ্রাম)",
    price: 450,
    originalPrice: 500,
    image: "https://images.unsplash.com/photo-1508061253366-f7da158b6d46?w=500&q=80",
    category: "Nuts",
    inStock: true,
  },
  {
    id: "9",
    name: "আতর বাখার (৬ মিলি)",
    price: 600,
    image: "https://images.unsplash.com/photo-1594824490333-6c841e06fe33?w=500&q=80",
    category: "Perfume",
    inStock: true,
    description: "উচ্চমানের আরবি সুগন্ধি।"
  },
  {
    id: "10",
    name: "সুন্দরবনের খাঁটি মধু (১ কেজি)",
    price: 900,
    image: "https://images.unsplash.com/photo-1590184462960-9602f741bfff?w=500&q=80",
    category: "Organic Food",
    inStock: true,
  }
];
