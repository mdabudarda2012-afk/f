// @ts-nocheck
import { collection, doc, getDoc, setDoc, getDocs, addDoc, updateDoc, deleteDoc, query, orderBy, serverTimestamp, onSnapshot, where, increment } from 'firebase/firestore';
import { db, auth } from './firebase';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  if (operationType !== OperationType.GET && operationType !== OperationType.LIST) {
    throw new Error(JSON.stringify(errInfo));
  }
}


// Collections
const PRODUCTS_COLLECTION = 'products';
const ORDERS_COLLECTION = 'orders';
const CATEGORIES_COLLECTION = 'categories';
const BRANDS_COLLECTION = 'brands';
const COUPONS_COLLECTION = 'coupons';
const SETTINGS_COLLECTION = 'settings';
const REVIEWS_COLLECTION = 'reviews';
const USERS_COLLECTION = 'users';
const RETURNS_COLLECTION = 'return_requests';

// Categories API
export const subscribeToCategories = (callback: (categories: any[]) => void, onError?: (error: any) => void) => {
  const q = query(collection(db, CATEGORIES_COLLECTION), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const categories = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(categories);
  }, (error) => {
    if (onError) onError(error);
    handleFirestoreError(error, OperationType.GET, CATEGORIES_COLLECTION);
  });
};

export const addCategory = async (data: { name: string, image?: string }) => {
  try {
    await addDoc(collection(db, CATEGORIES_COLLECTION), {
      ...data,
      createdAt: Date.now()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, CATEGORIES_COLLECTION);
  }
};

export const updateCategory = async (id: string, data: { name: string, image?: string }) => {
  try {
    await updateDoc(doc(db, CATEGORIES_COLLECTION, id), data);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, CATEGORIES_COLLECTION);
  }
};

export const deleteCategory = async (id: string) => {
  try {
    await deleteDoc(doc(db, CATEGORIES_COLLECTION, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, CATEGORIES_COLLECTION);
  }
};

// Brands API
export const subscribeToBrands = (callback: (brands: any[]) => void, onError?: (error: any) => void) => {
  const q = query(collection(db, BRANDS_COLLECTION), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
  }, (error) => {
    if (onError) onError(error);
    handleFirestoreError(error, OperationType.GET, BRANDS_COLLECTION);
  });
};

export const addBrand = async (data: { name: string, image?: string }) => {
  try {
    await addDoc(collection(db, BRANDS_COLLECTION), {
      ...data,
      createdAt: Date.now()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, BRANDS_COLLECTION);
  }
};

export const updateBrand = async (id: string, data: { name: string, image?: string }) => {
  try {
    await updateDoc(doc(db, BRANDS_COLLECTION, id), data);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, BRANDS_COLLECTION);
  }
};

export const deleteBrand = async (id: string) => {
  try {
    await deleteDoc(doc(db, BRANDS_COLLECTION, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, BRANDS_COLLECTION);
  }
};

// Coupons API
export const subscribeToCoupons = (callback: (coupons: any[]) => void) => {
  const q = query(collection(db, COUPONS_COLLECTION), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const coupons = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(coupons);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, COUPONS_COLLECTION);
  });
};

export const addCoupon = async (code: string, discount: number, type: 'percent' | 'fixed' = 'percent') => {
  try {
    await addDoc(collection(db, COUPONS_COLLECTION), {
      code: code.toUpperCase(),
      discount,
      type,
      active: true,
      createdAt: Date.now()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, COUPONS_COLLECTION);
  }
};

export const verifyCoupon = async (code: string) => {
  try {
    const q = query(collection(db, COUPONS_COLLECTION), where('code', '==', code.toUpperCase()), where('active', '==', true));
    const snap = await getDocs(q);
    if (!snap.empty) {
      return { id: snap.docs[0].id, ...snap.docs[0].data() };
    }
    return null;
  } catch (error) {
    console.error("Error verifying coupon", error);
    return null;
  }
};

export const deleteCoupon = async (id: string) => {
  try {
    await deleteDoc(doc(db, COUPONS_COLLECTION, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, COUPONS_COLLECTION);
  }
};

// Settings API
export const getSettings = async () => {
  try {
    const snapshot = await getDocs(collection(db, SETTINGS_COLLECTION));
    if (snapshot.empty) return { id: 'default', siteName: 'Kholos', phone: '', address: '', email: '' };
    return { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, SETTINGS_COLLECTION);
  }
};

export const subscribeToSettings = (callback: (data: any) => void) => {
  return onSnapshot(
    collection(db, SETTINGS_COLLECTION),
    (snapshot) => {
      if (snapshot.empty) {
        callback({ id: 'default', siteName: 'Kholos', phone: '', address: '', email: '' });
      } else {
        const doc = snapshot.docs[0];
        callback({ id: doc.id, ...doc.data() });
      }
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, SETTINGS_COLLECTION);
    }
  );
};

export const saveSettings = async (id: string, data: any) => {
  try {
    const { id: _, ...rest } = data;
    await updateDoc(doc(db, SETTINGS_COLLECTION, id), rest);
  } catch (error) {
    // If update fails because document doesn't exist, try setDoc
    try {
      const { id: _, ...rest } = data;
      await setDoc(doc(db, SETTINGS_COLLECTION, id || 'global'), rest);
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, SETTINGS_COLLECTION);
    }
  }
};

// User/Customer API
export const subscribeToUsers = (callback: (users: any[]) => void) => {
  const q = query(collection(db, USERS_COLLECTION));
  return onSnapshot(q, (snapshot) => {
    const users = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    // Client-side sort as fallback
    const sortedUsers = users.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    callback(sortedUsers);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, USERS_COLLECTION);
  });
};

export const getUserProfile = async (uid: string) => {
  try {
    const userDocRef = doc(db, USERS_COLLECTION, uid);
    const userDoc = await getDoc(userDocRef);
    if (!userDoc.exists()) {
      return null;
    }
    return { id: userDoc.id, ...userDoc.data() };
  } catch (error) {
    console.error("Error in getUserProfile", error);
    return null; 
  }
};

export const updateUserProfile = async (uid: string, data: any) => {
  try {
    const userDocRef = doc(db, USERS_COLLECTION, uid);
    const docSnap = await getDoc(userDocRef);
    if (!docSnap.exists()) {
      await setDoc(userDocRef, {
        uid,
        ...data,
        createdAt: Date.now(),
        updatedAt: Date.now()
      });
    } else {
      await setDoc(userDocRef, {
        ...data,
        updatedAt: Date.now()
      }, { merge: true });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, USERS_COLLECTION);
  }
};

export const deleteUser = async (id: string) => {
  try {
    await deleteDoc(doc(db, USERS_COLLECTION, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, USERS_COLLECTION);
  }
};

// Site Images API
export const subscribeToSiteImages = (callback: (images: any[]) => void, onError?: (error: any) => void) => {
  const q = query(collection(db, 'site_images'), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const images = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(images);
  }, (error) => {
    if (onError) onError(error);
    handleFirestoreError(error, OperationType.GET, 'site_images');
  });
};

export const addSiteImage = async (data: any) => {
  try {
    await addDoc(collection(db, 'site_images'), {
      ...data,
      createdAt: Date.now()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, 'site_images');
  }
};

export const deleteSiteImage = async (id: string) => {
  try {
    await deleteDoc(doc(db, 'site_images', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, 'site_images');
  }
};

// Reseller API
export const subscribeToResellers = (callback: (resellers: any[]) => void) => {
  const q = query(collection(db, 'resellers'), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(data);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, 'resellers');
  });
};

export const subscribeToUserReseller = (userId: string, callback: (reseller: any | null) => void) => {
  const q = query(collection(db, 'resellers'), where('userId', '==', userId));
  return onSnapshot(q, (snapshot) => {
    if (snapshot.empty) {
      callback(null);
    } else {
      callback({ id: snapshot.docs[0].id, ...snapshot.docs[0].data() });
    }
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, 'resellers');
  });
};

export const addReseller = async (data: any) => {
  try {
    await addDoc(collection(db, 'resellers'), {
      ...data,
      balance: 0,
      status: 'pending',
      createdAt: Date.now()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, 'resellers');
  }
};

export const deleteReseller = async (id: string) => {
  try {
    await deleteDoc(doc(db, 'resellers', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, 'resellers');
  }
};

// Withdrawals API
export const subscribeToWithdrawals = (callback: (withdrawals: any[]) => void) => {
  const q = query(collection(db, 'withdrawals'), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(data);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, 'withdrawals');
  });
};

export const deleteWithdrawal = async (id: string) => {
  try {
    await deleteDoc(doc(db, 'withdrawals', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, 'withdrawals');
  }
};

// Reviews API
export const subscribeToReviews = (callback: (reviews: any[]) => void) => {
  const q = query(collection(db, REVIEWS_COLLECTION), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    let reviews = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    reviews.sort((a:any, b:any) => {
       const tA = (a as any).createdAt?.seconds || 0;
       const tB = (b as any).createdAt?.seconds || 0;
       return tB - tA;
    });
    callback(reviews);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, REVIEWS_COLLECTION);
  });
};

export const deleteReview = async (id: string) => {
  try {
    await deleteDoc(doc(db, REVIEWS_COLLECTION, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, REVIEWS_COLLECTION);
  }
};

export const subscribeToProductReviews = (productId: string, callback: (reviews: any[]) => void) => {
  const q = query(collection(db, REVIEWS_COLLECTION), where('productId', '==', productId));
  return onSnapshot(q, (snapshot) => {
    const reviews = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(reviews);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, REVIEWS_COLLECTION);
  });
};

export const addReview = async (productId: string, data: { rating: number, comment: string, reviewerName: string, reviewerPhone: string }) => {
  try {
    await addDoc(collection(db, REVIEWS_COLLECTION), {
      productId,
      ...data,
      status: 'pending', // admin moderation could be added later
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, REVIEWS_COLLECTION);
  }
};


// Product API
export const subscribeToProducts = (callback: (products: any[]) => void, onError?: (error: any) => void) => {
  const q = query(collection(db, PRODUCTS_COLLECTION), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const products = snapshot.docs.map(doc => {
      const data = doc.data();
      return { 
        id: doc.id, 
        ...data,
        inStock: data.stock > 0 
      };
    });
    callback(products);
  }, (error) => {
    if (onError) onError(error);
    handleFirestoreError(error, OperationType.GET, PRODUCTS_COLLECTION);
  });
};

export const addProduct = async (productData: any) => {
  try {
    const docRef = await addDoc(collection(db, PRODUCTS_COLLECTION), {
      ...productData,
      createdAt: Date.now(),
      isActive: true
    });
    return docRef.id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, PRODUCTS_COLLECTION);
  }
};

export const updateProduct = async (productId: string, data: any) => {
  try {
    await updateDoc(doc(db, PRODUCTS_COLLECTION, productId), data);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${PRODUCTS_COLLECTION}/${productId}`);
  }
};

export const deleteProduct = async (productId: string) => {
  try {
    await deleteDoc(doc(db, PRODUCTS_COLLECTION, productId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${PRODUCTS_COLLECTION}/${productId}`);
  }
};

// Product Returns API
export const subscribeToReturns = (callback: (returns: any[]) => void) => {
  const q = query(collection(db, RETURNS_COLLECTION), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const returns = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(returns);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, RETURNS_COLLECTION);
  });
};

export const addReturnRequest = async (data: { orderId: string, customerId: string, items: any[], reason: string, phone: string, customerName: string }) => {
  try {
    await addDoc(collection(db, RETURNS_COLLECTION), {
      ...data,
      status: 'pending',
      createdAt: Date.now()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, RETURNS_COLLECTION);
  }
};

export const updateReturnStatus = async (id: string, status: string, orderId?: string) => {
  try {
    await updateDoc(doc(db, RETURNS_COLLECTION, id), { status, updatedAt: Date.now() });
    
    // Also update the order status if it's approved
    if (status === 'approved' && orderId) {
      // Find the order by shortId or ID
      const ordersSnapshot = await getDocs(query(collection(db, ORDERS_COLLECTION), where('shortId', '==', orderId)));
      if (!ordersSnapshot.empty) {
        const orderDoc = ordersSnapshot.docs[0];
        await updateDoc(doc(db, ORDERS_COLLECTION, orderDoc.id), { status: 'returned' });
      } else {
        await updateDoc(doc(db, ORDERS_COLLECTION, orderId), { status: 'returned' });
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, RETURNS_COLLECTION);
  }
};

export const deleteReturnRequest = async (id: string) => {
  try {
    await deleteDoc(doc(db, RETURNS_COLLECTION, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, RETURNS_COLLECTION);
  }
};

export const restockItems = async (items: any[]) => {
  try {
    for (const item of items) {
      if (item.id || item.productId) {
         await updateDoc(doc(db, PRODUCTS_COLLECTION, item.id || item.productId), {
           stock: increment(item.quantity)
         });
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, PRODUCTS_COLLECTION);
  }
};


export const subscribeToOrders = (callback: (orders: any[]) => void) => {
  const q = query(collection(db, ORDERS_COLLECTION), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const orders = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(orders);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, ORDERS_COLLECTION);
  });
};

export const subscribeToUserOrders = (userId: string, callback: (orders: any[]) => void) => {
  const q = query(
    collection(db, ORDERS_COLLECTION), 
    where('customerId', '==', userId),
    orderBy('createdAt', 'desc')
  );
  return onSnapshot(q, (snapshot) => {
    const orders = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(orders);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, ORDERS_COLLECTION);
  });
};

export const deleteOrder = async (id: string) => {
  try {
    await deleteDoc(doc(db, ORDERS_COLLECTION, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, ORDERS_COLLECTION);
  }
};

export const addOrder = async (orderData: any) => {
  try {
    const shortId = Math.random().toString(36).substring(2, 8).toUpperCase();
    const docRef = await addDoc(collection(db, ORDERS_COLLECTION), {
      ...orderData,
      shortId,
      status: 'pending',
      createdAt: Date.now()
    });
    
    // Decrement stock for ordered items
    if (orderData.items && Array.isArray(orderData.items)) {
       for (const item of orderData.items) {
          if (item.productId && item.quantity) {
             const productRef = doc(db, PRODUCTS_COLLECTION, item.productId);
             updateDoc(productRef, { stock: increment(-item.quantity) }).catch(e => console.error("Error updating stock", e));
          }
       }
    }

    // Create or update user record in 'users' collection
    if (orderData.customerId && orderData.customerId !== 'guest') {
      const userData = {
        uid: orderData.customerId,
        displayName: orderData.customerName,
        phone: orderData.customerPhone,
        email: orderData.customerEmail || '',
        address: orderData.customerAddress || '',
        lastOrderAt: Date.now(),
        updatedAt: Date.now()
      };
      
      const userDocRef = doc(db, USERS_COLLECTION, orderData.customerId);
      const docSnap = await getDoc(userDocRef);
      if (!docSnap.exists()) {
        await setDoc(userDocRef, { ...userData, email: orderData.customerEmail, createdAt: Date.now() }).catch(e => console.error("Could not save to users collection", e));
      } else {
        await setDoc(userDocRef, userData, { merge: true }).catch(e => console.error("Could not save to users collection", e));
      }
    }
    
    return { id: docRef.id, shortId };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, ORDERS_COLLECTION);
  }
};

export const updateOrderStatus = async (orderId: string, status: string) => {
  try {
    await updateDoc(doc(db, ORDERS_COLLECTION, orderId), { status });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `${ORDERS_COLLECTION}/${orderId}`);
  }
};

// Generic Collection Management Helpers
export const subscribeToCollection = (collectionName: string, callback: (data: any[]) => void, sortField: string = 'createdAt') => {
  const q = query(collection(db, collectionName), orderBy(sortField, 'desc'));
  return onSnapshot(q, (snapshot) => {
    callback(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, collectionName);
  });
};

export const addItemToCollection = async (collectionName: string, data: any) => {
  try {
    await addDoc(collection(db, collectionName), {
      ...data,
      createdAt: Date.now()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, collectionName);
  }
};

export const updateItemInCollection = async (collectionName: string, id: string, data: any) => {
  try {
    await updateDoc(doc(db, collectionName, id), data);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, collectionName);
  }
};

export const deleteItemFromCollection = async (collectionName: string, id: string) => {
  try {
    await deleteDoc(doc(db, collectionName, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, collectionName);
  }
};
