import { initializeApp, getApps } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import defaultFirebaseConfig from '../../firebase-applet-config.json';

let config = defaultFirebaseConfig;
try {
  // Allow overriding firebase config via local storage as requested
  const customConfig = localStorage.getItem('customFirebaseConfig');
  if (customConfig) {
    const parsed = JSON.parse(customConfig);
    if (parsed && parsed.apiKey) {
      config = parsed;
    }
  }
} catch(e) {}

const app = getApps().length === 0 ? initializeApp(config) : getApps()[0];
export const db = getFirestore(app, (config as any).databaseId || defaultFirebaseConfig.firestoreDatabaseId || '(default)');
export const auth = getAuth(app);
