import { Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Admin from './pages/Admin';
import Account from './pages/Account';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Products from './pages/Products';
import Category from './pages/Category';
import Page from './pages/Page';
import OrderTracking from './pages/OrderTracking';
import ResellerRegistration from './pages/ResellerRegistration';
import ReturnRequest from './pages/ReturnRequest';
import ScrollToTop from './components/ScrollToTop';

export default function App() {
  return (
    <>
      <ScrollToTop />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/products" element={<Products />} />
        <Route path="/category/:categoryName" element={<Category />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/checkout" element={<Checkout />} />
        <Route path="/dashboard/*" element={<Admin />} />
        <Route path="/admin/*" element={<Admin />} />
        <Route path="/account" element={<Account />} />
        <Route path="/product/:id" element={<ProductDetail />} />
        <Route path="/pages/:slug" element={<Page />} />
        <Route path="/track" element={<OrderTracking />} />
        <Route path="/reseller-registration" element={<ResellerRegistration />} />
        <Route path="/return-request" element={<ReturnRequest />} />
      </Routes>
    </>
  );
}

