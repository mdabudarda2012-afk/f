// @ts-nocheck
import { create } from 'zustand';

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  images?: string[];
  category: string;
  brand?: string;
  inStock: boolean;
  shortDescription?: string;
  description?: string;
  isCombo?: boolean;
  isHotDeal?: boolean;
  isFlashSale?: boolean;
  isVerified?: boolean;
  tag?: string;
  salesCount?: number;
  rating?: number;
  reviewCount?: number;
  [key: string]: any;
}

interface CartItem extends Product {
  quantity: number;
  cartItemId: string; // id + selectedOption
  selectedOption?: string;
}

interface AppState {
  cart: CartItem[];
  addToCart: (product: Product, selectedOption?: string) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, quantity: number) => void;
  clearCart: () => void;
  cartTotal: () => number;
}

export const useStore = create<AppState>((set, get) => ({
  cart: [],
  addToCart: (product, selectedOption?: string) => {
    set((state) => {
      const targetCartId = product.id + (selectedOption ? '-' + selectedOption : '');
      const existing = state.cart.find(item => item.cartItemId === targetCartId);
      if (existing) {
        return {
          cart: state.cart.map(item => 
            item.cartItemId === targetCartId ? { ...item, quantity: Math.min(item.quantity + 1, product.stock || 9999) } : item
          )
        };
      }
      return { cart: [...state.cart, { ...product, quantity: 1, selectedOption, cartItemId: targetCartId }] };
    });
  },
  removeFromCart: (cartItemId) => {
    set((state) => ({
      cart: state.cart.filter(item => item.cartItemId !== cartItemId)
    }));
  },
  updateQuantity: (cartItemId, quantity) => {
    set((state) => ({
      cart: state.cart.map(item => 
        item.cartItemId === cartItemId ? { ...item, quantity: Math.min(item.stock || 9999, Math.max(1, quantity)) } : item
      )
    }));
  },
  clearCart: () => set({ cart: [] }),
  cartTotal: () => {
    return get().cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  }
}));
