const fs = require('fs');
const path = require('path');

const file = path.join(__dirname, 'src/pages/AdminDashboard.tsx');
let content = fs.readFileSync(file, 'utf8');

// Replace all buttons calling clearForm without type="button"
content = content.replace(/<button(\s+onClick=\{\(\) => clearForm\([^}]+\}\))/g, '<button type="button"$1');
content = content.replace(/<button([\s\S]*?)onClick=\{\(\) => clearForm\([^}]+\}\)/g, (match, p1) => {
    if (match.includes('type="button"') || match.includes("type='button'")) return match;
    return match.replace('<button', '<button type="button"');
});

fs.writeFileSync(file, content, 'utf8');
console.log('Fixed clear buttons');
