const { execSync } = require('child_process');
execSync('git restore src/pages/AdminDashboard.tsx', { stdio: 'inherit' });
