import admin from "firebase-admin";
import fs from "fs";
const firebaseConfig = JSON.parse(fs.readFileSync('firebase-applet-config.json', 'utf-8'));
admin.initializeApp({ projectId: firebaseConfig.projectId });
const db = admin.firestore();
async function run() {
  const email = 'mdabudarda2012@gmail.com';
  const snapshot = await db.collection('users').where('email', '==', email).get();
  for (const doc of snapshot.docs) {
    if (doc.data().role !== 'student') {
        await doc.ref.update({ role: 'student' });
        console.log("updated", doc.id);
    }
  }
}
run().then(() => process.exit(0)).catch(e => { console.error(e); process.exit(1); });
