import React, { useState, useEffect, useRef } from 'react';

export const DebouncedInput = ({ value, onChange, debounce = 300, onEnter, onKeyDown, ...props }: any) => {
  const [internalVal, setInternalVal] = useState(value || "");
  const lastPropValueRef = useRef(value || "");
  const onChangeRef = useRef(onChange);

  useEffect(() => {
    onChangeRef.current = onChange;
  });

  if (value !== lastPropValueRef.current) {
    lastPropValueRef.current = value || "";
    if (internalVal !== (value || "")) {
      setInternalVal(value || "");
    }
  }

  useEffect(() => {
    if (internalVal === (value || "")) {
      return;
    }

    const handler = setTimeout(() => {
      onChangeRef.current(internalVal);
    }, debounce);

    return () => clearTimeout(handler);
  }, [internalVal, debounce, value]);

  return (
    <input
      value={internalVal}
      onChange={(e) => setInternalVal(e.target.value)}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          onChangeRef.current(internalVal);
          if (onEnter) onEnter(internalVal);
        }
        if (onKeyDown) onKeyDown(e);
      }}
      {...props}
    />
  );
};
