import React from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'motion/react';

// Import all your components here or pass them as children
// Since we are moving Routes here, we need to accept children
const AnimatedRoutes = ({ children }: { children: React.ReactNode }) => {
  const location = useLocation();

  return (
    <Routes location={location}>
      {children}
    </Routes>
  );
};

export default AnimatedRoutes;
