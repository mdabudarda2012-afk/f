import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, X, Calendar } from 'lucide-react';
import { useRealtimeCollection } from '../hooks/useRealtime';
import { Link } from 'react-router-dom';

const FloatingNoticePopup = () => {
  const { data: notices } = useRealtimeCollection('notices');
  const [isVisible, setIsVisible] = useState(false);
  const [latestNotice, setLatestNotice] = useState<any>(null);

  useEffect(() => {
    if (notices && notices.length > 0) {
      // Sort to get the most recent notice
      const sortedNotices = [...notices].sort((a: any, b: any) => {
        const timeA = a.created_at ? new Date(a.created_at).getTime() : 0;
        const timeB = b.created_at ? new Date(b.created_at).getTime() : 0;
        return timeB - timeA;
      });
      
      const topNotice = sortedNotices[0];
      if (!topNotice) return;

      setLatestNotice(topNotice);
      // Delay for appearance
      const timer = setTimeout(() => setIsVisible(true), 500);
      return () => clearTimeout(timer);
    }
  }, [notices]);

  const handleClose = () => {
    setIsVisible(false);
  };

  if (!latestNotice) return null;

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 50, scale: 0.9 }}
          transition={{ type: "spring", bounce: 0.3 }}
          className="fixed bottom-3 right-3 z-50 w-[calc(100vw-1.5rem)] max-w-[240px] md:max-w-[280px]"
        >
          <div className="bg-white rounded-xl shadow-2xl border-2 border-orange-500 overflow-hidden flex flex-col max-h-[50vh] md:max-h-[60vh] shadow-orange-100/50">
            <div className="bg-gradient-to-r from-orange-600 to-orange-500 px-3 py-2 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-1.5">
                <Bell className="h-3 w-3 text-white" />
                <span className="text-white font-black uppercase tracking-widest text-[10px]">Latest Notice</span>
              </div>
              <button 
                onClick={handleClose}
                className="text-white/80 hover:text-white transition-colors p-1"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
            
            <div className="p-3.5 flex-1 overflow-y-auto">
              <div className="flex items-center gap-1.5 text-slate-400 mb-1.5">
                <Calendar className="h-2.5 w-2.5 text-orange-500" />
                <span className="text-[9px] font-black uppercase tracking-widest">
                  {latestNotice.created_at ? new Date(latestNotice.created_at).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' }) : 'Recent'}
                </span>
              </div>
              
              <h3 className="text-sm font-black text-slate-900 mb-2 tracking-tight">
                {latestNotice.title}
              </h3>
              
              <div className="text-slate-600 text-xs whitespace-pre-wrap leading-relaxed line-clamp-4">
                {latestNotice.content}
              </div>
            </div>
            
            <div className="p-3 bg-orange-50/50 border-t border-orange-100 flex items-center gap-2 shrink-0">
              <Link 
                to="/notices" 
                onClick={handleClose}
                className="flex-1 bg-orange-600 text-white text-center py-2 rounded-lg font-black uppercase tracking-widest text-[9px] hover:bg-orange-700 transition-colors shadow-sm"
              >
                View
              </Link>
              <button 
                onClick={handleClose}
                className="flex-1 bg-white text-slate-600 border border-slate-200 text-center py-2 rounded-lg font-black uppercase tracking-widest text-[9px] hover:bg-slate-50 hover:text-slate-900 transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default FloatingNoticePopup;
