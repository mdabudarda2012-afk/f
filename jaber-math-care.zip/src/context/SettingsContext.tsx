import { db } from '../firebase';
import { collection, onSnapshot } from 'firebase/firestore';
import React, { createContext, useContext, useState, useEffect } from 'react';

interface Settings {
  site_name?: string;
  hero_image?: string;
  about_image?: string;
  contact_phone?: string;
  contact_email?: string;
  office_address?: string;
  facebook_url?: string;
  youtube_url?: string;
  instagram_url?: string;
  logo_url?: string;
  developer_name?: string;
  developer_photo_url?: string;
  developer_bio?: string;
  developer_email?: string;
  developer_phone?: string;
  developer_location?: string;
  [key: string]: any;
}

interface SettingsContextType {
  settings: Settings;
  loading: boolean;
  refreshSettings: () => Promise<void>;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

const updateFavicon = (url: string) => {
  if (!url) return;
  let link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
  if (!link) {
    link = document.createElement('link');
    link.rel = 'icon';
    document.head.appendChild(link);
  }
  link.href = url;
};

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<Settings>(() => {
    const saved = localStorage.getItem('site_settings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const siteName = parsed.site_name || 'Jaber Math Care';
        document.title = siteName;
        if (parsed.brand_logo) {
          updateFavicon(parsed.brand_logo);
        }
        return parsed;
      } catch (e) {
        return {};
      }
    }
    return {};
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Real-time listener for settings collection
    const unsubscribe = onSnapshot(collection(db, 'settings'), (snapshot) => {
      const data: any = {};
      snapshot.docs.forEach(doc => {
        const docData = doc.data();
        if (docData.key) {
          data[docData.key] = docData.value;
        } else {
          data[doc.id] = docData.value !== undefined ? docData.value : docData;
        }
      });
      
      setSettings(data);
      localStorage.setItem('site_settings', JSON.stringify(data));
      
      if (data.site_name) {
        document.title = data.site_name;
      }
      if (data.brand_logo) {
        updateFavicon(data.brand_logo);
      }
      
      setLoading(false);
    }, (error) => {
      console.error('Settings real-time error:', error);
      setLoading(false);
      // Trigger a custom event so the UI can respond
      window.dispatchEvent(new CustomEvent('firebase-offline', { detail: `Settings loading failed: ${error.message}. If using a custom project, make sure Firestore Rules are deployed.` }));
    });

    return () => unsubscribe();
  }, []);

  const refreshSettings = async () => {
    // No-op since it's real-time now, but kept for compatibility
  };

  return (
    <SettingsContext.Provider value={{ settings, loading, refreshSettings }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
