import React, { useState, useEffect } from 'react';
import { Star, Quote, User, ArrowLeft } from 'lucide-react';
import { motion } from 'motion/react';
import { db } from '../firebase';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const Reviews = () => {
  const { user } = useAuth();
  const [reviews, setReviews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const q = query(
          collection(db, 'reviews'),
          where('status', '==', 'approved'),
          orderBy('created_at', 'desc')
        );
        const querySnapshot = await getDocs(q);
        const data = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        setReviews(data);
      } catch (error) {
        console.error('Failed to fetch reviews', error);
        // Fallback to all reviews if index is missing or other error
        try {
          const querySnapshot = await getDocs(collection(db, 'reviews'));
          const data = querySnapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
          })).filter((r: any) => r.status === 'approved');
          setReviews(data);
        } catch (e) {
          console.error('Final fallback failed', e);
        }
      } finally {
        setLoading(false);
      }
    };
    fetchReviews();
  }, []);

  return (
    <div className="bg-slate-50 min-h-screen pb-20">
      {/* Header */}
      <div className="bg-white pt-20 pb-12 px-4 relative overflow-hidden border-b border-slate-100">
        <div className="max-w-7xl mx-auto relative z-10">
          <button 
            onClick={() => navigate(-1)}
            className="mb-4 flex items-center gap-2 text-slate-400 hover:text-slate-600 font-bold transition-colors group"
          >
            <ArrowLeft className="h-5 w-5 group-hover:-translate-x-1 transition-transform" />
            Back
          </button>
          <div className="text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-3xl md:text-4xl font-black text-orange-600 tracking-tight mb-2"
            >
              Student Testimonials
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-base text-slate-500 max-w-xl mx-auto font-medium"
            >
              Real stories from students who have transformed their journey with Jaber Math Care.
            </motion.p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <div className="flex justify-center mb-12">
          <button 
            onClick={() => {
              if (user) {
                navigate('/dashboard/profile');
              } else {
                navigate('/login');
              }
            }}
            className="bg-white text-orange-600 px-8 py-4 rounded-2xl font-black shadow-xl hover:scale-105 transition-all flex items-center gap-2 border border-orange-100"
          >
            <Star className="h-5 w-5 fill-current" />
            Add Your Review
          </button>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600"></div>
          </div>
        ) : reviews.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {reviews.map((review, idx) => (
              <motion.div
                key={review.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="relative p-8 rounded-[2.5rem] border border-slate-100 shadow-xl bg-white hover:shadow-2xl transition-all group overflow-hidden"
              >
                <div className="absolute top-0 right-0 w-32 h-32 bg-orange-50 rounded-full -mr-16 -mt-16 transition-transform group-hover:scale-150 duration-700 ease-out"></div>
                <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-white shadow-lg group-hover:scale-110 transition-transform duration-500">
                      <img 
                        src={review.student_image || `https://picsum.photos/seed/student${review.id}/200/200`} 
                        alt={review.student_name} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div>
                      <h4 className="text-lg font-black text-slate-900 tracking-tight">{review.student_name}</h4>
                      <div className="flex gap-1 mt-1">
                        {[...Array(5)].map((_, i) => (
                          <Star 
                            key={i} 
                            className={`h-4 w-4 ${i < (review.rating || 5) ? 'text-orange-500 fill-orange-500' : 'text-slate-200'}`} 
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                  <Quote className="h-10 w-10 text-orange-100 mb-4 transform -scale-x-100" />
                  <p className="text-slate-600 font-medium leading-relaxed">
                    "{review.comment}"
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 bg-white rounded-[3rem] border border-dashed border-slate-200">
            <Quote className="h-16 w-16 text-slate-100 mx-auto mb-4" />
            <p className="text-slate-400 text-xl font-bold">No reviews yet. Be the first to share your experience!</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Reviews;
