import { useRealtimeCollection } from '../hooks/useRealtime';
import { where } from 'firebase/firestore';
import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, BookOpen, Users, Award, PlayCircle, Rocket, Info, Phone, LogIn, User, GraduationCap, Atom, Magnet, FlaskConical, Zap, Calendar, X, Star, BarChart2, Youtube, Bell, Sparkles, SquareRadical, Download } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { Link } from 'react-router-dom';
import { useSettings } from '../context/SettingsContext';
import { useAuth } from '../context/AuthContext';
import { ChevronRight } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import FloatingNoticePopup from '../components/FloatingNoticePopup';

const StudentReviewsList = () => {
  const { data: reviews } = useRealtimeCollection('reviews', [
    where('status', '==', 'approved')
  ]);

  if (reviews.length === 0) return null;

  return (
    <>
      {reviews.slice(0, 3).map((review, idx) => (
        <motion.div
// ... (rest of component remains same)
          key={review.id}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: idx * 0.1 }}
          className="glass p-8 rounded-[2.5rem] border border-white/60 shadow-xl bg-white/40 hover:bg-white/60 transition-all group"
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-white shadow-lg group-hover:scale-110 transition-transform duration-500">
              <img 
                src={review.student_image || `https://picsum.photos/seed/student${review.id}/200/200`} 
                alt={review.student_name} 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h4 className="text-lg font-black text-slate-900 tracking-tight">{review.student_name}</h4>
              <div className="flex gap-1 mt-1">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className={`h-3 w-3 ${i < (review.rating || 5) ? 'text-orange-500 fill-orange-500' : 'text-slate-200'}`} 
                  />
                ))}
              </div>
            </div>
          </div>
          <p className="text-slate-600 font-medium leading-relaxed italic">
            "{review.comment}"
          </p>
        </motion.div>
      ))}
    </>
  );
};

const ScrollingNotices = () => {
  const { data: notices } = useRealtimeCollection('notices');

  if (notices.length === 0) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden bg-white/40 backdrop-blur-md border border-white/60 py-4 rounded-[2rem] shadow-sm group hover:bg-white/60 transition-all"
    >
      <div className="flex items-center gap-4 px-6 absolute left-0 top-0 h-full z-20 bg-white/80 backdrop-blur-md border-r border-slate-100">
        <div className="relative">
          <Bell className="h-5 w-5 text-orange-600" />
          <motion.span 
            animate={{ scale: [1, 1.5, 1], opacity: [1, 0, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute -top-1 -right-1 w-2 h-2 bg-orange-500 rounded-full"
          />
        </div>
        <span className="text-[10px] font-black uppercase tracking-widest text-slate-900 whitespace-nowrap">Latest News</span>
      </div>
      
      {/* Gradient Fades */}
      <div className="absolute inset-y-0 left-48 w-20 bg-gradient-to-r from-white/80 to-transparent z-10 pointer-events-none" />
      <div className="absolute inset-y-0 right-0 w-20 bg-gradient-to-l from-white/80 to-transparent z-10 pointer-events-none" />

      <div className="flex overflow-hidden">
        <motion.div 
          animate={{ x: [0, -1000] }}
          transition={{ 
            duration: 30, 
            repeat: Infinity, 
            ease: "linear" 
          }}
          className="flex gap-16 whitespace-nowrap pl-56"
        >
          {notices.map((notice, i) => (
            <div key={i} className="flex items-center gap-4 group/item">
              <div className="w-2 h-2 rounded-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.5)]" />
              <span className="text-sm font-black text-slate-700 uppercase tracking-wide group-hover/item:text-orange-600 transition-colors">
                {notice.title}
              </span>
            </div>
          ))}
          {/* Duplicate for seamless loop */}
          {notices.map((notice, i) => (
            <div key={`dup-${i}`} className="flex items-center gap-4 group/item">
              <div className="w-2 h-2 rounded-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.5)]" />
              <span className="text-sm font-black text-slate-700 uppercase tracking-wide group-hover/item:text-orange-600 transition-colors">
                {notice.title}
              </span>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.div>
  );
};

const MouseScrollIcon = () => (
  <motion.div
    initial={{ opacity: 0, y: -10 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 1, delay: 1 }}
    className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 hidden lg:flex"
  >
    <div className="w-6 h-10 rounded-full border-2 border-orange-500/30 flex justify-center p-1">
      <motion.div
        animate={{ y: [0, 12, 0] }}
        transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
        className="w-1.5 h-1.5 rounded-full bg-orange-500"
      />
    </div>
    <span className="text-[10px] font-black uppercase tracking-[0.2em] text-orange-500/50">Scroll</span>
  </motion.div>
);

const AdComponent = () => (
  <div className="my-12 p-8 bg-gradient-to-r from-orange-500 to-rose-500 rounded-[2.5rem] text-center text-white shadow-2xl">
    <h3 className="text-2xl font-black mb-2">Special Offer!</h3>
    <p className="text-orange-100 mb-4">Check out our latest courses and get a discount.</p>
    <Link to="/courses" className="inline-block bg-white text-orange-600 px-8 py-3 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-orange-50 transition-all">
      View Courses
    </Link>
  </div>
);

const Home = () => {
  const { settings, loading } = useSettings();

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="overflow-hidden bg-slate-50/50">
      {/* Hero Section */}
      <section className="relative min-h-[70vh] lg:min-h-[85vh] flex items-center pt-4 md:pt-10 lg:pt-16 pb-10 lg:pb-16 overflow-hidden">
        {/* Background Decorative Elements - Removed animate-pulse for performance */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
          <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-orange-500/20 rounded-full blur-[120px]" />
          <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-rose-500/20 rounded-full blur-[120px]" />
          <div className="absolute top-[20%] right-[10%] w-[30%] h-[30%] bg-blue-500/10 rounded-full blur-[100px]" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 items-center">
            <div className="space-y-6 text-center lg:text-left">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="space-y-4"
              >
                <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3">
                  <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-orange-100 text-orange-600 text-[10px] md:text-xs font-bold uppercase tracking-widest border border-orange-200/50 shadow-sm">
                    <Sparkles className="h-4 w-4" />
                    <span>{settings.hero_badge_text || "Engineers Are Born Here"}</span>
                  </div>
                </div>
                
                <h1 className="font-black leading-tight tracking-tight text-slate-900 text-center lg:text-left">
                  <div className="relative inline-flex flex-col items-center lg:items-start group">
                    <div className="relative">
                      <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 via-rose-600 to-orange-600 mb-2 whitespace-normal md:whitespace-nowrap text-4xl sm:text-6xl md:text-7xl lg:text-[4rem] xl:text-[4.8rem] font-black leading-[1.1] pb-4 inline-block overflow-visible tracking-tighter shadow-sm">
                        {settings.site_name || "Jaber Math Care"}
                      </span>
                      {/* Animated Underline */}
                      <motion.div 
                        className="absolute bottom-4 left-0 h-1 lg:h-1.5 bg-gradient-to-r from-orange-500 to-rose-500 rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: "100%" }}
                        transition={{ duration: 1.2, delay: 0.5, ease: "circOut" }}
                      />
                    </div>
                  </div>
                </h1>
                
                <div className="flex flex-col lg:flex-row items-center lg:items-center gap-6 lg:gap-12">
                  <div className="order-2 lg:order-1 flex-1">
                    <p className="text-sm sm:text-lg md:text-xl text-orange-600 max-w-xl mx-auto lg:mx-0 leading-relaxed font-bold text-center lg:text-left drop-shadow-sm">
                      {settings.hero_subtitle || "Where mathematical excellence meets engineering dreams, shaping the innovators of tomorrow."}
                    </p>
                  </div>
                  
                  <motion.div 
                    animate={{ 
                      y: [0, -15, 0],
                      rotate: [0, 5, -5, 0],
                      scale: [1, 1.1, 1]
                    }}
                    transition={{ 
                      duration: 3, 
                      repeat: Infinity, 
                      ease: "easeInOut" 
                    }}
                    className="order-1 lg:order-2 text-orange-600 drop-shadow-[0_15px_30px_rgba(249,115,22,0.4)] shrink-0 z-20 pointer-events-none relative lg:mt-2"
                  >
                    <SquareRadical className="h-12 w-12 sm:h-16 sm:w-16 lg:h-24 lg:w-24 border-none" strokeWidth={3} />
                    <motion.div
                      animate={{ opacity: [0.1, 1, 0.1], scale: [0.8, 1.2, 0.8] }}
                      transition={{ duration: 1.8, repeat: Infinity }}
                      className="absolute -top-1 -right-4 text-orange-400"
                    >
                      <Star className="h-4 w-4 sm:h-5 sm:w-5 fill-current" />
                    </motion.div>
                  </motion.div>
                </div>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="space-y-4 max-w-md mx-auto lg:mx-0"
              >
                <div className="flex gap-4">
                  <Link to="/programs" className="flex-1 bg-orange-600 text-white px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-orange-700 transition-all shadow-xl shadow-orange-600/20 flex items-center justify-center gap-2 group active:scale-95">
                    Programs
                    <GraduationCap className="h-4 w-4" />
                  </Link>
                  <Link to="/contact" className="flex-1 bg-white text-slate-900 px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-50 transition-all shadow-lg border border-slate-200 flex items-center justify-center gap-2 active:scale-95">
                    Contact Us
                    <Phone className="h-4 w-4" />
                  </Link>
                </div>
                
                <div className="hidden lg:block">
                  <Link to={settings.jaber_tube_link || "/video-library"} className="w-full bg-orange-600 text-white px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-orange-700 transition-all shadow-xl shadow-orange-600/20 flex items-center justify-center gap-2 group active:scale-95">
                    {settings.jaber_tube_text || "Jaber Math Care Tube"}
                    <Youtube className="h-5 w-5 group-hover:scale-110 transition-transform" />
                  </Link>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="grid grid-cols-2 sm:grid-cols-4 gap-3 md:gap-4 pt-6 md:pt-8"
              >
                {[
                  { icon: Calendar, label: "Schedule", path: "/schedule" },
                  { icon: BarChart2, label: "Results", path: "/results" },
                  { icon: Phone, label: "Contact", path: "/contact" },
                  { icon: PlayCircle, label: "Class", path: "/recorded-classes" }
                ].map((item, i) => (
                  <Link 
                    key={i}
                    to={item.path}
                    className="flex flex-col items-center gap-2 max-md:gap-1.5 p-4 md:p-6 rounded-[2rem] bg-white/50 hover:bg-white border border-white/50 hover:border-orange-200 transition-all group shadow-sm hover:shadow-md"
                  >
                    <div className="w-10 h-10 md:w-14 md:h-14 rounded-2xl bg-orange-50 flex items-center justify-center text-orange-600 group-hover:scale-110 transition-transform">
                      <item.icon className="h-5 w-5 md:h-7 md:w-7" />
                    </div>
                    <span className="text-[10px] md:text-[12px] font-black uppercase tracking-widest text-slate-500 group-hover:text-orange-600 text-center leading-tight">{item.label}</span>
                  </Link>
                ))}
              </motion.div>

              <div className="pt-4">
                <ScrollingNotices />
              </div>
            </div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, type: "spring" }}
              className="relative mt-24 lg:mt-0 lg:scale-[1.05] xl:scale-[1.1] lg:translate-x-16 xl:translate-x-24 mx-auto lg:mx-0 flex justify-center items-center z-0"
            >
              {/* Rotating Rings - Refined & Compact */}
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
                className="absolute inset-[-25px] lg:inset-[-40px] xl:inset-[-50px] rounded-full border-[6px] border-dashed border-orange-500/80 shadow-[0_0_100px_rgba(249,115,22,0.4)] z-0"
              />
              <motion.div 
                animate={{ rotate: -360 }}
                transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
                className="absolute inset-[-45px] lg:inset-[-70px] xl:inset-[-90px] rounded-full border-[4px] border-dotted border-rose-500/60 shadow-[0_0_80px_rgba(244,63,94,0.2)] z-0"
              />
              <motion.div 
                animate={{ scale: [1, 1.1, 1], opacity: [0.05, 0.15, 0.05] }}
                transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
                className="absolute inset-[-40px] lg:inset-[-65px] xl:inset-[-85px] rounded-full bg-gradient-to-tr from-orange-400 to-rose-400 blur-[80px] z-[-1]"
              />
              
              <div className="relative z-10 glass p-2 lg:p-3 rounded-[3.8rem] md:rounded-[4.8rem] border border-white/80 shadow-2xl bg-white/40 backdrop-blur-3xl overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-tr from-orange-500/15 to-rose-500/15 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
                <img 
                  src={settings.hero_image || "https://cdn-icons-png.flaticon.com/512/3135/3135715.png"} 
                  alt="Hero" 
                  className="w-[280px] sm:w-[320px] md:w-[400px] lg:w-[460px] xl:w-[500px] h-auto rounded-[3.5rem] md:rounded-[4.5rem] shadow-2xl transform group-hover:scale-[1.01] transition-all duration-700 object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </motion.div>
          </div>
        </div>
        <MouseScrollIcon />
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AdComponent />
      </div>

      {/* Stats Section */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="py-12 relative overflow-hidden"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
            {[
              { label: settings.stat_1_label || "Success Rate", value: settings.stat_1_value || "95%", icon: Award, color: "orange", gradient: "from-orange-50 to-white" },
              { label: settings.stat_2_label || "Expert Mentors", value: settings.stat_2_value || "4+", icon: GraduationCap, color: "blue", gradient: "from-blue-50 to-white" },
              { label: settings.stat_3_label || "Study Materials", value: settings.stat_3_value || "500+", icon: BookOpen, color: "emerald", gradient: "from-emerald-50 to-white" },
              { label: settings.stat_4_label || "Math Labs", value: settings.stat_4_value || "Online", icon: FlaskConical, color: "rose", gradient: "from-rose-50 to-white" }
            ].map((stat, i) => (
              <motion.div
                key={i}
                whileHover={{ y: -10, scale: 1.02 }}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`relative overflow-hidden p-8 rounded-[3rem] bg-white border border-slate-100 shadow-2xl shadow-slate-200/60 group text-center transform transition-all duration-500`}
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.gradient} opacity-40 group-hover:opacity-100 transition-opacity duration-500`} />
                <div className="relative z-10">
                  <div className={`w-20 h-20 mx-auto rounded-3xl bg-white shadow-xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:rotate-12 transition-all duration-500 text-${stat.color}-600 border border-slate-50`}>
                    <stat.icon className="h-10 w-10" />
                  </div>
                  <div className="text-4xl md:text-5xl font-black text-slate-900 mb-2 tracking-tighter">{stat.value}</div>
                  <div className="text-xs font-black text-slate-400 uppercase tracking-[0.25em]">{stat.label}</div>
                </div>
                
                {/* Decorative Element */}
                <div className={`absolute -right-6 -bottom-6 w-32 h-32 bg-${stat.color}-500/10 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-1000`} />
              </motion.div>
            ))}
          </div>

          {/* Mobile Jaber Tube Button */}
          <div className="mt-8 flex justify-center lg:hidden px-4">
            <Link to={settings.jaber_tube_link || "/video-library"} className="w-full sm:w-auto bg-orange-600 text-white px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-orange-700 transition-all shadow-xl shadow-orange-600/20 flex items-center justify-center gap-2 group active:scale-95">
              {settings.jaber_tube_text || "Jaber Math Care Tube"}
              <Youtube className="h-5 w-5 group-hover:scale-110 transition-transform" />
            </Link>
          </div>
        </div>
      </motion.section>

      {settings.app_download_link && (
        <motion.section 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="py-10 md:py-24 bg-white relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-orange-100 rounded-full blur-[100px] opacity-60"></div>
          <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-96 h-96 bg-blue-100 rounded-full blur-[100px] opacity-60"></div>
          
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-[2rem] md:rounded-[3rem] p-6 md:p-16 shadow-[0_20px_50px_-12px_rgba(0,0,0,0.3)] overflow-hidden relative flex flex-col md:flex-row items-center justify-between gap-6 md:gap-12">
              <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-gradient-to-br from-orange-500/20 to-transparent rounded-full translate-x-1/3 -translate-y-1/3 blur-3xl pointer-events-none"></div>
              
              <div className="flex-1 space-y-4 md:space-y-6 text-center md:text-left relative z-10 w-full">
                <div className="inline-flex items-center gap-2 px-3 md:px-5 py-1.5 md:py-2.5 rounded-full bg-white/10 border border-white/20 text-orange-400 text-[10px] md:text-xs font-black uppercase tracking-widest backdrop-blur-md">
                  <SquareRadical className="h-3 w-3 md:h-4 md:w-4" /> Official Mobile App
                </div>
                <h2 className="text-2xl md:text-5xl font-black text-white tracking-tight leading-tight">
                  Take Jaber Math Care <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-amber-300">Anywhere</span>
                </h2>
                <p className="text-slate-300 font-medium max-w-xl text-sm md:text-xl leading-relaxed mx-auto md:mx-0">
                  Never miss an update. Get instant access to live classes, study materials, notices, and your class routines directly from your phone.
                </p>
                <div className="pt-2 md:pt-6 pb-2">
                  <a href={settings.app_download_link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center w-full sm:w-auto gap-3 bg-gradient-to-r from-orange-500 to-orange-600 text-white px-6 md:px-8 py-3 md:py-4 rounded-2xl font-black text-xs md:text-sm uppercase tracking-widest hover:from-orange-400 hover:to-orange-500 transition-all shadow-[0_10px_30px_-10px_rgba(249,115,22,0.5)] active:scale-95 group">
                    <Download className="h-4 w-4 md:h-5 md:w-5 group-hover:-translate-y-1 transition-transform" />
                    Download Now
                  </a>
                </div>
              </div>

              <div className="relative z-10 shrink-0 hidden sm:block">
                <div className="absolute inset-0 bg-gradient-to-tr from-orange-500 to-amber-300 blur-2xl opacity-40 rounded-[3rem] animate-pulse"></div>
                <div className="bg-white p-4 md:p-6 rounded-[2rem] md:rounded-[2.5rem] shadow-2xl relative transform md:rotate-3 hover:rotate-0 transition-transform duration-500 group">
                  <div className="absolute -top-4 -right-2 md:-right-6 bg-orange-500 text-white text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-full shadow-lg transform rotate-12 group-hover:rotate-6 transition-transform">
                    Scan Me
                  </div>
                  <QRCodeSVG value={settings.app_download_link} size={150} level="H" includeMargin={false} className="rounded-2xl" />
                  <div className="mt-4 md:mt-6 flex items-center justify-center gap-2 text-slate-500">
                    <span className="text-[10px] md:text-xs font-black uppercase tracking-widest text-slate-900">Install via Chrome / Android</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.section>
      )}

      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="py-24 relative bg-white"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-20 space-y-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="inline-block px-4 py-2 rounded-full bg-slate-100 text-slate-600 text-xs font-black uppercase tracking-widest"
            >
              Our Excellence
            </motion.div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-orange-600 tracking-tighter leading-none whitespace-nowrap">
              Why Choose Us
            </h2>
            <p className="text-slate-500 font-medium text-lg">
              We provide a comprehensive learning ecosystem designed for success.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: Users, title: "Expert Teachers", desc: "Learn from highly qualified educators with years of teaching experience.", color: "orange" },
              { icon: BookOpen, title: "Proven Curriculum", desc: "Structured learning path with comprehensive study materials and practice sets.", color: "blue" },
              { icon: Award, title: "Regular Exams", desc: "Weekly and monthly assessments to ensure continuous improvement.", color: "emerald" },
              { icon: BarChart2, title: "Progress Tracking", desc: "Regular assessments and detailed progress reports to monitor improvement.", color: "rose" },
              { icon: User, title: "Personal Care", desc: "Individual attention to every student's needs for better understanding.", color: "purple" },
              { icon: Zap, title: "Interactive Classes", desc: "Engaging learning environment with real-world examples and experiments.", color: "amber" },
              { icon: Info, title: "Doubt Clearing", desc: "Dedicated sessions to solve every query instantly and effectively.", color: "indigo" },
              { icon: PlayCircle, title: "Digital Resources", desc: "Access to recorded lectures and PDF notes 24/7 from anywhere.", color: "cyan" },
              { icon: Magnet, title: "Conceptual Clarity", desc: "Deep dive into math concepts to build a strong foundation.", color: "orange" }
            ].map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group relative p-10 rounded-[3rem] bg-slate-50 hover:bg-white border border-transparent hover:border-orange-100 transition-all duration-500 hover:shadow-2xl hover:shadow-orange-900/5"
              >
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-8 shadow-lg group-hover:scale-110 transition-transform duration-500 bg-${feature.color}-100 text-${feature.color}-600`}>
                  <feature.icon className="h-8 w-8" />
                </div>
                <h4 className="text-2xl font-black text-slate-900 mb-4 tracking-tight group-hover:text-orange-600 transition-colors">{feature.title}</h4>
                <p className="text-slate-600 font-medium leading-relaxed">{feature.desc}</p>
                
                <div className="absolute top-8 right-8 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className={`w-2 h-2 rounded-full bg-${feature.color}-500 animate-ping`} />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>


      {/* Reviews Section */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="py-24 bg-slate-50/50"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="inline-block px-4 py-2 rounded-full bg-orange-100 text-orange-600 text-xs font-black uppercase tracking-widest"
            >
              Testimonials
            </motion.div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-orange-600 tracking-tighter leading-none">
              What Our Students Say
            </h2>
            <p className="text-slate-500 font-medium text-lg">
              Real stories from students who have transformed their math journey with us.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            <StudentReviewsList />
          </div>

          <div className="flex justify-center mt-16">
            <Link 
              to="/reviews" 
              className="glass px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-widest text-slate-900 border border-white/60 shadow-xl hover:bg-white/60 transition-all flex items-center gap-3 group"
            >
              View All Reviews
              <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </motion.section>

      {/* CTA Section */}
      <motion.section 
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="py-24"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass p-12 md:p-12 lg:p-20 rounded-[4rem] border border-white/60 shadow-[0_32px_64px_-12px_rgba(249,115,22,0.2)] bg-gradient-to-br from-orange-600 to-rose-600 text-center text-white relative overflow-hidden"
          >
            <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]" />
            <div className="relative z-10 max-w-3xl mx-auto space-y-10">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-black tracking-tighter leading-tight">
                Ready to Excel in Mathematics? <br />
                Join Us <span className="text-orange-200">Today!</span>
              </h2>
              <p className="text-xl text-orange-100 font-medium">
                Join thousands of successful students and master mathematics with expert guidance. Start your journey towards academic excellence now.
              </p>
              <div className="flex flex-wrap justify-center gap-6">
                <Link 
                  to="/contact" 
                  className="bg-white text-orange-600 px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-orange-50 transition-all shadow-2xl hover:scale-105 active:scale-95 flex items-center gap-3"
                >
                  Contact Us Now
                  <ArrowRight className="h-5 w-5" />
                </Link>
                <Link 
                  to="/programs" 
                  className="bg-black/20 backdrop-blur-md text-white border border-white/30 px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-black/30 transition-all flex items-center gap-3"
                >
                  View Programs
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </motion.section>
      <FloatingNoticePopup />
    </div>
  );
};

export default Home;
