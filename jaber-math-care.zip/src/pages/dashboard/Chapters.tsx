import React, { useEffect, useState, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { BookOpen, TrendingUp } from 'lucide-react';
import SmallLoadingSpinner from '../../components/SmallLoadingSpinner';
import { db } from '../../firebase';
import { collection, onSnapshot, query, where } from 'firebase/firestore';

const Chapters = () => {
  const { token, user } = useAuth();
  const [chapters, setChapters] = useState<any[]>([]);
  const [enrollments, setEnrollments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token || !user) return;
    
    const unsubChapters = onSnapshot(collection(db, 'chapters'), (snapshot) => {
      setChapters(snapshot.docs.map(d => ({ ...d.data(), id: d.id })));
      setLoading(false);
    });

    const unsubEnrollments = onSnapshot(
      query(collection(db, 'enrollments'), where('student_id', '==', user.id)),
      (snapshot) => {
        setEnrollments(snapshot.docs.map(d => ({ ...d.data(), id: d.id })));
      }
    );

    return () => {
      unsubChapters();
      unsubEnrollments();
    };
  }, [token, user]);

  const filteredChapters = useMemo(() => {
    if (!user) return [];
    return chapters.filter((c) => {
      // General visibility
      if (!c.program_id && !c.batch_id && !c.course_id) return true;

      if ((user as any).student_type !== "online") {
        // Offline filtering
        if (c.program_id) {
          if (String(c.program_id) !== String((user as any).program_id)) return false;
          if (c.batch_id && c.batch_id !== "all" && String(c.batch_id) !== String((user as any).batch_id)) return false;
          return true;
        }
        return false;
      } else {
        // Online filtering
        const userCourses = (user as any).enrolled_courses || [];
        const isEnrolledViaPrimary = String((user as any).course_id) === String(c.course_id);
        const isEnrolledViaProfile = userCourses.some((course: any) => 
          typeof course === 'string' ? String(course) === String(c.course_id) : String(course.id) === String(c.course_id)
        );
        const isEnrolledViaEnrollments = enrollments.some(e => 
          (e.status === "approved" || e.status === "contacted") && String(e.course_id) === String(c.course_id)
        );
        // Also show if explicitly marked for "everyone" (empty program/course)
        return isEnrolledViaPrimary || isEnrolledViaProfile || isEnrolledViaEnrollments || (!c.course_id && !c.program_id);
      }
    });
  }, [chapters, user, enrollments]);

  if (loading) return <SmallLoadingSpinner />;

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
            <div className="p-2 bg-green-100 rounded-xl">
              <BookOpen className="h-6 w-6 text-green-600" />
            </div>
            Chapters
          </h2>
          <p className="text-slate-500 mt-1 text-sm font-medium">Access your course chapters and learning materials.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredChapters.map((chapter) => (
          <div key={chapter.id} className="glass p-8 rounded-[2.5rem] border border-white/60 shadow-xl bg-white/40 hover:bg-white/60 transition-all group relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-green-500/5 rounded-full -mr-12 -mt-12 blur-2xl group-hover:bg-green-500/10 transition-colors"></div>
            
            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 rounded-2xl bg-green-100 text-green-600 shadow-lg shadow-green-100">
                <BookOpen className="h-6 w-6" />
              </div>
              <h3 className="font-black text-xl text-slate-900 tracking-tight line-clamp-1">{chapter.title}</h3>
            </div>

            <p className="text-slate-600 mb-8 line-clamp-3 font-medium leading-relaxed">{chapter.content}</p>
            
            <div className="flex justify-between items-center">
              <span className={`px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg ${
                chapter.status === 'complete' 
                  ? 'bg-green-500 text-white shadow-green-100' 
                  : chapter.status === 'active'
                  ? 'bg-blue-500 text-white shadow-blue-100'
                  : 'bg-orange-500 text-white shadow-orange-100'
              }`}>
                {chapter.status === 'complete' ? 'Completed' : chapter.status === 'active' ? 'Active' : 'Coming Soon'}
              </span>
              
              <button className="text-slate-400 hover:text-green-600 transition-colors">
                <TrendingUp className="h-5 w-5" />
              </button>
            </div>
          </div>
        ))}
        {filteredChapters.length === 0 && (
          <div className="col-span-full glass p-16 rounded-[2.5rem] border border-white/60 shadow-xl bg-white/40 text-center">
            <div className="max-w-xs mx-auto">
              <div className="p-6 bg-slate-50 rounded-full inline-block mb-4">
                <BookOpen className="h-12 w-12 text-slate-200" />
              </div>
              <h3 className="text-xl font-black text-slate-900 mb-2">No Chapters Found</h3>
              <p className="text-slate-500 font-medium">Your course chapters will appear here once they are added.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Chapters;
