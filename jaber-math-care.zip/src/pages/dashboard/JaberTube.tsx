import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Youtube, Play, Clock, Calendar, Search, Filter, ChevronRight, PlayCircle, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { safeJson } from '../../utils/api';

const JaberTube = () => {
  const { token, user } = useAuth();
  const [videos, setVideos] = useState<any[]>([]);
  const [activeEnrollments, setActiveEnrollments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedVideo, setSelectedVideo] = useState<any | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  if (!user) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-10rem)]">
        <div className="text-center">
          <h2 className="text-2xl font-black text-slate-900 mb-4">Login Required</h2>
          <p className="text-slate-500">Please log in to access Jaber Tube content.</p>
        </div>
      </div>
    );
  }

  useEffect(() => {
    fetchVideos();
    if (token) {
      fetch(`/api/my-enrollments?t=${Date.now()}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(res => res.json())
      .then(data => {
        if (!data.error) {
          setActiveEnrollments(Array.isArray(data) ? data.filter((e: any) => e.status === 'contacted' || e.status === 'approved') : []);
        }
      })
      .catch(console.error);
    }
  }, [token]);

  const fetchVideos = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/web-recorded-classes?t=' + Date.now(), {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await safeJson(res);
        setVideos(Array.isArray(data) ? data : []);
      }
    } catch (error) {
      console.error('Failed to fetch Jaber Tube videos:', error);
    } finally {
      setLoading(false);
    }
  };

  const getYoutubeId = (url: string) => {
    const regExp = /^.*(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const filteredVideos = videos.filter(v => {
    const matchesSearch = v.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          v.description?.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    // Enrollment check
    const isEnrolledInProgram = user?.program_id && String(v.program_id) === String(user.program_id);
    const isEnrolledInCourse = (user?.course_id && String(v.course_id) === String(user.course_id)) ||
                               user?.enrolled_courses?.some((c: any) => typeof c === 'string' ? String(c) === String(v.course_id) : String(c.id) === String(v.course_id));
    
    const isEnrolledInBatch = v.batch_id && v.batch_id !== 'all' && v.batch_id !== 'ALL' && (
      String(user?.batch_id) === String(v.batch_id) || 
      String(user?.batch_id_2) === String(v.batch_id) ||
      activeEnrollments?.some((e: any) => String(e.batch_id) === String(v.batch_id))
    );

    const cid = v.course_id && String(v.course_id).toUpperCase() !== 'ALL' ? v.course_id : null;
    const pid = v.program_id && String(v.program_id).toUpperCase() !== 'ALL' ? v.program_id : null;
    const bid = v.batch_id && String(v.batch_id).toUpperCase() !== 'ALL' ? v.batch_id : null;

    const isGeneralVideo = !pid && !cid && !bid;

    let matchesAccess = false;
    
    if (isGeneralVideo) {
      matchesAccess = true;
    } else if (cid) {
      matchesAccess = isEnrolledInCourse || activeEnrollments?.some((e: any) => String(e.course_id) === String(cid));
    } else if (pid) {
      const programMatches = isEnrolledInProgram || activeEnrollments?.some((e: any) => String(e.program_id) === String(pid));
      if (programMatches) {
        if (!bid) {
          matchesAccess = true;
        } else {
          matchesAccess = Boolean(isEnrolledInBatch);
        }
      }
    }

    return matchesAccess;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-10rem)]">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 border-4 border-orange-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-500 font-bold animate-pulse">Loading Jaber Tube...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-20">
      {/* Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight flex items-center gap-3">
            <div className="bg-red-600 p-2 rounded-xl shadow-lg shadow-red-600/20">
              <Youtube className="h-8 w-8 text-white" />
            </div>
            Jaber Tube
          </h1>
          <p className="text-slate-500 mt-2 font-medium text-lg">Premium recorded classes for your excellence.</p>
        </div>

        <div className="relative w-full md:w-96 group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 group-focus-within:text-orange-600 transition-colors" />
          <input 
            type="text"
            placeholder="Search classes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-slate-200 rounded-2xl pl-12 pr-4 py-3 text-slate-900 focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 transition-all shadow-sm"
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {filteredVideos.map((video, index) => {
          const videoId = getYoutubeId(video.url);
          return (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              whileHover={{ y: -8 }}
              onClick={() => setSelectedVideo(video)}
              className="group cursor-pointer"
            >
              <div className="relative aspect-video rounded-[2.5rem] overflow-hidden shadow-xl border border-white/60 bg-slate-100 mb-4">
                {videoId ? (
                  <img 
                    src={`https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`}
                    alt={video.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`;
                    }}
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center bg-slate-900">
                    <Youtube className="h-12 w-12 text-slate-700" />
                  </div>
                )}
                <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100 duration-300">
                  <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center border border-white/30 transform scale-75 group-hover:scale-100 transition-transform duration-500">
                    <Play className="h-8 w-8 text-white fill-white" />
                  </div>
                </div>
                <div className="absolute bottom-4 right-4 bg-black/80 backdrop-blur-md text-white text-[10px] font-black px-3 py-1 rounded-lg uppercase tracking-widest">
                  Recorded
                </div>
              </div>
              
              <div className="px-2">
                <h3 className="text-xl font-black text-slate-900 group-hover:text-orange-600 transition-colors line-clamp-2 leading-tight mb-2">
                  {video.title}
                </h3>
                <div className="flex items-center gap-4 text-slate-400">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="h-3.5 w-3.5" />
                    <span className="text-[10px] font-black uppercase tracking-widest">
                      {new Date(video.created_at || Date.now()).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5" />
                    <span className="text-[10px] font-black uppercase tracking-widest">Premium</span>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}

        {filteredVideos.length === 0 && (
          <div className="col-span-full py-20 text-center glass rounded-[3rem] border-dashed border-2 border-slate-200">
            <div className="bg-slate-50 w-24 h-24 rounded-[2rem] flex items-center justify-center mx-auto mb-6 shadow-inner">
              <Youtube className="h-12 w-12 text-slate-200" />
            </div>
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">No Classes Found</h3>
            <p className="text-slate-500 mt-2 font-medium">Try searching with different keywords or check back later.</p>
          </div>
        )}
      </div>

      {/* Video Player Modal */}
      <AnimatePresence>
        {selectedVideo && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 md:p-10 bg-slate-950/95 backdrop-blur-xl"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="w-full max-w-6xl aspect-video relative rounded-[3rem] overflow-hidden shadow-[0_0_100px_rgba(249,115,22,0.2)] border border-white/10"
            >
              <button 
                onClick={() => setSelectedVideo(null)}
                className="absolute top-6 right-6 z-10 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white p-3 rounded-2xl transition-all border border-white/10 hover:scale-110 active:scale-90"
              >
                <X className="h-6 w-6" />
              </button>
              
              <iframe 
                src={`https://www.youtube.com/embed/${getYoutubeId(selectedVideo.url)}?autoplay=1&rel=0&modestbranding=1&showinfo=0`}
                className="w-full h-full"
                allowFullScreen
                allow="autoplay"
              />

              <div className="absolute bottom-0 left-0 right-0 p-10 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent pointer-events-none">
                <h2 className="text-3xl font-black text-white mb-2 tracking-tight">{selectedVideo.title}</h2>
                <p className="text-slate-400 font-medium line-clamp-2 max-w-3xl">{selectedVideo.description}</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default JaberTube;
