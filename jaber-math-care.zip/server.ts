import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import admin from 'firebase-admin';
import { getFirestore } from 'firebase-admin/firestore';
import fs from 'fs';
import nodemailer from 'nodemailer';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Firebase Admin
const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf-8'));

if (!admin.apps.length) {
  admin.initializeApp({
    projectId: firebaseConfig.projectId
  });
  console.log(`Firebase Admin initialized for project: ${firebaseConfig.projectId}`);
}

let db: admin.firestore.Firestore;
try {
  const dbId = firebaseConfig.firestoreDatabaseId && firebaseConfig.firestoreDatabaseId !== '(default)'
    ? firebaseConfig.firestoreDatabaseId
    : undefined;

  if (dbId) {
    console.log('Using named database:', dbId);
    db = getFirestore(admin.app(), dbId);
  } else {
    console.log('Using default database');
    db = getFirestore(admin.app());
  }
  
  // Test connection
  db.collection('test').doc('connection').set({ 
    last_verified: new Date().toISOString()
  }, { merge: true })
    .then(async () => {
      console.log('Firestore connection verified.');
      try {
        const emailDoc = await db.collection('settings').doc('smtp_email').get();
        const passDoc = await db.collection('settings').doc('smtp_password').get();
        
        const targetEmail = 'jaberbhai69@gmail.com';
        const targetPassValue = 'qkecrqatjnkmfurs';

        if (!emailDoc.exists || emailDoc.data()?.value !== targetEmail) {
          await db.collection('settings').doc('smtp_email').set({ value: targetEmail }, { merge: true });
          console.log('[SMTP Init] Auto-configured smtp_email to jaberbhai69@gmail.com');
        }
        if (!passDoc.exists || passDoc.data()?.value !== targetPassValue) {
          await db.collection('settings').doc('smtp_password').set({ value: targetPassValue }, { merge: true });
          console.log('[SMTP Init] Auto-configured smtp_password key to qkecrqatjnkmfurs');
        }
      } catch (e: any) {
        console.error('[SMTP Init] Failed to auto-configure SMTP settings:', e.message);
      }
    })
    .catch(err => console.warn('Firestore test failed:', err.message));

} catch (error) {
  console.error('Critical error initializing Firestore SDK:', error);
  db = admin.firestore();
}

// Cascading delete helper functions
async function deleteStudentData(studentId: string) {
  try {
    const payments = await db.collection('payments').where('student_id', '==', studentId).get();
    for (const doc of payments.docs) {
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error('Failed to delete payments for student:', studentId, e);
  }

  try {
    const attendance = await db.collection('attendance').where('student_id', '==', studentId).get();
    for (const doc of attendance.docs) {
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error('Failed to delete attendance for student:', studentId, e);
  }

  try {
    const results = await db.collection('results').where('student_id', '==', studentId).get();
    for (const doc of results.docs) {
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error('Failed to delete results for student:', studentId, e);
  }

  try {
    const enrollments = await db.collection('enrollments').where('user_id', '==', studentId).get();
    for (const doc of enrollments.docs) {
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error('Failed to delete enrollments for student:', studentId, e);
  }
}

async function deleteBatchData(batchId: string) {
  try {
    const students = await db.collection('users').where('batch_id', '==', batchId).get();
    for (const doc of students.docs) {
      try {
        await admin.auth().deleteUser(doc.id).catch(() => {});
        await deleteStudentData(doc.id);
        await doc.ref.delete();
      } catch (e) {
        console.error('Failed to recursively delete student under batch:', doc.id, e);
      }
    }

    const students2 = await db.collection('users').where('batch_id_2', '==', batchId).get();
    for (const doc of students2.docs) {
      try {
        await admin.auth().deleteUser(doc.id).catch(() => {});
        await deleteStudentData(doc.id);
        await doc.ref.delete();
      } catch (e) {
        console.error('Failed to recursively delete student_2 under batch:', doc.id, e);
      }
    }
  } catch (e) {
    console.error('Failed to process student deletion under batch:', batchId, e);
  }

  try {
    const exams = await db.collection('exams').where('batch_id', '==', batchId).get();
    for (const doc of exams.docs) {
      try {
        const results = await db.collection('results').where('exam_id', '==', doc.id).get();
        for (const rDoc of results.docs) {
          await rDoc.ref.delete().catch(() => {});
        }
        await doc.ref.delete().catch(() => {});
      } catch (examErr) {
        console.error('Failed to cascade delete exam results:', doc.id, examErr);
      }
    }
  } catch (e) {
    console.error('Failed to process exams under batch:', batchId, e);
  }

  const batchIdColls = [
    'attendance', 'payments', 'live_classes', 'notices',
    'video_classes', 'class_slides', 'routines'
  ];
  for (const col of batchIdColls) {
    try {
      const items = await db.collection(col).where('batch_id', '==', batchId).get();
      for (const doc of items.docs) {
        await doc.ref.delete().catch(() => {});
      }
    } catch (e) {
      console.error(`Failed to delete col ${col} items under batch ${batchId}:`, e);
    }
  }
}

async function deleteProgramData(programId: string) {
  try {
    const batches = await db.collection('batches').where('program_id', '==', programId).get();
    for (const doc of batches.docs) {
      await deleteBatchData(doc.id);
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error('Failed to process batches cascading deletion under program:', programId, e);
  }

  try {
    const students = await db.collection('users').where('program_id', '==', programId).get();
    for (const doc of students.docs) {
      try {
        await admin.auth().deleteUser(doc.id).catch(() => {});
        await deleteStudentData(doc.id);
        await doc.ref.delete();
      } catch (e) {
        console.error('Failed to recursively delete student under program:', doc.id, e);
      }
    }
  } catch (e) {
    console.error('Failed to process students under program:', programId, e);
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ limit: '50mb', extended: true }));

  // Basic Security Headers to prevent hacking/inspection
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    next();
  });

  // Disable caching globally for all routes
  app.use((req, res, next) => {
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.set('Pragma', 'no-cache');
    res.set('Expires', '0');
    res.set('Surrogate-Control', 'no-store');
    next();
  });

  // Middleware to verify Firebase ID Token
  const authenticate = async (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      console.log(`[AUTH] Missing or invalid Authorization header from ${req.method} ${req.url}`);
      return res.status(401).json({ error: 'Unauthorized', details: 'Missing Authorization header' });
    }
    const idToken = authHeader.split('Bearer ')[1];
    try {
      // Use the default admin app for verification
      const decodedToken = await admin.auth().verifyIdToken(idToken);
      const email = (decodedToken.email || '').toLowerCase();
      console.log(`[AUTH] Authenticated: ${email}`);
      req.user = decodedToken;
      
      const userDoc = await db.collection('users').doc(decodedToken.uid).get();
      const adminEmails = [
        'jabermathcare@gmail.com', 
        'contact.jabermathcare@gmail.com'
      ].map(e => e.toLowerCase());

      if (adminEmails.includes(email)) {
        req.user.role = 'admin';
        if (!userDoc.exists || userDoc.data()?.role !== 'admin') {
          await db.collection('users').doc(decodedToken.uid).set({
            email: decodedToken.email,
            name: decodedToken.name || 'Admin',
            role: 'admin',
            updated_at: new Date().toISOString()
          }, { merge: true });
        }
      } else if (email === 'mdabudarda2012@gmail.com') {
        req.user.role = 'student';
        if (userDoc.exists && userDoc.data()?.role === 'admin') {
          await db.collection('users').doc(decodedToken.uid).update({ role: 'student' });
        }
      } else if (userDoc.exists) {
        req.user.role = userDoc.data()?.role;
      }
 else {
        req.user.role = 'student';
      }
      next();
    } catch (error: any) {
      console.error(`[AUTH] Error verifying token:`, error.message);
      res.status(401).json({ error: 'Unauthorized', details: error.message });
    }
  };

  // Robust SMTP Helper with Fallbacks and TLS Support
  const sendSmtpEmail = async ({
    to,
    subject,
    html,
    fromName = 'JaberMath Care',
    smtp_email,
    smtp_password
  }: {
    to: string;
    subject: string;
    html: string;
    fromName?: string;
    smtp_email?: string;
    smtp_password?: string;
  }) => {
    // Restrict strictly to gmail.com addresses as requested
    if (!to || !to.trim().toLowerCase().endsWith('@gmail.com')) {
      console.log(`[SMTP Helper] Skipping email to ${to || 'EMPTY'} because it is not a Gmail (@gmail.com) address.`);
      return { success: true, skipped: true, reason: 'Recipient is not a Gmail address' };
    }

    let emailUser = smtp_email;
    let emailPass = smtp_password;

    if (!emailUser || !emailPass) {
      // Load from database if not supplied
      const settingsSnap = await db.collection('settings').get();
      const settings: any = {};
      settingsSnap.forEach(doc => { settings[doc.id] = doc.data().value; });
      emailUser = settings.smtp_email;
      emailPass = settings.smtp_password;
      if (settings.site_name) fromName = settings.site_name;
    }

    if (!emailUser || !emailPass) {
      console.log(`[SMTP Helper] SMTP not configured. Action rejected.`);
      throw new Error("SMTP settings (Sender Email and App Password) are not configured. Please fill and save them in the Settings tab.");
    }

    const trimmedUser = emailUser.trim();
    // Gmail App Password contains spaces when displayed by Google (e.g. "abcd efgh ijkl mnop").
    // We strictly remove all inner spaces so it doesn't cause authentication failures.
    const trimmedPass = emailPass.trim().replace(/\s+/g, '');

    console.log(`[SMTP Helper] Initiating sending process to ${to} from ${trimmedUser}`);

    // Option A: Try standard Secure SSL Port 465 (Gmail recommended) with short 6-second timeout
    try {
      console.log(`[SMTP Helper] Attempting Port 465 (SSL/TLS) for user ${trimmedUser} with 6s timeout...`);
      const transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 465,
        secure: true,
        connectionTimeout: 6000,
        greetingTimeout: 5000,
        socketTimeout: 8000,
        auth: {
          user: trimmedUser,
          pass: trimmedPass
        },
        tls: {
          rejectUnauthorized: false
        }
      });

      await transporter.sendMail({
        from: `"${fromName}" <${trimmedUser}>`,
        to,
        subject,
        html
      });
      console.log(`[SMTP Helper] Email successfully dispatched to ${to} via Port 465!`);
      return { success: true };
    } catch (err465: any) {
      console.warn(`[SMTP Helper] Port 465 failed with error: ${err465.message || err465}. Trying Port 587 (STARTTLS) with active TLS as fallback...`);
      
      // Option B: Try STARTTLS Port 587 (Often allowed on virtual networks when 465 SSL is blocked/unresponsive)
      try {
        const transporterFallback = nodemailer.createTransport({
          host: 'smtp.gmail.com',
          port: 587,
          secure: false, // Must be false for 587
          requireTLS: true, // Force TLS
          connectionTimeout: 8000,
          greetingTimeout: 6000,
          socketTimeout: 10000,
          auth: {
            user: trimmedUser,
            pass: trimmedPass
          },
          tls: {
            rejectUnauthorized: false
          }
        });

        await transporterFallback.sendMail({
          from: `"${fromName}" <${trimmedUser}>`,
          to,
          subject,
          html
        });
        console.log(`[SMTP Helper] Email successfully dispatched to ${to} via Port 587 fallback!`);
        return { success: true };
      } catch (err587: any) {
        console.error(`[SMTP Helper] Fallback Port 587 failed too: ${err587.message || err587}`);
        throw new Error(`SMTP dispatch failed. Port 465: ${err465.message || err465} | Port 587: ${err587.message || err587}`);
      }
    }
  };

  // API Routes
  
  // Diagnostic
  app.get('/api/admin/debug-auth', authenticate, (req: any, res) => {
    res.json({
      user: req.user,
      firebaseProjectId: admin.app().options.projectId,
      configProjectId: firebaseConfig.projectId
    });
  });

  // Migration Route
  app.get('/migrate-results', async (req: any, res) => {
    try {
      const snapshot = await db.collection('results').get();
      let migrated = 0;
      for (const resultDoc of snapshot.docs) {
        const data = resultDoc.data();
        if (!data.roll_number || !data.student_name) {
           if (data.student_id) {
             const studentDoc = await db.collection('users').doc(data.student_id).get();
             if (studentDoc.exists) {
               await resultDoc.ref.update({
                  roll_number: studentDoc.data()?.roll_number || '',
                  student_name: studentDoc.data()?.name || ''
               });
               migrated++;
             }
           }
        }
      }
      res.json({ success: true, migrated });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get('/api/my-enrollments', authenticate, async (req: any, res) => {
    try {
      const email = (req.user.email || '').toLowerCase();
      const phone = req.user.phone_number || '';
      
      // Get approved enrollments for this user
      const snapshot = await db.collection('enrollments')
        .where('user_id', '==', req.user.uid)
        .get();
      
      let enrollments = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      // Also search by email/phone if user_id is missing (legacy/virtual enrollments)
      if (email || phone) {
        let q: any = db.collection('enrollments');
        const legacySnapshot = await q.get();
        const extra = legacySnapshot.docs
          .map((doc: any) => ({ id: doc.id, ...doc.data() }))
          .filter((e: any) => 
            !enrollments.find(existing => existing.id === e.id) &&
            ((email && e.email?.toLowerCase() === email) || (phone && e.phone === phone))
          );
        enrollments = [...enrollments, ...extra];
      }

      res.json(enrollments);
    } catch (error) {
      console.error('Error fetching my-enrollments:', error);
      res.status(500).json({ error: 'Failed to fetch enrollments' });
    }
  });

  // Auth Profile
  app.get('/api/auth/profile', authenticate, async (req: any, res) => {
    try {
      const userDoc = await db.collection('users').doc(req.user.uid).get();
      if (!userDoc.exists) return res.status(404).json({ error: 'User not found' });
      const data = userDoc.data();
      if (req.user.email === 'mdabudarda2012@gmail.com' && data.role !== 'student') {
        await db.collection('users').doc(req.user.uid).update({ role: 'student' });
        data.role = 'student';
      }
      res.json({ id: userDoc.id, ...data });
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch profile' });
    }
  });

  // Messages
  app.get('/api/messages', authenticate, async (req, res) => {
    try {
      const snapshot = await db.collection('messages').orderBy('created_at', 'desc').get();
      const messages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch messages' });
    }
  });

  // Settings
  app.get('/api/settings', async (req, res) => {
    try {
      const snapshot = await db.collection('settings').get();
      const settings: any = {};
      snapshot.forEach(doc => {
        settings[doc.id] = doc.data().value;
      });
      res.json(settings);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: String(error) });
    }
  });

  app.get('/api/public/settings', async (req, res) => {
    try {
      const snapshot = await db.collection('settings').get();
      const settings: any = {};
      snapshot.forEach(doc => {
        settings[doc.id] = doc.data().value;
      });
      res.json(settings);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: String(error) });
    }
  });

  app.post('/api/settings', authenticate, async (req, res) => {
    try {
      const { key, value } = req.body;
      if (!key) return res.status(400).json({ error: 'Key is required' });
      
      let cleanValue = value;
      if (key === 'smtp_password' && typeof value === 'string') {
        cleanValue = value.replace(/\s+/g, '');
      } else if (key === 'smtp_email' && typeof value === 'string') {
        cleanValue = value.trim();
      }

      await db.collection('settings').doc(key).set({ value: cleanValue }, { merge: true });
      res.json({ success: true, value: cleanValue });
    } catch (error) {
      console.error('Error saving settings:', error);
      res.status(500).json({ error: 'Failed to save settings' });
    }
  });

  // Special handling for enrollments (public for guests)
  app.post('/api/enrollments', async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ['image_url', 'profile_pic', 'student_image']) {
          if (typeof parsed[key] === 'string' && parsed[key].includes('drive.google.com')) {
            const match = parsed[key].match(/drive\.google\.com\/file\/d\/([^\/]+)/);
            if (match && match[1]) {
              parsed[key] = `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };

      req.body = sanitizeUrls(req.body);
      const { email, gmail, password, phone, name, profile_pic, ...rest } = req.body;
      const userEmail = email || gmail;
      let uid = null;

      if (userEmail && password) {
        try {
          const userRecord = await admin.auth().createUser({
            email: userEmail.trim(),
            password: password,
            displayName: name
          });
          uid = userRecord.uid;
          
          await db.collection('users').doc(uid).set({
            ...rest,
            name,
            email: userEmail.trim(),
            phone,
            role: 'student',
            status: 'pending',
            student_type: req.body.student_type || (req.body.course_title ? 'online' : 'offline'),
            profile_pic: profile_pic || '',
            created_at: new Date().toISOString()
          });
        } catch (authError: any) {
          if (authError.code === 'auth/email-already-in-use') {
            try {
              const userRecord = await admin.auth().getUserByEmail(userEmail.trim());
              uid = userRecord.uid;
            } catch (e) {
              // ignore
            }
          } else {
            console.error('Auth error during enrollment:', authError);
          }
        }
      }

      const enrollmentData = {
        ...req.body,
        user_id: uid,
        status: 'pending',
        created_at: new Date().toISOString()
      };
      
      const docRef = await db.collection('enrollments').add(enrollmentData);
      res.json({ id: docRef.id, ...enrollmentData });
    } catch (error) {
      console.error('Enrollment error:', error);
      res.status(500).json({ error: 'Failed to process enrollment' });
    }
  });

  // Special handling for messages (public for guests)
  app.post('/api/messages', async (req, res) => {
    try {
      const data = { ...req.body, created_at: new Date().toISOString() };
      await db.collection('messages').add(data);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to send message' });
    }
  });
  app.get('/api/students', authenticate, async (req, res) => {
    try {
      let query: any = db.collection('users').where('role', '==', 'student');
      Object.keys(req.query).forEach(key => {
        if (key !== 't') query = query.where(key, '==', req.query[key]);
      });
      const snapshot = await query.get();
      res.json(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch students' });
    }
  });

  app.get('/api/students/:id', authenticate, async (req, res) => {
    try {
      const doc = await db.collection('users').doc(req.params.id).get();
      if (!doc.exists) return res.status(404).json({ error: 'Not found' });
      let data: any = { id: doc.id, ...doc.data() };

      const [attendance, payments, results, enrollments] = await Promise.all([
        db.collection('attendance').where('student_id', '==', doc.id).get(),
        db.collection('payments').where('student_id', '==', doc.id).get(),
        db.collection('results').where('student_id', '==', doc.id).get(),
        db.collection('enrollments').where('user_id', '==', doc.id).get()
      ]);

      data = {
        ...data,
        attendance: attendance.docs.map(d => ({ id: d.id, ...d.data() })),
        payments: payments.docs.map(d => ({ id: d.id, ...d.data() })),
        results: results.docs.map(d => ({ id: d.id, ...d.data() })),
        enrolled_courses: enrollments.docs.map(d => ({ id: d.id, ...d.data() }))
      };
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch student details' });
    }
  });

  app.post('/api/students', authenticate, async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ['image_url', 'profile_pic', 'student_image']) {
          if (typeof parsed[key] === 'string' && parsed[key].includes('drive.google.com')) {
            const match = parsed[key].match(/drive\.google\.com\/file\/d\/([^\/]+)/);
            if (match && match[1]) {
              parsed[key] = `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };
      req.body = sanitizeUrls(req.body);
      const { email, password, name, enrollment_id, ...rest } = req.body;
      if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
      
      let uid = '';
      try {
        const userRecord = await admin.auth().createUser({
          email: email.trim(),
          password,
          displayName: name
        });
        uid = userRecord.uid;
      } catch (err: any) {
        if (err.code === 'auth/email-already-exists' || err.code === 'auth/email-already-in-use') {
          const userRecord = await admin.auth().getUserByEmail(email.trim());
          uid = userRecord.uid;
          await admin.auth().updateUser(uid, { password, displayName: name });
        } else {
          throw err;
        }
      }
      
      const userData = {
        ...rest,
        name,
        email: email.trim(),
        role: 'student',
        status: 'approved',
        initial_password: password,
        created_at: rest.created_at || rest.admission_date || rest.date_of_admission || new Date().toISOString()
      };
      await db.collection('users').doc(uid).set(userData, { merge: true });

      // Automatically record initial payment as admission fee if paid_amount is provided
      const paidAmountNum = Number(rest.paid_amount || 0);
      if (paidAmountNum > 0) {
        let batchName = "";
        let programId = rest.program_id || "";
        if (rest.batch_id) {
          try {
            const batchDoc = await db.collection('batches').doc(rest.batch_id).get();
            if (batchDoc.exists) {
              batchName = batchDoc.data()?.name || "";
              if (!programId) {
                programId = batchDoc.data()?.program_id || "";
              }
            }
          } catch (batchErr) {
            console.warn('Failed to fetch batch details for payment record:', batchErr);
          }
        }
        
        const now = new Date();
        const paymentDoc = {
          amount: paidAmountNum,
          type: "admission",
          date: now.toISOString().split('T')[0],
          month: rest.admission_month || now.toLocaleString('en-US', { month: 'long' }),
          year: now.getFullYear().toString(),
          status: "approved",
          student_id: uid,
          student_name: name,
          roll_number: rest.roll_number || "",
          batch_id: rest.batch_id || "",
          batch_name: batchName,
          program_id: programId,
          email: email.trim(),
          phone: rest.phone || "",
          payment_method: "Cash",
          method: "Cash",
          created_at: now.toISOString()
        };
        try {
          await db.collection('payments').add(paymentDoc);
        } catch (paymentErr) {
          console.error('Failed to auto-record admission payment:', paymentErr);
        }
      }
      
      if (enrollment_id) {
        try {
          await db.collection('enrollments').doc(enrollment_id).update({
            status: 'approved',
            user_id: uid
          });
        } catch (e) {
          console.warn('Failed to update enrollment:', e);
        }
      }

      // Dispatch welcome email via SMTP
      if (email && email.trim()) {
        try {
          await sendSmtpEmail({
            to: email.trim(),
            subject: 'ভর্তি সম্পন্ন হয়েছে - জাবেরম্যাথ কেয়ার',
            html: `
              <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
                <h2 style="color: #16a34a;">স্বাগতম!</h2>
                <p>প্রিয় ${name || 'শিক্ষার্থী'},</p>
                <p>আপনার <strong>${rest.course_title || rest.program_title || 'আমাদের প্রোগ্রাম'}</strong>-এ ভর্তি সফলভাবে সম্পন্ন হয়েছে।</p>
                <p>আপনি এখন আপনার ইমেইল এবং পাসওয়ার্ড ব্যবহার করে আমাদের ওয়েবসাইটে লগইন করতে পারবেন।</p>
                <div style="margin: 20px 0; padding: 15px; background: #f0fdf4; border-radius: 8px; border-left: 5px solid #16a34a;">
                  <p style="margin: 0;"><strong>আপনার লগইন ইমেইল:</strong> ${email.trim()}</p>
                  <p style="margin: 5px 0 0 0;"><strong>আপনার পাসওয়ার্ড:</strong> ${password}</p>
                  ${rest.roll_number ? `<p style="margin: 5px 0 0 0;"><strong>রোল নম্বর:</strong> ${rest.roll_number}</p>` : ''}
                  <p style="margin: 5px 0 0 0;"><strong>প্রোগ্রাম:</strong> ${rest.course_title || rest.program_title || 'N/A'}</p>
                </div>
                <p>শুভেচ্ছান্তে,<br/>জাবেরম্যাথ কেয়ার টিম</p>
              </div>
            `
          });
        } catch (emailErr) {
          console.error("Failed to send welcome email to student:", emailErr);
        }
      }
      
      res.json({ id: uid, ...userData });
    } catch (error: any) {
      console.error('Error creating student:', error);
      res.status(500).json({ error: error.message || 'Failed to create student' });
    }
  });

  app.put('/api/students/:id', authenticate, async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ['image_url', 'profile_pic', 'student_image']) {
          if (typeof parsed[key] === 'string' && parsed[key].includes('drive.google.com')) {
            const match = parsed[key].match(/drive\.google\.com\/file\/d\/([^\/]+)/);
            if (match && match[1]) {
              parsed[key] = `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };

      const payload = sanitizeUrls(req.body);
      const { password, confirmPassword, ...updateData } = payload;
      
      // If a new password is provided during update, update it in Auth
      if (password && password.length >= 6) {
        try {
          await admin.auth().updateUser(req.params.id, { password });
          updateData.initial_password = password; // Optional: keep record of latest password if they want
        } catch (authErr) {
          console.warn('Could not update auth password for student update:', authErr);
          // if user doesn't exist in auth, maybe create one? 
          // usually they do, but if not we just ignore or log
        }
      }

      await db.collection('users').doc(req.params.id).update(updateData);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update student' });
    }
  });

  app.delete('/api/students/:id', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    try {
      // Also delete from Auth if possible (optional but good)
      try {
        await admin.auth().deleteUser(req.params.id);
      } catch (e) {
        console.log('User not in Auth or delete failed, proceeding with Firestore delete');
      }
      await deleteStudentData(req.params.id);
      await db.collection('users').doc(req.params.id).delete();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete student' });
    }
  });

  app.delete('/api/cancel-enrollment/:id', authenticate, async (req: any, res) => {
    try {
      const enrollmentRef = db.collection('enrollments').doc(req.params.id);
      const enrollmentDoc = await enrollmentRef.get();
      if (!enrollmentDoc.exists) return res.status(404).json({ error: 'Enrollment not found' });
      
      const enrollmentData = enrollmentDoc.data() as any;
      
      const userRef = await db.collection('users').doc(req.user.uid).get();
      const userData = userRef.exists ? userRef.data() : null;

      const isOwner = req.user.role === 'admin' || 
                      enrollmentData.user_id === req.user.uid || 
                      (userData && userData.email && enrollmentData.email === userData.email) ||
                      (userData && userData.email && enrollmentData.gmail === userData.email) ||
                      (userData && userData.phone && enrollmentData.phone === userData.phone) ||
                      (userData && userData.phone && enrollmentData.phone && userData.phone.replace(/\\D/g, "").slice(-10) === enrollmentData.phone.replace(/\\D/g, "").slice(-10));

      if (!isOwner) {
        return res.status(403).json({ error: 'Forbidden' });
      }
      if (enrollmentData.status !== 'pending' && req.user.role !== 'admin') {
        return res.status(400).json({ error: 'Only pending enrollments can be cancelled' });
      }
      
      await enrollmentRef.delete();
      res.json({ success: true });
    } catch (error) {
      console.error('Error cancelling enrollment:', error);
      res.status(500).json({ error: 'Failed to cancel application' });
    }
  });

  app.delete('/api/moderators/:id', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    try {
      await db.collection('users').doc(req.params.id).delete();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete moderator' });
    }
  });

  // Moderator CRUD
  app.get('/api/moderators', authenticate, async (req, res) => {
    try {
      const snapshot = await db.collection('users').where('role', '==', 'moderator').get();
      res.json(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch moderators' });
    }
  });

  app.post('/api/moderators', authenticate, async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ['image_url', 'profile_pic', 'student_image']) {
          if (typeof parsed[key] === 'string' && parsed[key].includes('drive.google.com')) {
            const match = parsed[key].match(/drive\.google\.com\/file\/d\/([^\/]+)/);
            if (match && match[1]) {
              parsed[key] = `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };
      req.body = sanitizeUrls(req.body);
      const { email, password, name, ...rest } = req.body;
      const userRecord = await admin.auth().createUser({
        email: email.trim(),
        password,
        displayName: name
      });
      const userData = { ...rest, name, email: email.trim(), role: 'moderator', created_at: new Date().toISOString() };
      await db.collection('users').doc(userRecord.uid).set(userData);
      res.json({ id: userRecord.uid, ...userData });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Enrollment Status & Approval
  app.put('/api/enrollments/:id/status', authenticate, async (req, res) => {
    try {
      const { status, roll_number, monthly_fee, admission_fee, batch_id } = req.body;
      const enrollmentRef = db.collection('enrollments').doc(req.params.id);
      const enrollmentDoc = await enrollmentRef.get();
      
      if (!enrollmentDoc.exists) return res.status(404).json({ error: 'Enrollment not found' });
      
      const enrollmentData = enrollmentDoc.data() || {};
      
      // Update enrollment status
      await enrollmentRef.update({ 
        status,
        updated_at: new Date().toISOString(),
        ...(roll_number && { roll_number }),
        ...(monthly_fee && { monthly_fee }),
        ...(admission_fee && { admission_fee }),
        ...(batch_id && { batch_id })
      });

      // Sync with user record
      if (status === 'approved') {
        let uid = enrollmentData.user_id;
        const userEmail = (enrollmentData.email || enrollmentData.gmail || enrollmentData.email_address || '').trim();
        
        // Try to find user by email if uid is missing or invalid
        if (!uid && userEmail) {
          const userSnap = await db.collection('users').where('email', '==', userEmail).limit(1).get();
          if (!userSnap.empty) {
            uid = userSnap.docs[0].id;
            await enrollmentRef.update({ user_id: uid });
          }
        }

        const isOnline = !!(enrollmentData.course_id || enrollmentData.course_title || enrollmentData.student_type === 'online');
        
        const updatePayload: any = { 
          status: 'approved',
          role: 'student',
          updated_at: new Date().toISOString()
        };
        
        if (roll_number) updatePayload.roll_number = roll_number;
        if (monthly_fee) updatePayload.monthly_fee = String(monthly_fee);
        if (admission_fee) updatePayload.admission_fee = String(admission_fee);
        if (batch_id) updatePayload.batch_id = String(batch_id);
        updatePayload.student_type = isOnline ? 'online' : 'offline';
        if (enrollmentData.password) {
          updatePayload.initial_password = enrollmentData.password;
        }

        if (uid) {
          const userRef = db.collection('users').doc(uid);
          const userDoc = await userRef.get();
          if (userDoc.exists) {
            const currentData = userDoc.data();
            if (enrollmentData.course_id) {
               const enrolledCourses = currentData?.enrolled_courses || [];
               if (!enrolledCourses.includes(enrollmentData.course_id)) {
                 enrolledCourses.push(enrollmentData.course_id);
               }
               updatePayload.enrolled_courses = enrolledCourses;
            }
            // Update auth password if available and they were pending
            if (currentData?.status === 'pending' && enrollmentData.password) {
               try { await admin.auth().updateUser(uid, { password: enrollmentData.password }); } catch(e) {}
            }
            await userRef.update(updatePayload);
          } else {
            // Recreate missing document
            await userRef.set({ ...enrollmentData, ...updatePayload });
          }
        } else if (userEmail) {
          // Create new user if not found
          const newUser = {
            ...enrollmentData,
            ...updatePayload,
            email: userEmail,
            student_type: isOnline ? 'online' : 'offline'
          };
          delete (newUser as any).id;
          try {
            const userRecord = await admin.auth().createUser({
              email: userEmail,
              password: enrollmentData.password || 'Student@123',
              displayName: enrollmentData.name
            });
            uid = userRecord.uid;
          } catch (authErr: any) {
            if (authErr.code === 'auth/email-already-exists') {
              const existing = await admin.auth().getUserByEmail(userEmail);
              uid = existing.uid;
            } else {
              uid = db.collection('users').doc().id;
            }
          }
          await db.collection('users').doc(uid).set(newUser, { merge: true });
          await enrollmentRef.update({ user_id: uid });
        }

        // Send Approval Notification
        if (uid) {
          await db.collection('notifications').add({
            user_id: uid,
            title: 'Admission Approved',
            message: `Congratulations! Your admission for ${enrollmentData?.course_title || enrollmentData?.program_title || 'a program'} has been approved.`,
            type: 'enrollment',
            is_read: false,
            created_at: new Date().toISOString()
          });
        }

        // Send Email over SMTP
        if (userEmail) {
          try {
            await sendSmtpEmail({
              to: userEmail,
              subject: 'ভর্তি অনুমোদিত হয়েছে - জাবেরম্যাথ কেয়ার',
              html: `
                <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
                  <h2 style="color: #16a34a;">অভিনন্দন!</h2>
                  <p>প্রিয় ${enrollmentData.name || 'শিক্ষার্থী'},</p>
                  <p>আপনার <strong>${enrollmentData.course_title || enrollmentData.program_title || 'আমাদের প্রোগ্রাম'}</strong>-এ ভর্তির আবেদনটি সফলভাবে অনুমোদিত হয়েছে।</p>
                  <p>আপনি এখন আপনার ইমেইল এবং পাসওয়ার্ড ব্যবহার করে স্টুডেন্ট ড্যাশবোর্ডে লগইন করতে পারবেন।</p>
                  <div style="margin: 20px 0; padding: 15px; background: #f0fdf4; border-radius: 8px; border-left: 5px solid #16a34a;">
                    <p style="margin: 0;"><strong>প্রোগ্রাম:</strong> ${enrollmentData.course_title || enrollmentData.program_title || 'N/A'}</p>
                    ${roll_number ? `<p style="margin: 5px 0 0 0;"><strong>রোল নম্বর:</strong> ${roll_number}</p>` : ''}
                  </div>
                  <p>শুভেচ্ছান্তে,<br/>জাবেরম্যাথ কেয়ার টিম</p>
                </div>
              `
            });
          } catch (smtpErr: any) {
            console.error('SMTP Setup/Send Error:', smtpErr.message || smtpErr);
          }
        }
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error('Error updating status:', error);
      res.status(500).json({ error: 'Failed to update status' });
    }
  });

  // Student Search for Attendance
  app.get('/api/student-search', authenticate, async (req, res) => {
    try {
      const { batch_id, roll_number } = req.query;
      let q: any = db.collection('users').where('role', '==', 'student');
      if (batch_id) q = q.where('batch_id', '==', String(batch_id));
      if (roll_number) q = q.where('roll_number', '==', String(roll_number));
      
      const snapshot = await q.get();
      if (snapshot.empty) return res.status(404).json({ error: 'Student not found' });
      
      const student = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
      res.json(student);
    } catch (error) {
      res.status(500).json({ error: 'Search failed' });
    }
  });

  app.get('/api/attendance/report', authenticate, async (req: any, res) => {
    try {
      const { batch_id, program_id, startDate, endDate, type, status, roll_number } = req.query;
      let query: any = db.collection('attendance');

      if (batch_id && batch_id !== 'all') query = query.where('batch_id', '==', String(batch_id));
      if (program_id) query = query.where('program_id', '==', String(program_id));
      if (type) query = query.where('type', '==', String(type));
      if (status) query = query.where('status', '==', String(status));
      if (roll_number) query = query.where('roll_number', '==', String(roll_number));

      // Program ID filter would require joining which Firestore doesn't do natively well,
      // but we can filter by student's program if we had it in attendance doc.
      // For now, let's just filter by what's available.

      const snapshot = await query.get();
      let records = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));

      // Apply date filters in memory if needed
      if (startDate || endDate) {
        records = records.filter((r: any) => {
          const d = r.date;
          if (startDate && d < startDate) return false;
          if (endDate && d > endDate) return false;
          return true;
        });
      }

      res.json(records);
    } catch (error) {
      console.error('Error fetching attendance report:', error);
      res.status(500).json({ error: 'Failed to fetch attendance report' });
    }
  });

  // Standardize collection names (map URL paths to Firestore collection names)

  const collectionMap: Record<string, string> = {
    'batches': 'batches',
    'programs': 'programs',
    'courses': 'courses',
    'notices': 'notices',
    'resources': 'resources',
    'routines': 'routines',
    'gallery': 'gallery',
    'exams': 'exams',
    'chapters': 'chapters',
    'class-slides': 'class_slides',
    'payments': 'payments',
    'results': 'results',
    'reviews': 'reviews',
    'video-classes': 'video_classes',
    'degrees': 'degrees',
    'study-materials': 'study_materials',
    'web-recorded-classes': 'web_recorded_classes',
    'web-class-schedules': 'web_class_schedules',
    'enrollments': 'enrollments',
    'live-classes': 'live_classes',
    'attendance': 'attendance',
    'live-chat-messages': 'live_chat_messages',
    'live-polls': 'live_polls',
    'live-reactions': 'live_reactions',
    'live-participants': 'live_participants'
  };

  const genericCollections = Object.keys(collectionMap);

  genericCollections.forEach(pathName => {
    const collectionName = collectionMap[pathName];
    
    // GET all
    app.get(`/api/${pathName}`, authenticate, async (req, res) => {
      try {
        let query: any = db.collection(collectionName);
        Object.keys(req.query).forEach(key => {
          if (key !== 't') query = query.where(key, '==', req.query[key]);
        });
        const snapshot = await query.get();
        res.json(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      } catch (error) {
        console.error(`Error fetching ${pathName}:`, error);
        res.status(500).json({ error: `Failed to fetch ${pathName}` });
      }
    });

    // GET one
    app.get(`/api/${pathName}/:id`, authenticate, async (req, res) => {
      try {
        const doc = await db.collection(collectionName).doc(req.params.id).get();
        if (!doc.exists) return res.status(404).json({ error: 'Not found' });
        res.json({ id: doc.id, ...doc.data() });
      } catch (error) {
        res.status(500).json({ error: 'Failed to fetch document' });
      }
    });

    const sanitizeUrls = (obj: any) => {
      const parsed = { ...obj };
      for (const key of ['image_url', 'profile_pic', 'student_image']) {
        if (typeof parsed[key] === 'string' && parsed[key].includes('drive.google.com')) {
          const match = parsed[key].match(/drive\.google\.com\/file\/d\/([^\/]+)/);
          if (match && match[1]) {
            parsed[key] = `https://drive.google.com/uc?export=view&id=${match[1]}`;
          }
        }
      }
      return parsed;
    };

    // POST
    if (pathName !== 'enrollments' && pathName !== 'messages') {
      app.post(`/api/${pathName}`, authenticate, async (req, res) => {
        try {
          const sanitizedBody = sanitizeUrls(req.body);
          const data = { ...sanitizedBody, created_at: new Date().toISOString() };
          if (pathName === 'payments' && !data.status) {
            data.status = 'approved';
          }
          const docRef = await db.collection(collectionName).add(data);
          
          // Send automatic SMS and Email if it's a payment -- background task so we don't block response
          if (pathName === 'payments' || pathName === 'results') {
            (async () => {
              try {
                // Get student phone and email
                const studentId = data.student_id;
                let phone = "";
                let studentEmail = "";
                let studentName = data.student_name || "Student";
                if (studentId) {
                  const studentDoc = await db.collection('users').doc(studentId).get();
                  if (studentDoc.exists) {
                    const sData = studentDoc.data();
                    phone = sData?.guardian_phone || sData?.phone || "";
                    studentEmail = sData?.email || sData?.gmail || sData?.gmail_address || sData?.email_address || "";
                    if (!studentName || studentName === "Student") {
                      studentName = sData?.name || "Student";
                    }
                  }

                  // Try to find by email if data is missing
                  if (!studentEmail && data.email) studentEmail = data.email;
                  if (!studentEmail && data.gmail) studentEmail = data.gmail;
                  if (!phone && data.phone) phone = data.phone;
                  if (!phone && data.guardian_phone) phone = data.guardian_phone;

                  console.log(`[${pathName.toUpperCase()} BACKGROUND] studentId: ${studentId}, name: ${studentName}, email resolved: ${studentEmail || 'NONE'}, phone resolved: ${phone || 'NONE'}`);

                  // Create In-App Notification
                  let title = '';
                  let message = '';
                  let type = '';

                  if (pathName === 'payments') {
                    title = 'Payment Received';
                    message = `Your payment of ৳${data.amount} for ${data.month || 'this month'} has been received.`;
                    type = 'payment';
                  } else if (pathName === 'results') {
                    title = 'Result Added';
                    message = `Your result for ${data.exam_name || 'exam'} has been added. Marks: ${data.marks}`;
                    type = 'result';
                  }

                  await db.collection('notifications').add({
                    user_id: studentId,
                    title: title,
                    message: message,
                    type: type,
                    is_read: false,
                    created_at: new Date().toISOString()
                  });
                }
                
                const settingsSnapshot = await db.collection('settings').get();
                const settings: any = {};
                settingsSnapshot.docs.forEach(doc => { settings[doc.id] = doc.data().value; });
                  
                if (studentEmail) {
                  console.log(`[${pathName.toUpperCase()} EMAIL BACKGROUND] Attempting to connect & send email via Gmail SMTP to: ${studentEmail}`);
                  try {
                    let subject = '';
                    let htmlData = '';

                    if (pathName === 'payments') {
                      const currentMonth = data.month ? data.month + ' ' : '';
                      const amountTk = data.amount;
                      subject = `পেমেন্ট রসিদ: ${currentMonth}ফি`;
                      htmlData = `
                        <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
                          <h2 style="color: #16a34a;">পেমেন্ট সফল হয়েছে</h2>
                          <p>প্রিয় ${studentName},</p>
                          <p>আপনার <strong>${currentMonth}ফি</strong> বাবদ <strong>৳${amountTk}</strong> পেমেন্ট সফলভাবে গ্রহণ করা হয়েছে।</p>
                          <p>জাবেরম্যাথ কেয়ার-এর সাথে থাকার জন্য ধন্যবাদ!</p>
                        </div>
                      `;
                    } else if (pathName === 'results') {
                      subject = `ফলাফল প্রকাশ: ${data.exam_name || 'পরীক্ষা'}`;
                      htmlData = `
                        <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
                          <h2 style="color: #2563eb;">পরীক্ষার ফলাফল</h2>
                          <p>প্রিয় ${studentName},</p>
                          <p>আপনার <strong>${data.exam_name || 'পরীক্ষা'}</strong>-এর ফলাফল যুক্ত করা হয়েছে।</p>
                          <p>প্রাপ্ত নম্বর: <strong>${data.marks}</strong></p>
                          <p>বিস্তারিত ফলাফল জানতে জাবেরম্যাথ কেয়ার অ্যাপে লগইন করুন।</p>
                        </div>
                      `;
                    }

                    await sendSmtpEmail({
                      to: studentEmail,
                      subject: subject,
                      html: htmlData,
                      smtp_email: settings.smtp_email,
                      smtp_password: settings.smtp_password
                    });
                  } catch (emailErr: any) {
                    console.error(`[${pathName.toUpperCase()} EMAIL BACKGROUND] Auto Email sending failed:`, emailErr.message || emailErr);
                  }
                } else {
                  console.log(`[${pathName.toUpperCase()} EMAIL BACKGROUND] Not sending email. Email: ${studentEmail || 'NONE'}`);
                }

              } catch (e) {
                console.error(`Failed to send background auto SMS/Email for ${pathName}:`, e);
              }
            })();
          }

          res.json({ id: docRef.id, ...data });
        } catch (error) {
          res.status(500).json({ error: 'Failed to create document' });
        }
      });
    }

    // PUT
    app.put(`/api/${pathName}/:id`, authenticate, async (req, res) => {
      try {
        const sanitizedBody = sanitizeUrls(req.body);
        await db.collection(collectionName).doc(req.params.id).update(sanitizedBody);
        res.json({ success: true });
      } catch (error) {
        res.status(500).json({ error: 'Failed to update document' });
      }
    });

    // DELETE
    app.delete(`/api/${pathName}/:id`, authenticate, async (req: any, res) => {
      if (req.user.role !== 'admin' && req.user.role !== 'moderator') {
        return res.status(403).json({ error: 'Forbidden' });
      }
      try {
        const id = req.params.id;

        // Special handling for courses, programs, batches -> recursively delete students
        if (pathName === 'courses' || pathName === 'programs' || pathName === 'batches') {
          if (pathName === 'programs') {
            await deleteProgramData(id);
          } else if (pathName === 'batches') {
            await deleteBatchData(id);
          } else if (pathName === 'courses') {
            let fieldName = 'course_id';
            // Find students matching this ID, delete theirs
            const studentsQuery = await db.collection('users').where(fieldName, '==', id).get();
            for (const doc of studentsQuery.docs) {
              try {
                if (doc.id) {
                  await admin.auth().deleteUser(doc.id).catch(() => {});
                  await deleteStudentData(doc.id);
                }
                await doc.ref.delete();
              } catch (err) {
                console.error(`Failed to delete student ${doc.id}:`, err);
              }
            }

            // Also delete sub-collections of courses as in old frontend logic
            const collectionsToDelete = [
              "chapters", "routines", "study_materials", 
              "video_classes", "class_slides", "web_recorded_classes", 
              "web_class_schedules"
            ];
            for (const colName of collectionsToDelete) {
               try {
                 const items = await db.collection(colName).where("course_id", "==", id).get();
                 for (const itemDoc of items.docs) {
                   await itemDoc.ref.delete();
                 }
               } catch (e) {
                 console.error(`Failed to delete sub-collection ${colName} of course ${id}:`, e);
               }
            }
          }
        }

        await db.collection(collectionName).doc(id).delete();
        res.json({ success: true });
      } catch (error) {
        console.error(`[DELETE /api/${pathName}/:id] Error:`, error);
        res.status(500).json({ error: 'Failed to delete document' });
      }
    });
  });

  // Special handling for attendance (Admin/Moderator only)
  app.post('/api/attendance/mark-present', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin' && req.user.role !== 'moderator') return res.status(403).json({ error: 'Forbidden' });
    try {
      const { student_id, batch_id, date, status, roll_number } = req.body;
      const data = {
        student_id,
        batch_id,
        date: date || new Date().toISOString().split('T')[0],
        status: status || 'present',
        roll_number,
        created_at: new Date().toISOString()
      };
      const docRef = await db.collection('attendance').add(data);
      res.json({ id: docRef.id, ...data });
    } catch (error) {
      res.status(500).json({ error: 'Failed to mark attendance' });
    }
  });

  app.post('/api/attendance/auto-absent', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin' && req.user.role !== 'moderator') return res.status(403).json({ error: 'Forbidden' });
    try {
      const { batch_id, date } = req.body;
      if (!batch_id || !date) return res.status(400).json({ error: 'batch_id and date required' });
      
      // Get all students in this batch (primary or secondary)
      const studentsSnapshot1 = await db.collection('users')
        .where('role', '==', 'student')
        .where('batch_id', '==', String(batch_id))
        .get();
        
      const studentsSnapshot2 = await db.collection('users')
        .where('role', '==', 'student')
        .where('batch_id_2', '==', String(batch_id))
        .get();
        
      const studentDocsMap = new Map();
      studentsSnapshot1.docs.forEach(doc => studentDocsMap.set(doc.id, doc));
      studentsSnapshot2.docs.forEach(doc => studentDocsMap.set(doc.id, doc));
      
      const allStudentDocs = Array.from(studentDocsMap.values());
      
      const studentIds = allStudentDocs.map(doc => doc.id);
      
      // Get existing attendance for this date and batch
      const attendanceSnapshot = await db.collection('attendance')
        .where('batch_id', '==', String(batch_id))
        .where('date', '==', date)
        .get();
      
      const alreadyMarkedIds = new Set(attendanceSnapshot.docs.map(doc => doc.data().student_id));
      
      const batch = db.batch();
      let count = 0;
      
      for (const studentDoc of allStudentDocs) {
        if (!alreadyMarkedIds.has(studentDoc.id)) {
          const studentData = studentDoc.data();
          const attendanceRef = db.collection('attendance').doc();
          batch.set(attendanceRef, {
            student_id: studentDoc.id,
            batch_id: String(batch_id),
            date,
            status: 'absent',
            type: 'class',
            roll_number: studentData.roll_number,
            isAuto: true,
            created_at: new Date().toISOString()
          });
          count++;
        }
      }
      
      if (count > 0) await batch.commit();
      res.json({ success: true, count });
    } catch (error) {
      console.error('Auto-absent error:', error);
      res.status(500).json({ error: 'Failed to trigger auto-absent' });
    }
  });

  app.post('/api/admin/clear-all-data', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const { collection: collectionName } = req.body;
    try {
      const snapshot = await db.collection(collectionName).get();
      const batch = db.batch();
      snapshot.docs.forEach(doc => batch.delete(doc.ref));
      await batch.commit();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to clear data' });
    }
  });

  // Student Status Update
  app.patch('/api/students/:id/status', authenticate, async (req, res) => {
    try {
      const { status } = req.body;
      
      const userDoc = await db.collection('users').doc(req.params.id).get();
      if (!userDoc.exists) return res.status(404).json({ error: 'User not found' });
      
      const updateData: any = { status };
      
      // If approved and current type is online, change to offline
      if (status === 'approved' && userDoc.data()?.student_type === 'online') {
        updateData.student_type = 'offline';
      }
      
      await db.collection('users').doc(req.params.id).update(updateData);
      res.json({ success: true });
    } catch (error) {
      console.error('Failed to update student status:', error);
      res.status(500).json({ error: 'Failed to update student status' });
    }
  });

  // Reset Data Route
  app.post('/api/reset-data', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });
    const { type } = req.body;
    try {
      const collections: Record<string, string> = {
        'students': 'users',
        'online_students': 'users',
        'offline_students': 'users',
        'batches': 'batches',
        'payments': 'payments',
        'enrollments': 'enrollments',
        'attendance': 'attendance',
        'exams': 'exams',
        'results': 'results',
        'notices': 'notices',
        'live_classes': 'live_classes',
        'study_materials': 'study_materials',
        'gallery': 'gallery',
        'video_classes': 'video_classes',
        'class_slides': 'class_slides',
        'routines': 'routines',
        'programs': 'programs',
        'courses': 'courses',
        'chapters': 'chapters',
        'messages': 'messages',
        'web_recorded_classes': 'web_recorded_classes',
        'web_class_schedules': 'web_class_schedules'
      };

      const collectionName = collections[type];
      if (!collectionName) return res.status(400).json({ error: 'Invalid type' });

      let query: any = db.collection(collectionName);
      if (type === 'online_students') query = query.where('student_type', '==', 'online');
      if (type === 'offline_students') query = query.where('student_type', '==', 'offline');
      if (type === 'students') query = query.where('role', '==', 'student');

      const snapshot = await query.get();
      const batch = db.batch();
      snapshot.docs.forEach((doc: any) => {
        // Don't delete the admin user if resetting students
        if (collectionName === 'users' && doc.data().role === 'admin') return;
        batch.delete(doc.ref);
      });
      await batch.commit();
      res.json({ success: true });
    } catch (error) {
      console.error('Reset error:', error);
      res.status(500).json({ error: 'Failed to reset data' });
    }
  });

  // Public routes (no auth needed for some GETs)
  app.get('/api/public/notices', async (req, res) => {
    try {
      const snapshot = await db.collection('notices').where('is_verified', '==', true).get();
      const notices = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json(notices);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch notices' });
    }
  });

  app.get('/api/public/results', async (req, res) => {
    try {
      const [resultsSnap, usersSnap] = await Promise.all([
        db.collection('results').get(),
        db.collection('users').get()
      ]);
      const usersMap = new Map();
      usersSnap.docs.forEach(doc => {
        usersMap.set(doc.id, doc.data());
      });
      const results = resultsSnap.docs.map(doc => {
        const data = doc.data();
        let roll_number = data.roll_number;
        let student_name = data.student_name;
        if ((!roll_number || !student_name) && data.student_id) {
           const studentData = usersMap.get(data.student_id);
           if (studentData) {
             roll_number = studentData.roll_number || '';
             student_name = studentData.name || '';
           }
        }
        return { 
          id: doc.id, 
          ...data,
          roll_number,
          student_name
        };
      });
      res.json(results);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to fetch results' });
    }
  });

  app.get('/api/public/exams', async (req, res) => {
    try {
      const snapshot = await db.collection('exams').get();
      const exams = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json(exams);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch exams' });
    }
  });

  app.get('/api/public/programs', async (req, res) => {
    try {
      const snapshot = await db.collection('programs').get();
      const programs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json(programs);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch programs' });
    }
  });

  app.get('/api/public/batches', async (req, res) => {
    try {
      const snapshot = await db.collection('batches').get();
      const batches = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json(batches);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch batches' });
    }
  });

  // SMS Integration
  app.post('/api/notifications/broadcast', authenticate, async (req: any, res) => {
    try {
      const { user_ids, title, message, type } = req.body;
      if (!Array.isArray(user_ids)) return res.status(400).json({ error: 'user_ids must be an array' });

      const batch = db.batch();
      user_ids.forEach(uid => {
        const ref = db.collection('notifications').doc();
        batch.set(ref, {
          user_id: uid,
          title,
          message,
          type: type || 'announcement',
          is_read: false,
          created_at: new Date().toISOString()
        });
      });

      await batch.commit();
      res.json({ success: true, count: user_ids.length });
    } catch (error) {
      console.error('Broadcast error:', error);
      res.status(500).json({ error: 'Failed to broadcast notifications' });
    }
  });

  app.post('/api/send-sms', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin' && req.user.role !== 'moderator') return res.status(403).json({ error: 'Forbidden' });
    try {
      const { phone, message } = req.body;
      if (!phone || !message) {
        return res.status(400).json({ error: 'Phone and message are required' });
      }

      const settingsSnapshot = await db.collection('settings').get();
      const settings: any = {};
      settingsSnapshot.docs.forEach(doc => {
        settings[doc.id] = doc.data().value;
      });

      if (!settings.sms_api_url) {
        return res.status(400).json({ error: 'SMS Gateway URL not configured in Settings' });
      }

      const url = new URL(settings.sms_api_url);
      if (settings.sms_api_key) url.searchParams.append("api_key", settings.sms_api_key);
      if (settings.sms_sender_id) url.searchParams.append("senderid", settings.sms_sender_id);
      url.searchParams.append("number", phone);
      url.searchParams.append("message", message);
      
      const response = await fetch(url.toString());
      const responseText = await response.text();
      
      console.log(`SMS dispatched to ${phone}. Response: ${responseText}`);
      res.json({ success: true, response: responseText });
    } catch (error: any) {
      console.error('Error sending SMS:', error);
      res.status(500).json({ error: 'Failed to send SMS', details: error.message });
    }
  });

  app.post('/api/send-email', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin' && req.user.role !== 'moderator') return res.status(403).json({ error: 'Forbidden' });
    try {
      const { email, subject, message } = req.body;
      if (!email || !subject || !message) {
        return res.status(400).json({ error: 'Email, subject and message are required' });
      }

      await sendSmtpEmail({
        to: email,
        subject,
        html: message
      });
      
      res.json({ success: true, message: 'Email dispatched successfully' });
    } catch (error: any) {
      console.error('Error sending Email:', error);
      res.status(500).json({ error: 'Failed to send Email', details: error.message });
    }
  });

  app.post('/api/test-smtp', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin' && req.user.role !== 'moderator') return res.status(403).json({ error: 'Forbidden' });
    try {
      const { smtp_email, smtp_password } = req.body;
      if (!smtp_email || !smtp_password) {
        return res.status(400).json({ error: 'Both SMTP Email and SMTP App Password are required' });
      }

      // Try sending a test email using our robust helper
      await sendSmtpEmail({
        to: smtp_email.trim(),
        subject: 'SMTP Connection Test - JaberMath Care',
        html: `
          <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
            <p style="font-size: 18px; font-weight: bold; color: #16a34a;">SMTP Test Succeeded!</p>
            <p>Congratulations, your App has successfully connected to the Gmail SMTP server.</p>
            <p>Automated transactional messages will now be dispatched without issue!</p>
            <p>Best regards,<br/>JaberMath Care system</p>
          </div>
        `,
        smtp_email,
        smtp_password
      });
      
      res.json({ success: true, message: 'SMTP configurations are valid! A test email has been sent to ' + smtp_email });
    } catch (error: any) {
      console.error('SMTP testing connection failed:', error);
      res.status(500).json({ error: 'SMTP Connection Failed', details: error.message });
    }
  });

  // Coupons
  app.get('/api/coupons', authenticate, async (req: any, res) => {
    try {
      const snapshot = await db.collection('coupons').get();
      res.json(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch coupons' });
    }
  });

  app.post('/api/coupons', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Not authorized' });
    try {
      const { code, type, value, expiry_date, status } = req.body;
      const couponData = { 
        code: code.toUpperCase(), 
        type, 
        value: Number(value), 
        expiry_date, 
        status: status || 'active',
        created_at: new Date().toISOString()
      };
      const docRef = await db.collection('coupons').add(couponData);
      res.json({ id: docRef.id, ...couponData });
    } catch (error) {
      res.status(500).json({ error: 'Failed to create coupon' });
    }
  });

  app.delete('/api/coupons/:id', authenticate, async (req: any, res) => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Not authorized' });
    try {
      await db.collection('coupons').doc(req.params.id).delete();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete coupon' });
    }
  });

  app.post('/api/validate-coupon', async (req, res) => {
    try {
      const { code, amount } = req.body;
      const snapshot = await db.collection('coupons').where('code', '==', code.toUpperCase()).where('status', '==', 'active').get();
      
      if (snapshot.empty) return res.status(404).json({ error: 'Invalid coupon code' });
      
      const coupon = snapshot.docs[0].data();
      const now = new Date();
      if (coupon.expiry_date && new Date(coupon.expiry_date) < now) {
          return res.status(400).json({ error: 'Coupon has expired' });
      }

      let discount = 0;
      if (coupon.type === 'percentage') {
          discount = (Number(amount) * Number(coupon.value)) / 100;
      } else {
          discount = Number(coupon.value);
      }

      res.json({ 
          valid: true, 
          discount: Math.min(discount, Number(amount)),
          final_amount: Math.max(0, Number(amount) - discount),
          coupon_id: snapshot.docs[0].id
      });
    } catch (error) {
      res.status(500).json({ error: 'Validation failed' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath, {
      setHeaders: (res, path) => {
        if (path.endsWith('.html')) {
          res.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
          res.set('Pragma', 'no-cache');
          res.set('Expires', '0');
        }
      }
    }));
    app.get('*', (req, res) => {
      res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
export { db, admin };
